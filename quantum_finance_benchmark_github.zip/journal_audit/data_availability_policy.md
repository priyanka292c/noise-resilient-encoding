# Physical Review Applied — Data Availability Policy

**Source:** https://journals.aps.org/authors/editorial-policies#data-availability  
**Accessed:** 2026-10-03  
**Status:** VERIFIED from official APS editorial policies page

---

## Official Requirement

**All published articles MUST include a Data Availability Statement (DAS)**
that explains whether and how authors are sharing their data.

Authors are asked to enter a complete data availability statement during
the submission process, including relevant citations.

Source: https://journals.aps.org/prapplied/authors#data-availability-statements

Guidelines: https://journals.aps.org/authors/editorial-policies#data-availability

---

## DAS Structure Requirements

The DAS must state:
- Whether data are available
- Where data are available
- How data can be accessed
- Relevant citations for external datasets

---

## Data Availability Statement for This Manuscript

### Draft DAS (to be refined after all simulations complete):

The simulation data, quantum circuit definitions, noise model parameters,
preprocessing scripts, and analysis code that support the findings of this
study are available in the GitHub repository at https://github.com/priyanka292c/noise-resilient-encoding.
The financial indicator dataset is derived from publicly available market data
obtained via the Yahoo Finance API through the `yfinance` Python library
(version 0.2.36; https://pypi.org/project/yfinance/). The specific download
parameters, time interval, and preprocessing steps are documented in
`data/metadata/dataset_metadata.json` in the repository. All simulation
results were generated using Qiskit Aer v0.17.2 and are fully reproducible
using the provided `run_all.py` script with the specified random seeds.
No physical quantum hardware measurements were performed; all hardware-related
results are clearly labeled as "hardware-informed simulation."

### Status: COMPLIANT — Updated:
- [x] Actual GitHub repository URL: https://github.com/priyanka292c/noise-resilient-encoding
- [x] Exact yfinance version (0.2.36)
- [x] Exact Qiskit Aer version (0.17.2)
- [x] Confirm no hardware measurements (purely hardware-informed simulations)

---

## Source URLs

- DAS guidelines: https://journals.aps.org/authors/editorial-policies#data-availability
- DAS style basics: https://journals.aps.org/authors/style-basics#data-availability-statement
- Author instructions: https://journals.aps.org/prapplied/authors#data-availability-statements
