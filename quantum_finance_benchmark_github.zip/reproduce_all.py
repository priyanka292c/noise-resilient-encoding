#!/usr/bin/env python3
"""
reproduce_all.py
================
One-Click Master Reproducibility Script for:
"Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction:
 A Hardware-Informed Benchmark"
Target Journal: Quantitative Finance (Taylor & Francis)

Executes all analytical, simulation, machine learning, and figure/table generation
stages to reproduce Tables 1-8 (main), Tables S1-S6 (supplementary), and Figures 1-7.
"""

import os
import sys
import subprocess
import datetime
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
VENV_PYTHON = os.path.join(ROOT, ".venv", "Scripts", "python.exe")
PYTHON_EXE = VENV_PYTHON if os.path.exists(VENV_PYTHON) else sys.executable
PYTHON_DIR = os.path.join(ROOT, "python")

STAGES = [
    ("01", "01_environment_check.py",               "1. Environment and dependency verification"),
    ("02", "02_download_prepare_data.py",            "2. SPY ETF daily market ingestion (2015-2023)"),
    ("03", "03_feature_engineering.py",              "3. Causal technical indicator engineering & normalization"),
    ("04", "04_quantum_encoding.py",                 "4. Quantum feature map compilations & OpenQASM 3.0 export"),
    ("05", "05_ideal_simulation.py",                 "5. Statevector simulation (Ideal representation baseline)"),
    ("06", "06_noise_models.py",                     "6. Microscopic open-system noise sweeps (7 channels)"),
    ("07", "07_noise_mitigation.py",                 "7. Error mitigation evaluation (Linear ZNE, Richardson, MEM)"),
    ("08", "08b_controlled_physics_experiments.py",  "8. Controlled-depth ablation & multi-distribution tests"),
    ("09", "run_downstream_prediction.py",           "9. Downstream directional forecasting & economic backtesting"),
    ("10", "12_generate_figures.py",                 "10. Primary figure generation (Fig 1 workflow, Fig 2 circuits, etc.)"),
    ("11", "generate_qf_figures.py",                 "11. Quantitative Finance figures (Fig 5 distortion, Fig 6, Fig 7)"),
    ("12", "13_generate_tables.py",                  "12. Summary table generation (LaTeX & Markdown)"),
    ("13", "build_main_qf_manuscript.py",             "13. Build main manuscript LaTeX source"),
    ("14", "build_main_qf_markdown.py",               "14. Build main manuscript Markdown document"),
    ("15", "build_supplementary_quantitative_finance.py", "15. Build supplementary LaTeX & Markdown documents"),
]

def run_stage(idx, script_name, description):
    script_path = os.path.join(PYTHON_DIR, script_name)
    print(f"\n{'='*75}")
    print(f"[{idx}/{len(STAGES)}] {description}")
    print(f"Executing: {script_name}")
    print(f"Timestamp: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*75}")

    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"

    start_t = time.time()
    res = subprocess.run([PYTHON_EXE, script_path], cwd=ROOT, env=env)
    dur = time.time() - start_t

    if res.returncode == 0:
        print(f"--> [SUCCESS] Completed in {dur:.2f}s")
        return True
    else:
        print(f"--> [ERROR] Failed with exit code {res.returncode}")
        return False

def main():
    print("=" * 75)
    print("QUANTITATIVE FINANCE (TAYLOR & FRANCIS) — MASTER REPRODUCIBILITY ENGINE")
    print("Article: Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction")
    print(f"Python:  {PYTHON_EXE}")
    print(f"Root:    {ROOT}")
    print("=" * 75)

    success_count = 0
    for idx, script_name, desc in STAGES:
        ok = run_stage(idx, script_name, desc)
        if ok:
            success_count += 1
        else:
            print(f"\n[ABORT] Pipeline stopped at stage {idx} ({script_name}).")
            sys.exit(1)

    print("\n" + "=" * 75)
    print(f"REPRODUCIBILITY PIPELINE FINISHED: {success_count}/{len(STAGES)} stages passed.")
    print("All experimental tables (Tables 1-8) and publication figures (Figures 1-7)")
    print("have been successfully verified and generated.")
    print("=" * 75)

if __name__ == "__main__":
    main()
