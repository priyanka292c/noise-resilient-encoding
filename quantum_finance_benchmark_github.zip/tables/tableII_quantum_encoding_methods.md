# Table II: Quantum Encoding Methods

| Paradigm | Hilbert Space | Classical-Quantum Mapping | Invertibility |
| --- | --- | --- | --- |
| Angle Encoding (AE) | Product state |psi(x)> = Tensor_i Rx(pi x_i)|0> | Single-qubit Pauli-X rotations | Analytic inversion: x_i = arccos(<Z_i>)/pi |
| AE + Entanglement (AEE) | Entangled state with linear CNOT cascade | Sandwiched Rx rotations with CX entanglers | Non-invertible from marginal Z expectations alone |
| IQP Feature Map | Non-separable diagonal unitary evolution | Hadamard + Rz(2x_i) + linear Rzz(2x_i x_j) | Non-invertible without full quantum state tomography |
