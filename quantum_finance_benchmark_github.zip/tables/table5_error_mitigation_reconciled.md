# Table V: Reconciled Error Mitigation Performance Audit

| Mitigation Condition | Protocol / Scale Factors | AE Observable Agreement $S_Z$ | AE Delta $\Delta S_Z$ | AEE Observable Agreement $S_Z$ | AEE Delta $\Delta S_Z$ | Total Shots |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Ideal (Noiseless Reference)** | Analytic statevector | 0.999985 | Reference | 0.840976 | Reference | 8,192 |
| **Noisy (Unmitigated Baseline)** | $p_{1Q}=0.01, p_{2Q}=0.03$ | 0.999970 | Reference | 0.845879 | Reference | 8,192 |
| **ZNE - Linear** | Unitary gate folding $\lambda \in [1, 3, 5]$ | 0.999976 | **+0.000006** (Improvement) | 0.841601 | -0.004278 (Degradation) | 24,576 ($3\times$) |
| **ZNE - Richardson** | Two-point polynomial $\lambda \in [1, 3]$ | 0.999957 | **-0.000013** (Variance Loss) | 0.841200 | -0.004679 (Degradation) | 16,384 ($2\times$) |
| **MEM (Confusion Inversion)** | Complete $2^n=16$ basis state inversion | 0.999972 | **+0.000002** (Improvement) | 0.846211 | **+0.000332** (Improvement) | 139,264 ($17\times$) |

---

### Methodological Notes:
1. **Mathematical Explanation of Richardson Failure:** Under two-point Richardson extrapolation $\hat{E}_{\text{Rich}}(0) = 1.5\hat{E}(1) - 0.5\hat{E}(3)$, finite-sample measurement variance is amplified by $(1.5)^2 + (-0.5)^2 = 2.5\times$ relative to raw measurements. When the physical noise bias is smaller than this sampling noise inflation, Richardson extrapolation degrades the observable agreement metric $S_Z$.
2. **Measurement Error Mitigation (MEM):** MEM yields slight observable improvement for both AE and AEE, but incurs a massive $17\times$ shot overhead ($139,264$ shots), yielding diminishing returns for state preparation circuits dominated by coherent two-qubit gate errors.

