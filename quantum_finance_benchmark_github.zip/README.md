# Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction: A Hardware-Informed Benchmark

[![Target Journal: Quantitative Finance](https://img.shields.io/badge/Journal-Quantitative%20Finance-005A9C.svg)](https://www.tandfonline.com/journals/RQUF)
[![Publisher: Taylor & Francis](https://img.shields.io/badge/Publisher-Taylor%20%26%20Francis-blue.svg)](https://www.tandfonline.com/)
[![Article Type: Research Article](https://img.shields.io/badge/Article%20Type-Research%20Article-1B365D.svg)](https://authorservices.taylorandfrancis.com/)
[![Status: Submitted](https://img.shields.io/badge/Status-Submitted%20(2026)-orange.svg)]()
[![Python: 3.11.14](https://img.shields.io/badge/Python-3.11.14-3776AB.svg?logo=python&logoColor=white)](https://www.python.org/)
[![Qiskit: 2.5.2](https://img.shields.io/badge/Qiskit-2.5.2-6929C4.svg?logo=qiskit&logoColor=white)](https://qiskit.org/)
[![Qiskit-Aer: 0.17.2](https://img.shields.io/badge/Qiskit--Aer-0.17.2-6929C4.svg?logo=qiskit&logoColor=white)](https://qiskit.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Reproducibility: 100% Deterministic (Seed=42)](https://img.shields.io/badge/Reproducibility-Seed%20%3D%2042-brightgreen.svg)](reproduce_all.py)

This repository contains the complete empirical data, quantum circuit generators, open-quantum-system noise simulation pipelines, econometrics evaluation suite, error mitigation audits, figure/table generation scripts, and publication manuscript sources for:

> **"Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction: A Hardware-Informed Benchmark"**  
> *Target Journal:* **Quantitative Finance** (Taylor & Francis)  
> *Article Type:* **Research Article**  
> *Authors:* Shahrukh Saleem$^1$, Araby Madbouly$^2$, Uvesh Husain$^3$, Ram Soorat$^{4,*}$, Priyanka$^5$, Afzalur Rahman$^6$  
> $^1$*VIT Business School, Vellore Institute of Technology, India*  
> $^2$*Muscat College, Oman*  
> $^3$*Mazoon College, Oman*  
> $^4$*School of Technology, Woxsen University, India*  
> $^5$*Department of Physics and Astrophysics, University of Delhi, India*  
> $^6$*School of Business, Woxsen University, India*  
> \*Corresponding Author: `ram.soorat@woxsen.edu.in`

---

## 🔬 Scientific Overview & Problem Formulation

Modern quantitative finance and empirical asset pricing frequently deploy machine learning to uncover non-linear signals in noisy, non-stationary market time series. Quantum Machine Learning (QML) algorithms leverage quantum feature maps $\Phi(\mathbf{x})$ to embed market indicators into $2^n$-dimensional Hilbert spaces where non-linear patterns may become linearly separable. 

However, in Noisy Intermediate-Scale Quantum (NISQ) processors, physical hardware noise—including environmental energy relaxation ($T_1$), transverse dephasing ($T_2$), coherent gate infidelities, and readout confusion—distorts these quantum state representations.

This repository implements a rigorous, finance-first benchmark evaluating three encoding architectures across daily S&P 500 ETF (`SPY`) market data (2015–2023; 2,013 valid trading days):
1. **Angle Encoding (AE):** Product-state separable circuit (depth 1, 4 single-qubit gates, 0 CX).
2. **Angle Encoding with Linear Entanglement (AE+ENT):** Depth 5, 8 single-qubit gates, 3 nearest-neighbor CNOT gates.
3. **Instantaneous Quantum Polynomial (IQP) Feature Map:** Depth 13, 19 single-qubit gates, 6 CNOT gates (decomposed native CNOT-Rz-CNOT sequences).

---

## ⚙️ 5-Qubit Backend vs. 4-Qubit Active Circuit Register

An essential methodological distinction in this benchmark is the relationship between the physical backend topology and the circuit register:

- **Instantiated Backend Topology:** Qiskit's `GenericBackendV2(num_qubits=5, seed=42)` was instantiated with five qubits to provide a canonical, reproducible hardware-informed transmon topology.
- **Active Experimental Register:** All reported 4-qubit quantum encoding circuits and downstream learning experiments execute **strictly on the active $q_0-q_3$ subgraph register**. Qubit $q_4$ remains completely idle and does not participate in state preparation, entangling interactions, or measurement readout.
- **Physical Parameter Separation:**
  - **Active Register ($q_0-q_3$ Mean):** $T_1 = 167.1\;\mu\text{s}$, $T_2 = 142.3\;\mu\text{s}$, single-qubit error $p_{1Q} \approx 9.41 \times 10^{-5}$, directed CNOT error across the 6 active pairs $p_{2Q} \approx 2.84 \times 10^{-3}$, readout assignment error $p_{\text{ro}} \approx 1.86 \times 10^{-3}$.
  - **Full 5-Qubit Topology ($q_0-q_4$ Mean):** $T_1 = 166.5\;\mu\text{s}$, $T_2 = 150.3\;\mu\text{s}$, single-qubit error $p_{1Q} \approx 9.35 \times 10^{-5}$, 8-pair CNOT error $p_{2Q} \approx 2.94 \times 10^{-3}$, readout error $p_{\text{ro}} \approx 1.79 \times 10^{-3}$.
- *Explicit Hardware Disclosure:* Computations are conducted via density matrix and shot-based open-quantum-system simulations on classical hardware; no physical dilution refrigerator quantum hardware was operated.

---

## 📊 Summary of Primary Findings

1. **Decoupling State Fidelity from Marginal Agreement:** Single-qubit Pauli-$Z$ marginal agreement ($S_Z \ge 0.9998$) substantially overstates state preservation in entangling circuits, masking severe multi-qubit phase corruption. Genuine Uhlmann state fidelity reveals substantial degradation ($\mathcal{F}_Q = 0.9609$ for AE+ENT and $\mathcal{F}_Q = 0.9257$ for IQP), driving Frobenius kernel distortion to $7.02\%$ and $13.03\%$.
2. **The Entanglement Penalty:** Controlled-depth ablations holding logical depth fixed at $d=5$ and $d=13$ demonstrate that two-qubit entangling gates account for $90.1\%$ and $86.5\%$ of additional state infidelity. Non-entangled Angle Encoding achieves near-perfect fidelity ($\mathcal{F}_Q = 0.9989$).
3. **Finite-Shot Variance Amplification in Richardson ZNE:** Two-point Richardson Zero-Noise Extrapolation amplifies finite-sample variance by $2.5\times$ relative to raw measurements under independent equal-variance sampling ($\operatorname{Var}(\hat{O}_{\text{Rich}}) \approx 2.5 \sigma^2/N$), degrading observable accuracy under realistic shot budgets ($N = 8,192$).
4. **Downstream Forecasting & Transaction-Cost Decay:** Out-of-sample directional forecasting accuracy spans 50.8% to 54.0% across classical and quantum models, with no statistically significant outperformance over linear baselines (Diebold–Mariano test $p > 0.07$). High-turnover quantum models incur severe Sharpe ratio decay under transaction friction (noisy IQP collapses from 1.28 to 0.86 at 20 bps), while shallow AE ($0.7\times - 7.4\times$ turnover) preserves risk-adjusted performance.
5. **Distribution Invariance:** Benchmarking across uniform, standard normal, and correlated Gaussian distributions indicates that hardware-noise vulnerability is driven primarily by circuit topology and physical gate characteristics rather than the specific statistical properties of the input features.

---

## 💻 Environment Setup & Requirements

### Software Dependencies
The entire codebase is verified on **Python 3.11.14** under Windows 11 Enterprise (x86_64) and Linux:
- `qiskit == 2.5.2`
- `qiskit-aer == 0.17.2`
- `numpy == 1.26.4`
- `scipy == 1.13.1`
- `pandas == 2.2.2`
- `scikit-learn == 1.4.2`
- `matplotlib == 3.8.4`
- `yfinance == 1.7.0`

### Installation
```bash
# Clone the repository
git clone https://github.com/priyanka292c/noise-resilient-encoding.git
cd noise-resilient-encoding

# Create virtual environment
python -m venv .venv

# Activate environment
# On Windows PowerShell:
.venv\Scripts\Activate.ps1
# On Linux/macOS:
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

---

## 🚀 Step-by-Step Reproduction Guide (Tables 1–10 & Figures 1–7)

All experiments run deterministically using fixed random seed `seed = 42`.

### One-Click Reproduction
To execute the complete pipeline and regenerate all data, tables, figures, and manuscripts:
```bash
python reproduce_all.py
```

### Modular Pipeline Execution

| Stage | Script | Output / Artifacts | Description |
|:---:|:---|:---|:---|
| **01** | `python python/01_environment_check.py` | Terminal log | Verifies Python environment, Qiskit version, and packages |
| **02** | `python python/02_download_prepare_data.py` | `data/raw/`, `data/processed/` | Ingests SPY daily prices (2015–2023) and computes 8 causal indicators |
| **03** | `python python/03_feature_engineering.py` | `tables/table1_financial_indicators.csv` | Augmented Dickey-Fuller tests, correlation matrix, Table 1 |
| **04** | `python python/04_quantum_encoding.py` | `circuits/qasm/`, `tables/table2_circuit_resources.csv` | Generates AE, AE+ENT, and IQP circuits and OpenQASM 3.0 files |
| **05** | `python python/05_ideal_simulation.py` | Ideal statevectors, Table 4 baseline | Computes exact statevectors and ideal observable expectations |
| **06** | `python python/06_noise_models.py` | `tables/table3_noise_models.csv`, Table 4 | Evaluates 7 isolated physical noise channels (depolarizing, damping, etc.) |
| **07** | `python python/07_noise_mitigation.py` | `tables/table5_error_mitigation.csv` | Audits Linear ZNE, Richardson ZNE (2.5× variance), and MEM |
| **08** | `python python/08_hardware_calibrated_simulation.py` | `tables/table4_hw_informed.csv` | Simulates `GenericBackendV2(5Q, seed=42)` across active $q_0-q_3$ register |
| **09** | `python python/08b_controlled_physics_experiments.py` | Depth ablation & distribution results | Depth 5 & 13 ablations, synthetic distribution sweeps |
| **10** | `python python/run_downstream_prediction.py` | `tables/table7_*.csv`, `tables/table8_*.csv` | QSVM vs classical forecasting, Diebold–Mariano tests, friction backtests |
| **11** | `python python/12_generate_figures.py` | `figures/pdf/fig01_workflow.pdf` to `fig04_*.pdf` | Generates primary publication figures |
| **12** | `python python/generate_qf_figures.py` | `figures/pdf/fig06_*.pdf`, `fig07_*.pdf` | Generates Quantitative Finance figures (Figs 5, 6, 7) |
| **13** | `python python/13_generate_tables.py` | `tables/table*.csv` | Exports all tables in CSV, Markdown, and LaTeX formats |
| **14** | `python python/build_main_qf_manuscript.py` | `manuscript/main_quantitative_finance.tex` | Generates main manuscript LaTeX source |
| **15** | `python python/build_supplementary_quantitative_finance.py` | `supplementary/supplementary_quantitative_finance.tex` | Generates supplementary LaTeX and Markdown documents |
| **16** | `python python/build_qf_submission_package.py` | `submission_package/` | Generates verified submission package and SHA-256 manifest |

---

## 📑 OpenQASM 3.0 Circuit Listings

Canonical OpenQASM 3.0 listings for the three feature maps evaluated in the paper are stored in `circuits/qasm/` and documented in Supplementary Material Section S1:
- `circuits/qasm/angle_encoding.qasm` (Depth 1, 0 CX)
- `circuits/qasm/angle_encoding_entangled.qasm` (Depth 5, 3 CX)
- `circuits/qasm/iqp_feature_map.qasm` (Depth 13, 6 CX decomposed native CNOT-Rz-CNOT)

---

## 🔒 Cryptographic SHA-256 Verification Hashes

Table of exact SHA-256 hashes ensuring 100% bit-level reproducibility:

| File Artifact | Cryptographic SHA-256 Checksum |
|:---|:---|
| `data/processed/encoding_features.csv` | `04008f68adcaf51cacea5bcdf64a94df8764c8c024bbcc6b72332654bd52cee5` |
| `tables/table1_financial_indicators.csv` | `f692b84adb42e188f7d8dc1d3cf7fe49b7bf5ae9c9e0d0d2d938ecb87247fb74` |
| `tables/table2_circuit_resources.csv` | `14bd16ce6620413f6138b2c9a433a314f9115e5b26c3395d998521dfcc474cd3` |
| `tables/table3_noise_models.csv` | `be923ec6fa664de69fe7670f016670dbf3fc0a31989204b54af7d6929932b37a` |
| `tables/table4_hw_informed.csv` | `a81d72cb1f729343f9ad2b2a3c2c78179cfbed8ab8a20ff9fbb8a692f2ffe95d` |
| `tables/table5_error_mitigation.csv` | `de52434e99d53ae1d7ee6c6dcc3e21127eabc9367fec475d75dbb51d83b3e8b2` |
| `tables/table7_predictive_performance.csv` | `699d6f1770adc1fca8a3bf5f7581a987b4f9345d7c5fd04fdbaa814c92e8acee` |
| `tables/table8_economic_significance.csv` | `8235f619cd75f44b4a16be9f4c243902ce343d293cb2bdbdc902d21f1349cd4c` |
| `tables/table9_walk_forward_validation.csv` | `1c8c534906b76deaf3b8f436e0b837bc83e2d99a79be8a18f47dbf8dbd8a41df` |
| `tables/table10_kernel_target_alignment.csv` | `800151d32f925f4b53b6890fe0cb1bcbf20c30dc6f046ae39944ec0572b45610` |
| `results/master_simulation_bundle.json` | `03a4ee08f72829fdfa8f3e66c3aa59ea46b179fe83d0e09ffdc1ea8d98a92e22` |
| `manuscript/main_quantitative_finance.tex` | `d57871c5e73002b12f0e052ca7853e00863107ee028be88c95592379d6b7ba97` |

---

## 📁 Repository File Tree

```
noise-resilient-encoding/
├── README.md                                  # Complete repository documentation
├── LICENSE                                    # MIT License (code) + CC-BY 4.0 (manuscript)
├── CITATION.cff                               # Citation metadata
├── requirements.txt                           # Frozen Python dependencies
├── reproduce_all.py                           # Master reproduction script
├── run_all.py                                 # Pipeline runner
│
├── python/                                    # Execution and analysis scripts
│   ├── 01_environment_check.py                # Environment verification
│   ├── 02_download_prepare_data.py            # Market data ingestion & causal indicator engineering
│   ├── 03_feature_engineering.py              # Statistical diagnostics & ADF tests
│   ├── 04_quantum_encoding.py                 # Circuit builders & OpenQASM 3.0 export
│   ├── 05_ideal_simulation.py                 # Ideal statevector benchmark
│   ├── 06_noise_models.py                     # 7-channel open-system Lindbladian noise sweeps
│   ├── 07_noise_mitigation.py                 # Linear ZNE, Richardson ZNE, and MEM
│   ├── 08_hardware_calibrated_simulation.py   # GenericBackendV2 simulation across q0-q3
│   ├── 08b_controlled_physics_experiments.py  # Depth ablations & synthetic distribution sweeps
│   ├── run_downstream_prediction.py           # Downstream forecasting & transaction friction backtests
│   ├── 12_generate_figures.py                 # Primary publication figures
│   ├── generate_qf_figures.py                 # Quantitative Finance publication figures (Figs 5–7)
│   ├── 13_generate_tables.py                  # Standalone table generators (LaTeX/CSV/Markdown)
│   ├── build_main_qf_manuscript.py            # Main manuscript LaTeX generator
│   ├── build_main_qf_markdown.py              # Main manuscript Markdown generator
│   ├── build_supplementary_quantitative_finance.py # Supplementary material generator
│   └── build_qf_submission_package.py         # Taylor & Francis package bundler
│
├── data/                                      # Empirical dataset files
│   ├── raw/                                   # Raw SPY daily prices (2015–2023)
│   └── processed/                             # Causal indicators (encoding_features.csv)
│
├── circuits/                                  # Quantum circuits
│   └── qasm/                                  # OpenQASM 3.0 definitions
│       ├── angle_encoding.qasm
│       ├── angle_encoding_entangled.qasm
│       └── iqp_feature_map.qasm
│
├── figures/                                   # High-resolution vector & raster figures
│   ├── pdf/                                   # Vector PDF format (fig01–fig07)
│   ├── png/                                   # 300 DPI raster PNG
│   └── eps/                                   # Vector EPS format
│
├── tables/                                    # Numerical tables (table1–table10 in CSV, MD, TEX)
│
├── manuscript/                                # Main submission documents
│   ├── main_quantitative_finance.tex         # Complete LaTeX source (27 pages, 0 overfull hboxes)
│   ├── main_quantitative_finance.pdf         # Compiled publication PDF
│   ├── main_quantitative_finance.md          # Full Markdown manuscript
│   ├── references.bib                         # Verified BibTeX references (including 2026 literature)
│   ├── cover_letter_quantitative_finance.tex  # Cover letter LaTeX source (3 pages, 0 overfull hboxes)
│   └── cover_letter_quantitative_finance.pdf  # Compiled cover letter PDF
│
├── supplementary/                             # Supplementary Information
│   ├── supplementary_quantitative_finance.tex # Supplementary LaTeX source (11 pages, 0 overfull hboxes)
│   ├── supplementary_quantitative_finance.pdf # Compiled Supplementary PDF
│   └── supplementary_quantitative_finance.md  # Supplementary Markdown companion
│
└── submission_package/                        # Submission bundle
    ├── Quantitative_Finance_Submission_Package.zip # Official uploadable ZIP bundle
    └── MANIFEST_SHA256.txt                    # Complete SHA-256 verification manifest
```

---

## 📜 Citation

If you find this benchmark or codebase useful in your research, please cite:

```bibtex
@article{Saleem2026QuantitativeFinance,
  author    = {Saleem, Shahrukh and Madbouly, Araby and Husain, Uvesh and Soorat, Ram and Priyanka and Rahman, Afzalur},
  title     = {Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction: A Hardware-Informed Benchmark},
  journal   = {Quantitative Finance},
  year      = {2026},
  note      = {Submitted, Taylor \& Francis}
}
```

---

## ⚖️ License

- **Computational Code, Scripts, and Algorithms:** [MIT License](LICENSE)
- **Manuscripts, Figures, and Supplementary Documentation:** [Creative Commons Attribution 4.0 International (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/)
