#!/usr/bin/env python3
"""
20_build_github_zip.py
======================
Builds a clean, publication-ready GitHub repository ZIP archive:
"quantum_finance_benchmark_github.zip"

Guarantees total archive size is strictly below 25.0 MB (GitHub web upload limit).
Includes full source code, datasets, figures (PNG/PDF/EPS), tables, manuscript,
supplementary material, documentation, and SHA-256 integrity manifest.
"""

import os
import sys
import hashlib
import zipfile

import shutil

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GITHUB_ZIP_PATH = os.path.join(ROOT, "quantum_finance_benchmark_github.zip")
ALT_ZIP_PATH = os.path.join(ROOT, "github_repository.zip")

SYNC_DIRS = [
    os.path.abspath(os.path.join(ROOT, "..", "..", "Quantitative_Finance")),
    os.path.abspath(os.path.join(ROOT, "..", "..")),
]

MAX_SIZE_BYTES = 25 * 1024 * 1024  # 25 MB hard limit

EXCLUDE_DIRS = {
    ".venv", "venv", ".git", "__pycache__", "brain", ".gemini",
    "scratch", ".system_generated", "submission_package"
}

EXCLUDE_EXTENSIONS = {
    ".pyc", ".pyo", ".tmp", ".log", ".aux", ".bbl", ".blg",
    ".synctex.gz", ".fls", ".fdb_latexmk", ".out", ".toc", ".zip"
}

EXCLUDE_FILES = {
    "Physical_Review_Applied_Quantum_Finance_Benchmark.zip",
    "quantum_finance_benchmark_github.zip",
    "github_repository.zip",
    "Quantitative_Finance_Submission_Package.zip",
    ".DS_Store", "Thumbs.db"
}


def compute_sha256(filepath):
    """Compute SHA-256 checksum."""
    h = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def build_github_zip():
    print("=" * 70)
    print("BUILDING CLEAN GITHUB REPOSITORY ZIP ARCHIVE (MAX 25 MB)")
    print("=" * 70)

    # Collect all eligible files
    eligible_files = []
    for root, dirs, files in os.walk(ROOT):
        # Prune excluded directories
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and not d.startswith('.')]

        for f in sorted(files):
            if f in EXCLUDE_FILES:
                continue
            if any(f.endswith(ext) for ext in EXCLUDE_EXTENSIONS):
                continue

            fpath = os.path.join(root, f)
            relpath = os.path.relpath(fpath, ROOT).replace("\\", "/")
            eligible_files.append((fpath, relpath))

    print(f"Collected {len(eligible_files)} files to package.")

    # Generate in-memory SHA256 manifest
    manifest_lines = []
    for fpath, relpath in eligible_files:
        sha = compute_sha256(fpath)
        manifest_lines.append(f"{sha}  {relpath}\n")

    manifest_content = "".join(sorted(manifest_lines))

    # Write ZIP archives (both standard named targets)
    for zip_target in [GITHUB_ZIP_PATH, ALT_ZIP_PATH]:
        with zipfile.ZipFile(zip_target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            for fpath, relpath in eligible_files:
                zf.write(fpath, arcname=relpath)
            # Add manifest
            zf.writestr("CHECKSUMS_GITHUB.sha256", manifest_content)

        size_bytes = os.path.getsize(zip_target)
        size_mb = size_bytes / (1024 * 1024)
        print(f"\n[OK] Created: {os.path.basename(zip_target)}")
        print(f"     File size: {size_bytes:,} bytes ({size_mb:.2f} MB)")
        print(f"     Max limit: {MAX_SIZE_BYTES:,} bytes (25.00 MB)")

        if size_bytes < MAX_SIZE_BYTES:
            margin_mb = (MAX_SIZE_BYTES - size_bytes) / (1024 * 1024)
            print(f"     Status: STRICTLY UNDER 25 MB (Safety margin: {margin_mb:.2f} MB)")
        else:
            print(f"     [ERROR] Archive exceeds 25 MB limit!")
            sys.exit(1)

        target_sha = compute_sha256(zip_target)
        print(f"     SHA-256:   {target_sha}")

        # Synchronize to target directories
        for sdir in SYNC_DIRS:
            if os.path.exists(sdir):
                dest_file = os.path.join(sdir, os.path.basename(zip_target))
                shutil.copy2(zip_target, dest_file)
                print(f"     -> Synchronized to: {dest_file}")

    print("\n" + "=" * 70)
    print("GITHUB ZIP BUILD COMPLETE AND VERIFIED")
    print("=" * 70)


if __name__ == "__main__":
    build_github_zip()
