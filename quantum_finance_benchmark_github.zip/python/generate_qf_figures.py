#!/usr/bin/env python3
"""
generate_qf_figures.py
======================
Generates high-resolution publication-quality figures specifically aligned with
Quantitative Finance (Taylor & Francis) requirements:
  - Figure 6: Out-of-sample directional forecasting performance, ROC-AUC, and
              transaction-cost friction Sharpe decay curves across classical and quantum models.
  - Figure 7: Financial indicator dynamics over the 2023 calendar trading year
              (strictly terminating at 2023-12-31 without a 2024 tick) and encoding robustness
              across empirical SPY and synthetic distributions.
"""

import os
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG_DIR = os.path.join(ROOT, "figures", "pdf")
os.makedirs(FIG_DIR, exist_ok=True)

# Publication styling
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 11
plt.rcParams['xtick.labelsize'] = 9.5
plt.rcParams['ytick.labelsize'] = 9.5
plt.rcParams['legend.fontsize'] = 9.5
plt.rcParams['figure.titlesize'] = 12
plt.rcParams['lines.linewidth'] = 1.6
plt.rcParams['grid.alpha'] = 0.35
plt.rcParams['grid.linestyle'] = '--'

def generate_figure_6():
    """
    Figure 6: Out-of-Sample Forecasting Comparison & Economic Friction Sensitivity
    Panel (a): Directional Accuracy (%) with 95% Bootstrap CI.
    Panel (b): ROC-AUC with 95% Bootstrap CI.
    Panel (c): Net Sharpe Ratio across transaction friction (0, 5, 10, 20 bps).
    """
    models = [
        "Logistic Reg.",
        "SVM (RBF)",
        "Random Forest",
        "QSVM (AE Noisy)",
        "QSVM (AE ZNE)",
        "QSVM (AE+ENT)",
        "QSVM (IQP Noisy)"
    ]
    
    # Accuracy and 95% CIs from Table 7
    acc = np.array([51.33, 51.33, 51.60, 52.13, 52.13, 50.80, 53.99])
    acc_err_low = acc - np.array([46.5, 46.5, 46.8, 47.3, 47.3, 45.9, 49.1])
    acc_err_high = np.array([56.1, 56.1, 56.4, 56.9, 56.9, 55.7, 58.8]) - acc
    
    # ROC-AUC and 95% CIs from Table 7
    auc = np.array([0.5191, 0.4613, 0.4896, 0.4380, 0.4371, 0.4413, 0.4381])
    auc_err_low = auc - np.array([0.4607, 0.4047, 0.4294, 0.3814, 0.3806, 0.3876, 0.3850])
    auc_err_high = np.array([0.5787, 0.5232, 0.5440, 0.4955, 0.4941, 0.4988, 0.4950]) - auc
    
    # Economic Sharpe at 0, 5, 10, 20 bps from Table 8
    frictions = np.array([0, 5, 10, 20])
    sharpes = {
        "Passive SPY": [1.04, 1.04, 1.04, 1.04],
        "Logistic Reg.": [1.04, 1.04, 1.04, 1.03],
        "Random Forest": [1.07, 0.98, 0.90, 0.73],
        "QSVM (AE Noisy)": [1.17, 1.15, 1.13, 1.09],
        "QSVM (IQP Noisy)": [1.28, 1.18, 1.07, 0.86],
    }
    
    fig = plt.figure(figsize=(14, 4.6), constrained_layout=True)
    gs = fig.add_gridspec(1, 3, width_ratios=[1.1, 1.1, 1.2])
    
    # Panel a: Directional Accuracy
    ax0 = fig.add_subplot(gs[0, 0])
    y_pos = np.arange(len(models))
    colors = ['#4477AA', '#4477AA', '#4477AA', '#228833', '#66CCEE', '#EE6677', '#AA3377']
    
    ax0.errorbar(acc, y_pos, xerr=[acc_err_low, acc_err_high], fmt='o', color='black',
                 ecolor='gray', elinewidth=1.5, capsize=3.5, zorder=3)
    ax0.scatter(acc, y_pos, c=colors, s=70, zorder=4, edgecolor='black', linewidth=0.8)
    ax0.axvline(50.0, color='gray', linestyle=':', linewidth=1.2, label='Random Guess (50%)')
    ax0.axvline(53.68, color='darkred', linestyle='--', linewidth=1.2, label='Prevailing Trend (53.7%)')
    ax0.set_yticks(y_pos)
    ax0.set_yticklabels(models)
    ax0.invert_yaxis()
    ax0.set_xlabel('Directional Accuracy (%)')
    ax0.set_title('(a) Out-of-Sample Accuracy ($N = 376$)', fontweight='bold')
    ax0.set_xlim(44.0, 60.0)
    ax0.grid(True)
    ax0.legend(loc='lower left', framealpha=0.9, fontsize=8.5)
    
    # Panel b: ROC-AUC
    ax1 = fig.add_subplot(gs[0, 1])
    ax1.errorbar(auc, y_pos, xerr=[auc_err_low, auc_err_high], fmt='s', color='black',
                 ecolor='gray', elinewidth=1.5, capsize=3.5, zorder=3)
    ax1.scatter(auc, y_pos, c=colors, s=70, zorder=4, edgecolor='black', linewidth=0.8, marker='s')
    ax1.axvline(0.50, color='gray', linestyle=':', linewidth=1.2, label='Uninformative (0.50)')
    ax1.set_yticks(y_pos)
    ax1.set_yticklabels([])
    ax1.invert_yaxis()
    ax1.set_xlabel('Area Under ROC Curve (ROC-AUC)')
    ax1.set_title('(b) Ranking Discriminability (ROC-AUC)', fontweight='bold')
    ax1.set_xlim(0.35, 0.62)
    ax1.grid(True)
    ax1.legend(loc='lower left', framealpha=0.9, fontsize=8.5)
    
    # Panel c: Transaction Friction Decay
    ax2 = fig.add_subplot(gs[0, 2])
    style_dict = {
        "Passive SPY": ('black', ':', 'o'),
        "Logistic Reg.": ('#4477AA', '--', '^'),
        "Random Forest": ('#EE6677', '-.', 's'),
        "QSVM (AE Noisy)": ('#228833', '-', 'D'),
        "QSVM (IQP Noisy)": ('#AA3377', '-', 'v'),
    }
    
    for name, s_vals in sharpes.items():
        col, ls, m = style_dict[name]
        ax2.plot(frictions, s_vals, color=col, linestyle=ls, marker=m,
                 markersize=6, linewidth=1.8, label=name)
        
    ax2.set_xlabel('Transaction Cost Friction (basis points)')
    ax2.set_ylabel('Annualized Net Sharpe Ratio')
    ax2.set_title('(c) Friction Sensitivity & Sharpe Decay', fontweight='bold')
    ax2.set_xticks([0, 5, 10, 20])
    ax2.set_xlim(-1, 21)
    ax2.set_ylim(0.65, 1.35)
    ax2.grid(True)
    ax2.legend(loc='upper right', framealpha=0.9, fontsize=8.5)
    
    out_path = os.path.join(FIG_DIR, "fig06_forecasting_performance.pdf")
    plt.savefig(out_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Generated Figure 6: {out_path}")

def generate_figure_7():
    """
    Figure 7: Financial indicator dynamics over 2023 (strictly terminating at 2023-12-31)
    and encoding robustness across empirical SPY and synthetic distributions.
    """
    enc_path = os.path.join(ROOT, "data", "processed", "all_features.csv")
    dist_path = os.path.join(ROOT, "results", "distribution_sensitivity.csv")
    
    fig, axes = plt.subplots(2, 1, figsize=(11, 7.5), constrained_layout=True)
    
    # Panel a: 2023 SPY Indicators strictly constrained to 2023-12-31
    ax0 = axes[0]
    if os.path.exists(enc_path):
        df = pd.read_csv(enc_path, index_col=0, parse_dates=True)
        # Select 2023 trading year strictly
        df_2023 = df.loc['2023-01-01':'2023-12-31']
        
        features = ["close_normalized", "rsi_14", "macd_signal", "bollinger_pct_b"]
        feat_labels = ["Normalized Close ($x_0$)", "RSI 14-day ($x_1$)", "MACD Signal ($x_2$)", "Bollinger %B ($x_3$)"]
        colors = ['#4477AA', '#228833', '#EE6677', '#CCBB44']
        
        for feat, lab, c in zip(features, feat_labels, colors):
            if feat in df_2023.columns:
                ax0.plot(df_2023.index, df_2023[feat], label=lab, color=c, lw=1.5)
                
        ax0.set_ylabel("Normalized Feature Value $\\in [0, 1]$", fontsize=10.5)
        ax0.set_title("(a) SPY Causal Indicator Dynamics Across 2023 Trading Sessions ($N = 250$)", fontsize=11, fontweight='bold')
        ax0.legend(frameon=True, ncol=4, loc='upper center', bbox_to_anchor=(0.5, 1.15), framealpha=0.9, fontsize=9)
        ax0.set_ylim(-0.05, 1.05)
        
        # Strict date formatting terminating strictly at December 2023
        ax0.set_xlim(pd.Timestamp('2023-01-01'), pd.Timestamp('2023-12-31'))
        ax0.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
        ax0.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
        ax0.grid(True)
        
    # Panel b: Distribution sensitivity comparison
    ax1 = axes[1]
    if os.path.exists(dist_path):
        df_dist = pd.read_csv(dist_path)
        dists = df_dist["distribution"].unique()
        clean_dists = ["Empirical SPY", "Uniform $\\mathcal{U}(0,1)$", "Standard Gaussian $\\mathcal{N}(0,1)$", "Correlated Gaussian"]
        x = np.arange(len(dists))
        width = 0.25
        
        ae_vals = [df_dist[(df_dist["distribution"] == d) & (df_dist["encoding"] == "angle_encoding")]["mean_fidelity_FQ"].values[0] for d in dists]
        aee_vals = [df_dist[(df_dist["distribution"] == d) & (df_dist["encoding"] == "angle_encoding_entangled")]["mean_fidelity_FQ"].values[0] for d in dists]
        iqp_vals = [df_dist[(df_dist["distribution"] == d) & (df_dist["encoding"] == "iqp_feature_map")]["mean_fidelity_FQ"].values[0] for d in dists]
        
        ax1.bar(x - width, ae_vals, width, label='Angle Encoding (AE, 0 CX)', color='#4477AA', alpha=0.9, edgecolor='black', linewidth=0.6)
        ax1.bar(x, aee_vals, width, label='AE + Entanglement (AE+ENT, 3 CX)', color='#EE6677', alpha=0.9, edgecolor='black', linewidth=0.6)
        ax1.bar(x + width, iqp_vals, width, label='IQP Feature Map (6 CX)', color='#228833', alpha=0.9, edgecolor='black', linewidth=0.6)
        
        ax1.set_xticks(x)
        ax1.set_xticklabels(clean_dists, fontsize=10)
        ax1.set_ylabel("True Quantum State Fidelity $\\mathcal{F}_Q$", fontsize=10.5)
        ax1.set_title("(b) State Fidelity Robustness Across Empirical vs. Synthetic Input Distributions", fontsize=11, fontweight='bold')
        ax1.legend(frameon=True, loc='lower left', framealpha=0.9, fontsize=9)
        ax1.set_ylim(0.92, 1.008)
        ax1.grid(True, axis='y')
        
    out_path = os.path.join(FIG_DIR, "fig07_financial_distribution_robustness.pdf")
    plt.savefig(out_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Generated Figure 7: {out_path}")

def generate_figure_5():
    """
    Figure 5: Error mitigation benchmark plotting observable distortion (1 - S_Z) * 10^5.
    Directly reconciles with Table 5, illustrating the finite-sample variance amplification
    of two-point Richardson extrapolation across AE, AE+ENT, and IQP.
    """
    fig, ax = plt.subplots(figsize=(9, 5.0), constrained_layout=True)
    conditions = [
        "Noisy (Unmitigated)\n$\\lambda = 1$",
        "Linear ZNE\n$\\lambda \\in \\{1, 2\\}$",
        "Richardson ZNE\n$\\lambda \\in \\{1, 3\\}$",
        "MEM\n(Readout Inv.)"
    ]
    
    # Observable distortion (1 - S_Z) * 1e5 from Table 5
    ae_dist = np.array([3.0, 2.4, 4.3, 2.8])
    aee_dist = np.array([4.2, 3.5, 5.8, 4.0])
    iqp_dist = np.array([17.6, 15.9, 20.2, 17.0])
    
    x = np.arange(len(conditions))
    width = 0.26
    
    rects1 = ax.bar(x - width, ae_dist, width, label='Angle Encoding (AE, 0 CX)',
                    color='#4477AA', edgecolor='black', linewidth=0.7, alpha=0.9)
    rects2 = ax.bar(x, aee_dist, width, label='AE + Entanglement (AE+ENT, 3 CX)',
                    color='#EE6677', edgecolor='black', linewidth=0.7, alpha=0.9)
    rects3 = ax.bar(x + width, iqp_dist, width, label='IQP Feature Map (6 CX)',
                    color='#228833', edgecolor='black', linewidth=0.7, alpha=0.9)
    
    # Value annotations on top of bars
    for rects, color in zip([rects1, rects2, rects3], ['#4477AA', '#EE6677', '#228833']):
        for rect in rects:
            height = rect.get_height()
            ax.annotate(f'{height:.1f}',
                        xy=(rect.get_x() + rect.get_width() / 2, height),
                        xytext=(0, 3), textcoords="offset points",
                        ha='center', va='bottom', fontsize=8.5, fontweight='bold', color=color)
            
    # Highlight Richardson Variance Amplification
    ax.annotate('2.5× Variance Amplification\nInflates Observable Distortion',
                xy=(2, 20.2), xytext=(1.5, 23.0),
                arrowprops=dict(facecolor='darkred', arrowstyle='->', lw=1.5),
                ha='center', fontsize=9, fontweight='bold', color='darkred',
                bbox=dict(boxstyle='round,pad=0.4', facecolor='#FFF3CD', edgecolor='darkred', alpha=0.9))
    
    ax.set_ylabel("Observable Distortion $(1 - S_Z) \\times 10^{-5}$", fontsize=11)
    ax.set_title("Observable-Level Error Mitigation Performance (8,192 Shots)", fontsize=11.5, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(conditions, fontsize=10)
    ax.set_ylim(0, 26.5)
    ax.grid(True, axis='y', linestyle='--', alpha=0.4)
    ax.legend(frameon=True, loc='upper left', framealpha=0.9, fontsize=9.5)
    
    out_pdf = os.path.join(FIG_DIR, "fig09_mitigation_performance.pdf")
    png_dir = os.path.join(ROOT, "figures", "png")
    os.makedirs(png_dir, exist_ok=True)
    out_png = os.path.join(png_dir, "fig09_mitigation_performance.png")
    
    plt.savefig(out_pdf, dpi=300, bbox_inches='tight')
    plt.savefig(out_png, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Generated Figure 5 (fig09_mitigation_performance): {out_pdf}")

if __name__ == "__main__":
    generate_figure_5()
    generate_figure_6()
    generate_figure_7()
    print("Quantitative Finance figures generation complete.")
