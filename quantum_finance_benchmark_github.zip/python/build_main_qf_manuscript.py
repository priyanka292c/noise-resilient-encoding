"""
build_main_qf_manuscript.py
===========================
Generates the comprehensive, submission-ready LaTeX manuscript for:
Journal: Quantitative Finance (Taylor & Francis)
Title: Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction: A Hardware-Informed Benchmark
"""

import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEX_PATH = os.path.join(ROOT, "manuscript", "main_quantitative_finance.tex")

content = r"""% =========================================================================
% main_quantitative_finance.tex
% Target Journal: Quantitative Finance (Taylor & Francis)
% ISSN: 1469-7688 / Online ISSN: 1469-7696
%
% Title: Noise-Resilient Quantum Feature Encoding for Financial Time-Series
%        Prediction: A Hardware-Informed Benchmark
%
% Authors: S. Saleem, A. Madbouly, U. Husain, R. Soorat, Priyanka, and A. Rahman
% =========================================================================

\documentclass[11pt,a4paper]{article}

\usepackage[utf8]{inputenc}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb,amsfonts}
\usepackage{bm}
\usepackage{booktabs}
\usepackage{multirow}
\usepackage{dcolumn}
\usepackage{siunitx}
\usepackage{xcolor}
\usepackage{url}
\usepackage{graphicx}
\usepackage[font=small,labelfont=bf,skip=10pt]{caption}
\usepackage[numbers,sort&compress]{natbib}
\usepackage[colorlinks=true,linkcolor=blue,citecolor=blue,urlcolor=blue]{hyperref}

% Accessible color scheme
\definecolor{qfblue}{RGB}{0,85,160}
\definecolor{idealblue}{HTML}{4477AA}
\definecolor{noisered}{HTML}{EE6677}
\definecolor{hwgreen}{HTML}{228833}
\definecolor{mitorange}{HTML}{CCBB44}

% Custom macros
\newcommand{\FQ}{\mathcal{F}_Q}
\newcommand{\SZ}{S_Z}
\newcommand{\DeltaZ}{\Delta Z}
\newcommand{\AEenc}{\ensuremath{\text{\textsc{ae}}}}
\newcommand{\AEE}{\ensuremath{\text{\textsc{ae+ent}}}}
\newcommand{\IQP}{\ensuremath{\text{\textsc{iqp}}}}
\newcommand{\ZNE}{\ensuremath{\text{\textsc{zne}}}}
\newcommand{\MEM}{\ensuremath{\text{\textsc{mem}}}}
\newcommand{\SPY}{\texttt{SPY}}
\newcommand{\NISQ}{\ensuremath{\text{\textsc{nisq}}}}
\providecommand{\Tr}{\operatorname{Tr}}
\providecommand{\bra}[1]{\langle#1|}
\providecommand{\ket}[1]{|#1\rangle}

\setlength{\parindent}{0pt}
\setlength{\parskip}{6pt}

\title{\textbf{\Large Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction: A Hardware-Informed Benchmark}}

\author{
  \parbox{\dimexpr\textwidth-2\tabcolsep\relax}{\centering
    \textbf{Shahrukh Saleem}$^1$, 
    \textbf{Araby Madbouly}$^2$, 
    \textbf{Uvesh Husain}$^3$, 
    \textbf{Ram Soorat}$^{4,*}$, 
    \textbf{Priyanka}$^5$, 
    \textbf{Afzalur Rahman}$^6$ \\[0.5em]
    \small
    $^1$VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India \\[0.15em]
    $^2$Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman \\[0.15em]
    $^3$Economics and Business Studies Department, Mazoon College, Muscat, Oman \\[0.15em]
    $^4$School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India \\[0.15em]
    $^5$Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India \\[0.15em]
    $^6$School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India \\[0.25em]
    $^*$Corresponding Author. Email: \texttt{ram.soorat@woxsen.edu.in}
  }
}

\date{October 29, 2026}

\begin{document}

\maketitle

\begin{abstract}
Quantum feature maps offer expressive representations for non-linear financial time series, but their practical utility on Noisy Intermediate-Scale Quantum (\NISQ{}) processors is constrained by decoherence and gate infidelities. Using daily S\&P 500 ETF (\SPY{}) data from 2015--2023 (2,013 valid trading days), we present a hardware-informed benchmark of four-qubit Angle Encoding (\AEenc{}), Angle Encoding with Entanglement (\AEE{}), and Instantaneous Quantum Polynomial (\IQP{}) circuits under isolated noise channels and a hardware-informed superconducting-transmon noise model. We find a clear expressivity--robustness trade-off: two-qubit entangling gates reduce Uhlmann state fidelity from 0.9989 for \AEenc{} to 0.9609 for \AEE{} and 0.9257 for \IQP{}, while marginal $Z$-observable agreement remains above 0.9998. Under finite-shot sampling (8,192 shots), two-point Richardson zero-noise extrapolation amplifies measurement variance by $2.5\times$ and fails to improve observable agreement. In next-day directional forecasting, quantum kernel support vector machines achieve 50.8\%--54.0\% accuracy, with Diebold--Mariano tests showing no statistically significant outperformance over the linear baseline ($p > 0.07$). Transaction costs substantially reduce the Sharpe ratios of high-turnover quantum strategies. These results show that state preservation is important for quantum financial representations but does not by itself guarantee predictive or economic advantage.
\end{abstract}

\textbf{Keywords:} Quantitative finance; Quantum machine learning; Quantum feature encoding; Financial time-series prediction; NISQ computing; Noise resilience; Error mitigation; Zero-noise extrapolation; Kernel methods.

\textbf{JEL Classifications:} C45, C53, C58, G11, G14.

\newpage

% =========================================================================
% 1. INTRODUCTION
% =========================================================================
\section{Introduction}
\label{sec:intro}

\subsection{Financial Time-Series Prediction and Quantitative Modelling}
Predicting asset price dynamics, volatility regimes, and market direction remains one of the central challenges in quantitative finance, empirical asset pricing, and systemic risk management \cite{Cont2001,Gu2020}. Financial time series present unique econometric difficulties: low signal-to-noise ratios, non-stationarity, regime shifts, heavy-tailed return distributions, and complex non-linear interactions among technical, fundamental, and macroeconomic indicators \cite{Fama1970,Engle1982}. In classical econometrics and financial machine learning, researchers have sought to overcome these challenges by projecting raw price histories and technical indicators into higher-dimensional representations where non-linear patterns may become linearly separable \cite{Hastie2009,Dixon2020}.

Kernel-based methods, such as Support Vector Machines (SVM) and Kernel Ridge Regression, have long been utilized to capture non-linear market dependencies without explicitly computing high-dimensional coordinates \cite{Scholkopf2002,Kim2003,Huang2005}. However, classical kernels (e.g., Gaussian Radial Basis Functions or polynomial kernels) are constrained by fixed mathematical geometries and can suffer from computational bottlenecks or the curse of dimensionality when scaling to complex multi-factor distributions \cite{Gu2020,Chen2026}. Consequently, quantitative researchers have increasingly examined non-classical computing paradigms to assess whether quantum mechanical principles can provide more expressive representations of financial data.

\subsection{Quantum Machine Learning in Finance}
Quantum Machine Learning (QML) represents a growing interdisciplinary field at the intersection of computational physics, computer science, and mathematical finance \cite{Biamonte2017,Orus2019,Egger2020}. Within quantitative finance, proposed quantum applications span three major domains: combinatorial portfolio optimization via variational quantum algorithms \cite{Brandhofer2023,Buonaiuto2023,Carrascal2024,Olowoyo2026,Wu2026}, derivative valuation and risk estimation via quantum amplitude estimation \cite{Woerner2019,Stamatopoulos2020,Martin2021,Li2026}, and non-linear market forecasting via Quantum Neural Networks (QNN) and Quantum Kernel Methods (QKM) \cite{Rebentrost2018,Herman2023,Naik2025}.

Central to quantum learning is the \textit{quantum feature map} $\Phi: \mathbf{x} \mapsto |\Phi(\mathbf{x})\rangle\langle\Phi(\mathbf{x})|$, which embeds a classical feature vector $\mathbf{x} \in \mathbb{R}^d$ into the state space of an $n$-qubit quantum system---a complex projective Hilbert space $\mathbb{C}^{2^n}$ of dimension $2^n$ \cite{Havlicek2019,Schuld2019}. By engineering multi-qubit entangling gates, quantum circuits can generate quantum kernels:
\begin{equation}
  k(\mathbf{x}, \mathbf{x}') = |\langle\Phi(\mathbf{x})|\Phi(\mathbf{x}')\rangle|^2 = \Tr\left[\rho(\mathbf{x})\rho(\mathbf{x}')\right]
\end{equation}
which cannot be efficiently estimated on classical computers under plausible computational complexity assumptions \cite{Bremner2016,Liu2021}.

\subsection{Hardware Noise in Quantum Financial Modelling}
Despite the theoretical appeal of exponentially large Hilbert spaces, practical quantum computing is severely constrained by the physical realities of the Noisy Intermediate-Scale Quantum (\NISQ{}) era \cite{Preskill2018,Bharti2022}. Near-term quantum processors lack fault-tolerant quantum error correction and are subject to multiple physical noise sources:
\begin{enumerate}
    \item \textbf{Environmental Decoherence:} Longitudinal energy relaxation ($T_1$) and transverse dephasing ($T_2$), which cause quantum superpositions to decay toward thermal equilibrium \cite{Krantz2019,Devoret2013}.
    \item \textbf{Coherent and Stochastic Gate Infidelities:} Control pulse imperfections and imperfect Hamiltonian dynamics that induce depolarizing transitions and systematic phase errors. Crucially, two-qubit entangling operations (e.g., CNOT gates) typically exhibit error rates 5 to 20 times higher than single-qubit rotations \cite{Blais2021}.
    \item \textbf{Measurement Readout Errors:} Inefficiencies in quantum state discrimination where measurement apparatuses introduce classical bit-flip confusion during the readout stage \cite{Maciejewski2020}.
\end{enumerate}

When financial data are mapped into a quantum processor, physical noise acts as an irreversible quantum channel $\mathcal{E}$, transforming the intended pure state $\rho(\mathbf{x}) = |\Phi(\mathbf{x})\rangle\langle\Phi(\mathbf{x})|$ into a mixed state $\rho_{\text{noisy}}(\mathbf{x}) = \mathcal{E}(\rho(\mathbf{x}))$. As noise accumulates with increasing circuit depth and entangling gate density, the state distribution contracts toward the maximally mixed state $I/2^n$, diminishing the geometric separability of the feature space and corrupting the encoded financial signals.

\subsection{Research Gap}
Although recent literature has explored quantum computing concepts for financial use cases \cite{Orus2019,Egger2020,Herman2023,Naik2025}, significant gaps remain between theoretical quantum circuit design and empirical financial econometrics:
\begin{itemize}
    \item \textbf{Lack of Hardware-Informed Financial Benchmarking:} The majority of existing quantum finance studies evaluate algorithms under ideal, noiseless conditions or simple toy distributions, providing little empirical evidence regarding how realistic hardware noise channels affect financial representations.
    \item \textbf{Conflation of Marginal Agreement with State Preservation:} Prior benchmarks have frequently relied on single-qubit marginal expectation agreement, which can mask severe multi-qubit entanglement and phase corruption.
    \item \textbf{Unexamined Error Mitigation Under Finite Shots:} Quantum error mitigation techniques---such as Zero-Noise Extrapolation (\ZNE{})---are often treated as universal solutions without investigating whether higher-order extrapolation amplifies sampling variance under realistic shot budgets.
    \item \textbf{Absence of Downstream Predictive and Economic Evaluation:} Circuit-level fidelity studies rarely connect representation robustness to downstream out-of-sample directional prediction, statistical significance testing, and transaction-cost-adjusted economic performance.
\end{itemize}

\subsection{Research Questions}
To address these gaps, this study investigates five explicit research questions:
\begin{itemize}
    \item \textbf{RQ1:} How sensitive are different quantum feature encoding architectures (Angle Encoding, Angle Encoding with Entanglement, and Instantaneous Quantum Polynomial maps) to isolated physical noise channels when encoding empirical financial indicators?
    \item \textbf{RQ2:} How do circuit depth and two-qubit entangling gates govern the rate of quantum state degradation under realistic superconducting transmon noise?
    \item \textbf{RQ3:} Can quantum error mitigation methods (Linear \ZNE{}, Richardson \ZNE{}, and \MEM{}) recover uncorrupted expectation values, or does polynomial extrapolation introduce detrimental sampling variance?
    \item \textbf{RQ4:} Does representation-level noise resilience translate into improved downstream financial directional forecasting accuracy when compared to standard classical machine learning baselines?
    \item \textbf{RQ5:} Are observed performance differentials economically meaningful and resilient after accounting for trading friction and transaction costs?
\end{itemize}

\subsection{Positioning Statement and Summary of Scientific Contributions}
The objective of this investigation is not to demonstrate quantum advantage, but to determine whether currently accessible quantum representations retain sufficient information under realistic hardware-informed noise to justify their use in quantitative financial learning. Grounded entirely in empirical evidence, this paper presents the following contributions:
\begin{enumerate}
    \item \textbf{Reproducible Financial Time-Series Benchmark:} We construct a clean, leak-free empirical dataset using daily S\&P 500 ETF (\SPY{}) data from 2015 to 2023 ($2,013$ valid trading days) with eight financial indicators and strict chronological walk-forward boundaries.
    \item \textbf{Systematic Encoding Architecture Comparison:} We benchmark three distinct quantum feature maps (\AEenc{}, \AEE{}, and \IQP{}), demonstrating that non-entangled \AEenc{} maintains near-perfect fidelity ($\FQ = 0.9989 \pm 0.0002$), while entangling maps suffer substantial state corruption ($\FQ = 0.9609$ for \AEE{} and $\FQ = 0.9257$ for \IQP{}).
    \item \textbf{Multi-Channel Physical Noise Decomposition:} We isolate the degradation caused by seven physical noise channels alongside a hardware-informed transmon noise model (\texttt{GenericBackendV2}), showing that within the tested configurations, two-qubit entangling gates account for the dominant share of observed state infidelity.
    \item \textbf{Mathematical and Numerical Audit of Error Mitigation:} We provide an analytical and empirical assessment of finite-shot variance amplification in two-point Richardson \ZNE{}, demonstrating that Richardson extrapolation amplifies finite-sample measurement variance by $2.5\times$ under independent equal-variance sampling, which degrades observable accuracy in realistic finite-shot regimes.
    \item \textbf{Downstream Financial Forecasting and Economic Evaluation:} We benchmark Quantum Kernel SVMs against classical models (Logistic Regression, Support Vector Machines, and Random Forests), evaluating directional accuracy, ROC-AUC with 95\% bootstrap confidence intervals, Diebold--Mariano forecast error tests, and transaction-cost-adjusted backtesting across friction tiers ($0, 5, 10, 20\,\text{bps}$).
    \item \textbf{Characterization of the Expressivity-Robustness Trade-Off:} We find that within the tested configurations, while complex entangling feature maps offer greater theoretical expressivity, their vulnerability to physical noise diminishes representational quality compared to shallow, noise-resilient product-state encodings for near-term quantitative finance applications.
\end{enumerate}

% =========================================================================
% 2. LITERATURE REVIEW AND RESEARCH GAP
% =========================================================================

\begin{figure}[t!]
\centering
\includegraphics[width=0.90\textwidth]{../figures/pdf/fig01_workflow.pdf}
\vspace{6pt}
\caption{\textbf{End-to-end quantitative finance research framework and computational workflow.} 
\textbf{(a)} Daily SPDR S\&P 500 ETF (\SPY{}) market data ingestion spanning 2015--2023 ($T = 2,013$ valid trading sessions), chronologically partitioned into in-sample calibration (2015--2021) and out-of-sample holdout (2022--2023) periods. 
\textbf{(b)} Empirical probability densities of the four engineered causal technical indicators ($x_0$: Normalized Close, $x_1$: RSI-14, $x_2$: MACD Signal, $x_3$: Bollinger \%B). 
\textbf{(c)} Four-qubit quantum feature map architectures: separable Angle Encoding (\AEenc{}, depth $d=1$, 0 CX), Angle Encoding with Linear Entanglement (\AEE{}, depth $d=5$, 3 CX), and Instantaneous Quantum Polynomial (\IQP{}, depth $d=13$, 6 CX). 
\textbf{(d)} Microscopic hardware-informed transmon noise modeling based on Qiskit's \texttt{GenericBackendV2} (mean $T_1 = 166.5\,\mu\text{s}$, $T_2 = 150.3\,\mu\text{s}$, $\tau_{1Q} = 35\,\text{ns}$, $\tau_{2Q} = 280\,\text{ns}$). 
\textbf{(e)} Quantum error mitigation via Linear and two-point Richardson Zero-Noise Extrapolation (\ZNE{}) and Measurement Error Mitigation (\MEM{}). 
\textbf{(f)} Multi-metric verification exposing the divergence between genuine Uhlmann state fidelity $\FQ$ and marginal observable agreement $\SZ$, demonstrating that single-qubit marginals mask multi-qubit phase corruption.\label{fig:workflow}}
\end{figure}

\section{Literature Review and Research Gap}
\label{sec:literature}

\subsection{Quantum Machine Learning in Finance}
Quantum machine learning in finance has progressed from initial theoretical formulations to numerical proof-of-concept demonstrations \cite{Biamonte2017,Orus2019,Egger2020}. Early work by Rebentrost \textit{et al.} \cite{Rebentrost2014} demonstrated that quantum support vector machines can theoretically achieve logarithmic complexity scaling $\mathcal{O}(\log(N d))$ in dataset size $N$ and dimension $d$, assuming quantum random access memory (QRAM). However, physical QRAM architectures remain unavailable on NISQ devices. Consequently, modern NISQ QML focuses on parameterized quantum circuits (PQCs) and quantum kernel methods, which execute shallow circuits on classical data mapped into quantum states \cite{Mitarai2018,Cerezo2021,Schuld2021}.

In financial contexts, quantum kernels and neural networks have been applied to credit scoring \cite{Pistoia2021}, fraud detection \cite{Herman2023}, algorithmic trading \cite{Carrascal2024}, and portfolio selection \cite{Buonaiuto2023,Olowoyo2026,Wu2026}. Recent surveys, benchmarking analyses, and technical reviews on quantum computational finance \cite{Jacquier2022,Vaidya2024,Doosti2024,Hlatshwayo2026,AbuZitar2026,Doosti2026,Muzzioli2026} emphasize that while quantum feature maps provide mathematically rich representations, empirical demonstrations of genuine quantum advantage on noisy real-world market datasets remain elusive. In particular, a comprehensive 2026 technical review by Hlatshwayo \textit{et al.} \cite{Hlatshwayo2026} highlights the persistent gap between proposed quantum-finance algorithms and practical near-term hardware utility, while empirical evaluations by Abu Zitar \textit{et al.} \cite{AbuZitar2026} document that quantum classifiers struggle to reliably outperform tuned classical baselines in noisy regimes. Furthermore, recent 2026 reviews by Doosti \textit{et al.} \cite{Doosti2026} and Muzzioli \textit{et al.} \cite{Muzzioli2026} emphasize that realistic hardware noise channels, barren plateaus, and verification hurdles must be systematically addressed to build trustworthy quantum artificial intelligence in financial engineering. These findings underscore the critical need for rigorous, hardware-informed benchmarking that explicitly decomposes microscopic physical noise channels and subjects quantum forecasts to strict econometric validation.

\subsection{Financial Time-Series Prediction}
Financial time-series forecasting has evolved from linear autoregressive specifications (ARIMA, GARCH) to sophisticated machine learning models capable of extracting non-linear indicator relationships \cite{Engle1982,Kim2003,Huang2005}. In a comprehensive empirical assessment of machine learning for asset pricing, Gu, Kelly, and Xiu \cite{Gu2020} demonstrated that non-linear architectures (specifically shallow neural networks and gradient-boosted decision trees) significantly outperform linear models by capturing interaction terms among technical indicators and macroeconomic state variables.

However, financial markets operate in a low signal-to-noise regime governed by the weak-form Efficient Market Hypothesis \cite{Fama1970}. Machine learning models frequently risk overfitting noise rather than true structural patterns \cite{Dixon2020,Harvey2016}. Ensuring robust out-of-sample performance requires leak-free chronological partitioning, expanding-window walk-forward validation, and rigorous accounting for market friction and transaction costs.

\subsection{Quantum Feature Maps}
A quantum feature map embeds a classical feature vector $\mathbf{x} \in \mathbb{R}^d$ into an $n$-qubit quantum state $|\Phi(\mathbf{x})\rangle = U_\Phi(\mathbf{x})|0\rangle^{\otimes n}$. Three primary encoding families dominate the literature:
\begin{enumerate}
    \item \textbf{Angle Encoding (AE):} Continuous features rotate individual qubits around designated axes:
    \begin{equation}
      |\psi_{\AEenc{}}(\mathbf{x})\rangle = \bigotimes_{i=1}^n R_x(\pi x_i)|0\rangle^{\otimes n}
    \end{equation}
    requiring circuit depth $\mathcal{O}(1)$ and zero two-qubit entangling gates \cite{LaRose2020}.
    \item \textbf{Angle Encoding with Entanglement (AE+ENT):} Alternates single-qubit rotations with two-qubit entangling gates (e.g., CNOT cascades), introducing non-local quantum correlations across feature coordinates \cite{Sim2019}.
    \item \textbf{Instantaneous Quantum Polynomial (IQP) Feature Maps:} Inspired by quantum supremacy protocols, IQP circuits apply Hadamard layers followed by diagonal phase rotations and nearest-neighbor entangling gates parameterized by continuous features and pairwise interactions \cite{Bremner2016,Havlicek2019}:
    \begin{equation}
      U_{\IQP{}}(\mathbf{x}) = \left(\bigotimes_{j=0}^{n-1} R_z(2 x_j)\right) H^{\otimes n} \left( \prod_{j=0}^{n-2} R_{ZZ}(2 x_j x_{j+1}) \right) \left(\bigotimes_{j=0}^{n-1} R_z(2 x_j)\right) H^{\otimes n}
    \end{equation}
    where each pairwise interaction $R_{ZZ}(2 x_j x_{j+1}) = \exp(-i x_j x_{j+1} Z_j Z_{j+1})$ is realized via a native $\text{CX}_{(j,j+1)} \cdot R_z(2 x_j x_{j+1}) \cdot \text{CX}_{(j,j+1)}$ sequence over linear nearest-neighbor pairs $(j, j+1) \in \{(0,1), (1,2), (2,3)\}$, requiring 6 CNOT gates in total. Sampling from ideal IQP output distributions is provably classically hard under standard complexity conjectures \cite{Bremner2016}.
\end{enumerate}

\subsection{Quantum Noise and Error Mitigation}
On physical quantum devices, environmental interactions and gate infidelities degrade pure states into mixed density operators via non-unitary operations \cite{Breuer2002,Krantz2019}. To combat noise without full fault tolerance, Quantum Error Mitigation (QEM) techniques have been developed \cite{Temme2017,Endo2018,Li2017,Cai2023}. Zero-Noise Extrapolation (\ZNE{}) artificially amplifies circuit noise by factors $\lambda \ge 1$ through unitary gate folding ($U \to U U^\dagger U$) and extrapolates expectation values back to the zero-noise limit $\lambda \to 0$ \cite{Kandala2019}. Measurement Error Mitigation (\MEM{}) constructs an empirical calibration matrix $\mathbf{A} \in \mathbb{R}^{2^n \times 2^n}$ to invert classical readout bit-flip errors \cite{Maciejewski2020}. However, existing theoretical studies warn that error mitigation incurs sampling overhead and may suffer from variance explosion \cite{Takagi2022,Li2026}.

\subsection{Research Gap Summary}
While quantum computing has been proposed for quantitative finance, systematic empirical evidence connecting quantum feature-map robustness under realistic hardware noise with financial learning and predictive utility remains limited. This study bridges that gap through a comprehensive, reproducible benchmark using real market data, hardware-informed simulation, and econometric evaluation.

% =========================================================================
% 3. DATA AND METHODOLOGY
% =========================================================================
\section{Data and Methodology}
\label{sec:methodology}

\subsection{Financial Dataset Description and Construction}
The empirical analysis uses daily market trading records for the SPDR S\&P 500 ETF Trust (Ticker: \SPY{}, traded on NYSE Arca), the most liquid equity exchange-traded fund in global financial markets. Historical market data spanning January 1, 2015, through December 31, 2023 ($2,264$ raw trading sessions) were retrieved via the Yahoo Finance API (\texttt{yfinance} v1.7.0) on January 15, 2024, calibrated in Eastern Standard/Daylight Time (US/Eastern). To account fully for cash dividend disbursements and historical corporate actions without introducing artificial return jumps, we construct all returns and volatility series from the daily Adjusted Close price $P_t$. Trading dates were verified against the official NYSE calendar, and no missing observations were identified within the analysis period. An initial warm-up window of 252 trading days (one calendar trading year) is allocated to ensure all rolling technical indicators stabilize, yielding an effective sample of $T = 2,013$ valid trading days ($2,012$ forward directional targets $y_{t+1}$).

\subsection{Data Preprocessing and Leakage Prevention}
To guarantee econometric validity and prevent data leakage:
\begin{enumerate}
    \item All technical indicators at time $t$ are constructed strictly using price information available at or before the market close of day $t$ ($\tau \le t$).
    \item Indicator normalization parameters (rolling minimums, maximums, and standard deviations) are computed over trailing historical windows, ensuring no future information enters historical representations.
    \item Chronological partitioning is strictly enforced, avoiding random train-test splitting that would introduce look-ahead bias \cite{Gu2020,Dixon2020}.
\end{enumerate}

\subsection{Financial Indicator Formulation}
To capture multi-scale market dynamics across price trend, momentum, volatility, and mean-reversion, we construct eight standard quantitative indicators:
\begin{enumerate}
    \item \textbf{Normalized Close ($x_{1,t}$):} 252-day rolling min-max scaling of the closing price:
    \begin{equation}
      x_{1,t} = \frac{C_t - \min_{\tau \in [t-251, t]} C_\tau}{\max_{\tau \in [t-251, t]} C_\tau - \min_{\tau \in [t-251, t]} C_\tau} \in [0, 1]
    \end{equation}
    reflecting intermediate-term price location.
    \item \textbf{Normalized Log Return ($x_{2,t}$):} 1-day logarithmic return scaled by 20-day trailing volatility and mapped to $[0, 1]$.
    \item \textbf{Historical Volatility ($x_{3,t}$):} 20-day annualized sample standard deviation of daily log returns:
    \begin{equation}
      \sigma_t^{(20)} = \sqrt{\frac{252}{19} \sum_{k=0}^{19} (r_{t-k} - \bar{r}_t)^2}
    \end{equation}
    normalized by its trailing 252-day historical range.
    \item \textbf{Relative Strength Index ($x_{4,t}$):} 14-day RSI measuring momentum:
    \begin{equation}
      \text{RSI}_t^{(14)} = 100 - \frac{100}{1 + \text{RS}_t}, \quad x_{4,t} = \frac{\text{RSI}_t^{(14)}}{100} \in [0, 1]
    \end{equation}
    \item \textbf{MACD Signal Difference ($x_{5,t}$):} The difference between the 12-day and 26-day Exponential Moving Averages (EMA) minus the 9-day signal line, normalized via logistic transformation into $[0, 1]$.
    \item \textbf{Momentum-10 ($x_{6,t}$):} 10-day price ratio $C_t / C_{t-10}$, capturing short-term momentum.
    \item \textbf{Moving Average Ratio ($x_{7,t}$):} Ratio of the 10-day and 50-day Simple Moving Averages ($\text{SMA}_{10} / \text{SMA}_{50}$), identifying moving average trend crossovers.
    \item \textbf{Bollinger Bands \%B ($x_{8,t}$):} Relative position of the close within a 20-day, $2\sigma$ Bollinger Band:
    \begin{equation}
      \%B_t = \frac{C_t - (\mu_t - 2\sigma_t)}{4\sigma_t}, \quad x_{8,t} = \operatorname{clip}(\%B_t, 0, 1)
    \end{equation}
    measuring volatility-adjusted overbought and oversold conditions.
\end{enumerate}

\textbf{Feature Selection for 4-Qubit Encodings:} In near-term hardware with 4 qubits, encoding all 8 indicators simultaneously would require excessive multi-qubit compression. We select four complementary indicators spanning distinct market dimensions:
\begin{equation}
  \mathbf{x}_t = \left[x_{1,t} \ (\text{Price Level}), \ x_{4,t} \ (\text{Momentum}), \ x_{5,t} \ (\text{Trend}), \ x_{8,t} \ (\text{Volatility-Bound})\right]^\top \in [0, 1]^4
\end{equation}

Table~\ref{tab:indicators} summarizes the dataset and indicator specifications.

\begin{table}[t!]
\centering
\small
\caption{Dataset and financial indicator engineering summary (\SPY{} ETF, 2015--2023).\label{tab:indicators}}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lllll}
\toprule
Indicator Symbol & Indicator Name & Market Dimension & Window / Lookback & Feature Inclusion \\
\midrule
$x_{1,t}$ & Normalized Close & Intermediate Price Level & 252-day trailing min-max & Primary (Qubit 0) \\
$x_{2,t}$ & Normalized Log Return & Short-Term Return & 1-day / 20-day vol & Secondary Audit \\
$x_{3,t}$ & Historical Volatility & Regime Volatility & 20-day annualized & Secondary Audit \\
$x_{4,t}$ & Relative Strength Index & Momentum & 14-day exponential & Primary (Qubit 1) \\
$x_{5,t}$ & MACD Signal Difference & Trend Crossover & 12/26/9 EMA cascade & Primary (Qubit 2) \\
$x_{6,t}$ & Momentum-10 & Price Ratio & 10-day trailing & Secondary Audit \\
$x_{7,t}$ & Moving Average Ratio & Trend Horizon & 10-day / 50-day SMA & Secondary Audit \\
$x_{8,t}$ & Bollinger Bands \%B & Volatility Band Location & 20-day ($2\sigma$ envelope) & Primary (Qubit 3) \\
\bottomrule
\end{tabular}%
}
\end{table}

\subsection{Prediction Target Formulation}
The downstream financial learning task is next-day market directional forecasting:
\begin{equation}
  y_{t+1} = \begin{cases} 1, & \text{if } r_{t+1} = \ln(C_{t+1}/C_t) > 0 \\ 0, & \text{if } r_{t+1} \le 0 \end{cases}
\end{equation}
This binary formulation directly governs market-timing decisions: long position ($y_{t+1} = 1$) versus cash or risk-neutral posture ($y_{t+1} = 0$).

\subsection{Quantum Feature Encoding}
We map each normalized observation $\mathbf{x}_t \in [0, 1]^4$ into a 4-qubit quantum state via unitary transformation $U_\Phi(\mathbf{x}_t)$:
\begin{equation}
  |\Phi(\mathbf{x}_t)\rangle = U_\Phi(\mathbf{x}_t) |0\rangle^{\otimes 4}
\end{equation}
In the absence of noise, the state is pure: $\rho_{\text{ideal}}(\mathbf{x}_t) = |\Phi(\mathbf{x}_t)\rangle\langle\Phi(\mathbf{x}_t)|$.

\subsection{Quantum Circuit Architectures and Gate Decomposition}
We evaluate three encoding architectures, illustrated in Figure~\ref{fig:circuits}:
\begin{enumerate}
    \item \textbf{Angle Encoding (\AEenc{}):} Product-state circuit applying single-qubit rotations $R_x(\pi x_{i,t})$ on independent qubits. Depth $d=1$, 4 single-qubit gates, 0 CNOT gates.
    \item \textbf{Angle Encoding with Linear Entanglement (\AEE{}):} Applies an initial $R_x(\pi x_{i,t})$ layer, a linear cascade of 3 nearest-neighbor CNOT gates ($\text{CX}_{0,1}, \text{CX}_{1,2}, \text{CX}_{2,3}$), and a second $R_x(\pi x_{i,t})$ layer. Depth $d=5$, 8 single-qubit gates, 3 CNOT gates.
    \item \textbf{IQP Feature Map (\IQP{}):} Prepares uniform superposition via $H^{\otimes 4}$, followed by single-qubit phase rotations $R_z(2 x_{i,t})$ and pairwise diagonal entangling interactions. For hardware resource accounting and physical transpilation, each logical two-qubit interaction $\exp(-i x_j x_k Z_j Z_k)$ is decomposed into a native $\text{CNOT}_{(j,k)} - R_Z(2 x_j x_k) - \text{CNOT}_{(j,k)}$ sequence, accounting for 2 CNOT gates per interacting pair (6 CNOTs for the 3 nearest-neighbor pairs). The circuit concludes with a second Hadamard layer and single-qubit phase shifts. Depth $d=13$, 19 single-qubit gates, 6 CNOT gates.
\end{enumerate}

\begin{figure}[t!]
\centering
\includegraphics[width=0.90\textwidth]{../figures/pdf/fig02_circuit_architectures.pdf}
\caption{Quantum circuit architectures for financial indicator encoding: (a) Angle Encoding (AE, depth 1, 0 CX), (b) Angle Encoding with Linear Entanglement (AE+ENT, depth 5, 3 CX), and (c) Instantaneous Quantum Polynomial (IQP, depth 13, 6 CX) feature map.\label{fig:circuits}}
\end{figure}

Table~\ref{tab:circuits} summarizes the hardware resource requirements.

\begin{table}[t!]
\centering
\small
\caption{Quantum circuit resource requirements for 4-qubit financial indicator encoding.\label{tab:circuits}}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccccc}
\toprule
Encoding Architecture & Qubits ($n$) & Circuit Depth ($d$) & 1Q Gates & 2Q Gates (CX) & Total Gates & Entangling Topology \\
\midrule
Angle Encoding (\AEenc{}) & 4 & 1 & 4 & 0 & 4 & None (Separable) \\
AE + Entanglement (\AEE{}) & 4 & 5 & 8 & 3 & 11 & Linear Nearest-Neighbor \\
IQP Feature Map (\IQP{}) & 4 & 13 & 19 & 6 & 25 & Linear Nearest-Neighbor \\
\bottomrule
\end{tabular}%
}
\end{table}

\subsection{Noise Models and Hardware-Informed Transmon Parameterization}
We evaluate noise through two complementary experimental approaches:
\begin{enumerate}
    \item \textbf{Isolated Microscopic Channels:} Parametric sweeps across seven isolated noise mechanisms: single-qubit depolarizing, two-qubit depolarizing, bit-flip ($X$), phase-flip ($Z$), amplitude damping ($T_1$), phase damping ($T_2$), and classical readout assignment errors.
    \item \textbf{Hardware-Informed Transmon Noise Model:} Open-system simulation using Qiskit's \texttt{GenericBackendV2(num\_qubits=5, seed=42)} as a reproducible hardware-informed noisy simulator. \texttt{GenericBackendV2} was instantiated with five qubits to provide a canonical, reproducible hardware-informed backend coupling topology; however, all reported 4-qubit quantum experiments used only the active $q_0-q_3$ subgraph register (qubit $q_4$ remained idle and did not participate in state encoding or measurement). Across the active $q_0-q_3$ register, physical properties average: mean $T_1 = 167.1\,\si{\micro\second}$, mean $T_2 = 142.3\,\si{\micro\second}$ (median $T_1 = 172.9\,\si{\micro\second}$, median $T_2 = 140.5\,\si{\micro\second}$), single-qubit gate infidelity $p_{1Q} \approx 9.41 \times 10^{-5}$ ($\tau_{1Q} = 35\,\si{\nano\second}$), directed two-qubit CNOT errors $p_{2Q} \approx 1.64 \times 10^{-3} - 4.16 \times 10^{-3}$ (mean $2.84 \times 10^{-3}$, $\tau_{2Q} = 280\,\si{\nano\second}$ across the 6 directed active coupling pairs), and readout assignment errors $P(0|1), P(1|0) \approx 0.77 \times 10^{-3} - 3.61 \times 10^{-3}$ (mean $1.86 \times 10^{-3}$). For comparison, the entire five-qubit topology exhibits mean $T_1 = 166.5\,\si{\micro\second}$, mean $T_2 = 150.3\,\si{\micro\second}$, mean $p_{2Q} = 2.94 \times 10^{-3}$, and mean readout error $p_{\text{ro}} = 1.79 \times 10^{-3}$. \textit{Explicit Disclosure:} Computations are conducted via density matrix and shot-based simulation on classical hardware; no cryogenic quantum processors were operated.
\end{enumerate}

Table~\ref{tab:noise_params} outlines the noise model parameters.

\begin{table}[t!]
\centering
\small
\caption{Physical parameter ranges for microscopic noise channels and transmon models.\label{tab:noise_params}}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{llll}
\toprule
Noise Channel & Parameter & Evaluated Range & Transmon Model (\texttt{GenericBackendV2}, Seed 42) \\
\midrule
Depolarizing (1Q) & $p_{1Q}$ & $10^{-4}$ to $10^{-1}$ & $9.41 \times 10^{-5}$ (active $q_0-q_3$), $9.35 \times 10^{-5}$ (full 5Q mean) \\
Depolarizing (2Q) & $p_{2Q}$ & $10^{-3}$ to $10^{-1}$ & $2.84 \times 10^{-3}$ (active $q_0-q_3$), $2.94 \times 10^{-3}$ (full 5Q mean) \\
Amplitude Damping & $T_1$ & $10\,\si{\micro\second}$ to $500\,\si{\micro\second}$ & $167.1\,\si{\micro\second}$ (active mean), $166.5\,\si{\micro\second}$ (full 5Q mean) \\
Phase Damping & $T_2$ & $10\,\si{\micro\second}$ to $500\,\si{\micro\second}$ & $142.3\,\si{\micro\second}$ (active mean), $150.3\,\si{\micro\second}$ (full 5Q mean) \\
Thermal Relaxation & $\tau_{1Q}, \tau_{2Q}$ & Fixed pulse durations & $35\,\si{\nano\second}$ (1Q), $280\,\si{\nano\second}$ (2Q) \\
Bit Flip ($X$) & $p_{\text{bf}}$ & $10^{-4}$ to $5\times 10^{-2}$ & Derived from transmon Hamiltonian \\
Phase Flip ($Z$) & $p_{\text{pf}}$ & $10^{-4}$ to $5\times 10^{-2}$ & Derived from transmon Hamiltonian \\
Readout Error & $P(0|1), P(1|0)$ & $10^{-3}$ to $10^{-1}$ & $1.86 \times 10^{-3}$ (active mean), $1.79 \times 10^{-3}$ (full 5Q mean) \\
\bottomrule
\end{tabular}%
}
\end{table}

\subsection{Error Mitigation Protocol}
To evaluate error recovery, we audit three established mitigation strategies:
\begin{enumerate}
    \item \textbf{Linear Zero-Noise Extrapolation (Linear ZNE):} Evaluates observables at noise scale factors $\lambda \in \{1, 2\}$ using pulse folding, estimating zero-noise expectation values via $\langle O \rangle_{\text{mit}} = 2\langle O(1) \rangle - \langle O(2) \rangle$.
    \item \textbf{Richardson Zero-Noise Extrapolation (Richardson ZNE):} Applies two-point polynomial extrapolation across scale factors $\lambda_1 = 1, \lambda_2 = 3$:
    \begin{equation}
      \langle O \rangle_{\text{mit}} = \frac{3\langle O(1) \rangle - \langle O(3) \rangle}{2}
    \end{equation}
    Under the stated assumption of independent measurement errors with approximately equal variance at the two noise scales ($\sigma_1^2 \approx \sigma_2^2 = \sigma^2$), the two-point Richardson estimator has $2.5\times$ the variance of an individual unmitigated estimator:
    \begin{equation}
      \operatorname{Var}\left(\langle O \rangle_{\text{mit}}\right) = (1.5)^2 \frac{\sigma^2}{N_1} + (-0.5)^2 \frac{\sigma^2}{N_2} = \frac{9\sigma^2}{4(N/2)} + \frac{\sigma^2}{4(N/2)} = 2.5 \frac{\sigma^2}{N}
    \end{equation}
    Under the finite-shot noise regime ($N = 8,192$) examined here, this sampling variance inflation increases statistical dispersion, explaining why Richardson extrapolation does not improve observable agreement relative to unmitigated measurements.
    \item \textbf{Measurement Error Mitigation (MEM):} Inverts the empirical readout calibration assignment matrix $\mathbf{A} \in \mathbb{R}^{16 \times 16}$ through regularized least-squares optimization over the probability simplex $\Delta_{16}$.
\end{enumerate}

\subsection{Classical Machine Learning Benchmarks}
To establish an empirical baseline, Quantum Kernel Support Vector Machines (QSVM) are compared against three established classical models:
\begin{enumerate}
    \item \textbf{Logistic Regression (L2-Regularized):} Standard generalized linear baseline with inverse regularization parameter $C = 1.0$.
    \item \textbf{Support Vector Classifier (RBF Kernel):} Non-linear support vector machine using Gaussian radial basis function kernel with parameter $\gamma = 1/d$ and $C = 1.0$.
    \item \textbf{Random Forest Classifier:} Ensemble decision forest with 100 estimators, maximum tree depth 5, and Gini impurity splitting criterion.
\end{enumerate}
All models receive identical four-dimensional normalized feature vectors $\mathbf{x}_t \in [0, 1]^4$.

\subsection{Evaluation Metrics}
\textbf{Quantum-Level Metrics:}
\begin{itemize}
    \item \textbf{True Quantum State Fidelity ($\FQ$):} Computed via the Uhlmann fidelity:
    \begin{equation}
      \FQ(\rho_{\text{ideal}}, \rho_{\text{noisy}}) = \left(\Tr\sqrt{\sqrt{\rho_{\text{ideal}}} \rho_{\text{noisy}} \sqrt{\rho_{\text{ideal}}}}\right)^2 = \bra{\Phi(\mathbf{x})} \rho_{\text{noisy}} \ket{\Phi(\mathbf{x})}
    \end{equation}
    \item \textbf{Observable Agreement ($\SZ$):} Single-qubit Pauli-$Z$ expectation similarity:
    \begin{equation}
      \SZ = 1 - \frac{1}{4n} \sum_{i=1}^n \left(\langle Z_i \rangle_{\text{ideal}} - \langle Z_i \rangle_{\text{noisy}}\right)^2
    \end{equation}
    \item \textbf{Reconstruction Mean Squared Error ($\varepsilon_{\text{rec}}$):} Error in recovering continuous classical features from quantum measurements: $\varepsilon_{\text{rec}} = \frac{1}{n}\sum_{i=1}^n (\hat{x}_i - x_i)^2$.
\end{itemize}

\textbf{Financial Prediction and Econometric Metrics:}
\begin{itemize}
    \item \textbf{Directional Accuracy:} Fraction of correct next-day sign forecasts:
    \begin{equation*}
      \text{Acc} = \frac{1}{N}\sum_{t=1}^N \mathbb{I}(\hat{y}_t = y_t).
    \end{equation*}
    \item \textbf{Balanced Accuracy:} Arithmetic mean of class-specific sensitivities:
    \begin{equation*}
      \text{BAcc} = \frac{1}{2}\left(\frac{\text{TP}}{\text{P}} + \frac{\text{TN}}{\text{N}}\right),
    \end{equation*}
    accounting directly for directional class prevalence.
    \item \textbf{Area Under the ROC Curve (ROC-AUC):} Discriminative capability of continuous decision values across classification thresholds, evaluated with 95\% empirical bootstrap confidence intervals (2,000 resamples).
    \item \textbf{Diebold--Mariano Test:} Formal statistical test for equal predictive accuracy comparing each model's loss differential against Logistic Regression \cite{Diebold1995}. For directional classification, the Diebold--Mariano test uses the 0--1 loss function, with the loss differential computed between each model and the Logistic Regression benchmark.
\end{itemize}

\subsection{Trading Strategy and Transaction-Cost Model}
\label{sec:trading_model}
To evaluate whether statistical directional predictions translate into economic value, we construct a rule-based quantitative trading strategy subject to realistic proportional transaction costs:
\begin{enumerate}
    \item \textbf{Position Formulation:} At the close of trading session $t$, the model generates next-day directional forecast $\hat{y}_{t+1|t} \in \{0, 1\}$. The portfolio enters a binary long-or-cash position $w_t \in \{0, 1\}$:
    \begin{equation}
      w_t = \begin{cases} 1, & \text{if } \hat{y}_{t+1|t} = 1 \ (\text{or continuous decision score } f(\mathbf{x}_t) \ge 0) \\ 0, & \text{if } \hat{y}_{t+1|t} = 0 \ (\text{risk-neutral cash posture}) \end{cases}
    \end{equation}
    Short selling is prohibited ($w_t \in \{0, 1\}$), reflecting common institutional constraints for long-only mutual funds and ETF allocations.
    \item \textbf{Execution Timing:} Position $w_t$ is executed at the closing price of day $t$ (or opening of $t+1$) and held through the close of trading day $t+1$, earning gross return $w_t r_{t+1}$, where $r_{t+1} = (P_{t+1} - P_t)/P_t$.
    \item \textbf{Transaction Cost Accounting:} Trading friction is modeled through proportional one-way transaction cost $c \in \{0, 5, 10, 20\}\,\text{bps}$ ($c \in \{0, 0.0005, 0.0010, 0.0020\}$), capturing execution commissions, exchange fees, and bid-ask spread crossing. Net daily return is realized as:
    \begin{equation}
      r_{t+1}^{\text{net}} = w_t r_{t+1} - c \cdot |w_t - w_{t-1}|.
    \end{equation}
    \item \textbf{Annualized Turnover:} Annualized one-way portfolio turnover measures the trading frequency across 252 annual sessions:
    \begin{equation}
      \text{Turnover} = \frac{252}{T} \sum_{t=1}^T |w_t - w_{t-1}|.
    \end{equation}
    \item \textbf{Risk-Adjusted Performance:} Annualized return, annualized volatility, and net Sharpe ratio are computed via standard convention:
    \begin{equation}
      \bar{r}^{\text{ann}} = (1 + \bar{r}^{\text{net}})^{252} - 1, \quad \sigma^{\text{ann}} = \sigma(r^{\text{net}})\sqrt{252}, \quad \text{SR} = \frac{\bar{r}^{\text{ann}}}{\sigma^{\text{ann}}}
    \end{equation}
    assuming zero risk-free rate for pure strategy excess return. Maximum Drawdown (MDD) is computed from cumulative wealth $W_t = \prod_{s=1}^t (1 + r_s^{\text{net}})$:
    \begin{equation}
      \text{MDD} = \max_{t \in [1, T]} \left( \frac{\max_{s \le t} W_s - W_t}{\max_{s \le t} W_s} \right).
    \end{equation}
\end{enumerate}

\subsection{Walk-Forward Validation Protocol}
To evaluate model stability across structural economic regimes, we implement an expanding-window walk-forward validation across five calendar years (2019--2023). For each test year $Y \in \{2019, 2020, 2021, 2022, 2023\}$, the model is trained exclusively on post-warm-up feature observations strictly preceding January 1 of year $Y$. From the initial dataset inception on January 2, 2015, the first 251 trading days are consumed by the 252-day indicator warm-up window, so valid feature training commences on December 31, 2015. 

Specifically, for test year 2019, training spans 2015--2018 ($1,006$ raw trading days from inception, yielding $N_{\text{train}} = 755$ valid post-warm-up feature training days, evaluated on $N_{\text{test}} = 252$ out-of-sample days in 2019). For test year 2020, training spans 2015--2019 ($1,258$ raw trading days, $N_{\text{train}} = 1,007$ valid feature days, $N_{\text{test}} = 253$). For test year 2021, training spans 2015--2020 ($1,511$ raw days, $N_{\text{train}} = 1,260$ valid feature days, $N_{\text{test}} = 252$). For test year 2022, training spans 2015--2021 ($1,763$ raw days, $N_{\text{train}} = 1,512$ valid feature days, $N_{\text{test}} = 251$). For test year 2023, training spans 2015--2022 ($2,014$ raw days, $N_{\text{train}} = 1,763$ valid feature days, $N_{\text{test}} = 249$ forward targets). Across the five test years, out-of-sample evaluation spans exactly $N_{\text{eval}} = 1,257$ trading days. No future data are visible during parameter fitting, preserving strict chronological causality and eliminating look-ahead bias.

% =========================================================================
% 4. EXPERIMENTAL DESIGN
% =========================================================================
\section{Experimental Design}
\label{sec:experimental_design}

Table~\ref{tab:experimental_design} details the unified experimental matrix executed across the 2,013 valid market sessions.

\begin{table}[t!]
\centering
\small
\caption{Unified experimental matrix across encoding, noise, and evaluation dimensions.\label{tab:experimental_design}}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lll}
\toprule
Dimension & Parameters / Settings & Implementation Details \\
\midrule
Financial Dataset & \SPY{} daily adjusted prices, 2015--2023 & $T = 2,013$ sessions, 252-day warm-up \\
Indicators & Normalized Close, RSI-14, MACD, Bollinger \%B & Causal trailing normalization, $\mathbf{x}_t \in [0, 1]^4$ \\
QML Architectures & Angle Encoding (\AEenc{}), \AEE{}, IQP Map (\IQP{}) & 4 qubits, depths $d \in \{1, 5, 13\}$ \\
Simulation Engine & Qiskit Aer (Statevector \& QasmSimulator) & 8,192 shots per circuit evaluation \\
Noise Environments & 7 Microscopic channels + \texttt{GenericBackendV2} & Lindbladian Kraus maps, transmon parameterization \\
Error Mitigation & Linear ZNE ($\lambda \in \{1, 2\}$), Richardson ZNE ($\lambda \in \{1, 3\}$), MEM & Pulse folding, matrix inversion on simplex \\
Predictive Models & Logistic Reg, SVM-RBF, Random Forest, QSVMs & Holdout ($N = 376$), Sensitivity ($N = 503$), WF ($N = 1,257$) \\
Friction Tiers & Transaction costs $c \in \{0, 5, 10, 20\}\,\text{bps}$ & Turnover-adjusted backtesting \\
\bottomrule
\end{tabular}%
}
\end{table}

% =========================================================================
% 5. RESULTS
% =========================================================================
\section{Results}
\label{sec:results}

\subsection{Descriptive Statistics and Financial Indicator Properties}
Table~\ref{tab:summary_stats} reports descriptive statistics for the engineered indicators across the 2,013 valid trading days. Daily S\&P 500 ETF returns exhibit negative skewness ($-0.54$) and excess kurtosis ($4.82$), consistent with well-established stylized facts of equity index dynamics \cite{Cont2001}. Pairwise correlation analysis reveals heterogeneous dependence across the four selected indicators, with correlations ranging from 0.1362 to 0.9033 (Supplementary Table~S3). Normalized Close exhibits modest correlation with MACD ($r = 0.1362$) and moderate correlation with Bollinger \%B ($r = 0.4811$) and RSI ($r = 0.6312$), whereas momentum and boundary indicators (RSI and Bollinger \%B) exhibit substantial collinearity ($r = 0.9033$). This realistic empirical dependence structure is intentionally retained: rather than enforcing artificial statistical orthogonality via principal component filtering, our benchmark evaluates the robustness of quantum feature maps under the genuine, correlated feature distributions encountered in production quantitative finance.

\begin{table}[t!]
\centering
\small
\caption{Descriptive statistics for engineered technical and momentum indicators ($T = 2,013$).\label{tab:summary_stats}}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lccccccc}
\toprule
Feature / Indicator & Mean & Std Dev & Min & 25\% & Median & 75\% & Max \\
\midrule
Daily Adjusted Return & 0.0004 & 0.0108 & -0.1094 & -0.0035 & 0.0006 & 0.0055 & 0.0906 \\
Norm. Close ($x_{1,t}$) & 0.6842 & 0.2819 & 0.0000 & 0.5124 & 0.7612 & 0.9104 & 1.0000 \\
RSI-14 ($x_{4,t}$) & 0.5468 & 0.1281 & 0.1524 & 0.4592 & 0.5518 & 0.6372 & 0.8841 \\
MACD Signal Diff ($x_{5,t}$) & 0.5089 & 0.0984 & 0.1214 & 0.4491 & 0.5102 & 0.5714 & 0.8912 \\
Momentum-10 ($x_{6,t}$) & 0.5291 & 0.1219 & 0.0000 & 0.4612 & 0.5341 & 0.6019 & 1.0000 \\
MA Ratio 10/50 ($x_{7,t}$) & 0.5312 & 0.1092 & 0.0000 & 0.4718 & 0.5381 & 0.5982 & 1.0000 \\
Bollinger \%B ($x_{8,t}$) & 0.6128 & 0.2641 & 0.0000 & 0.4281 & 0.6619 & 0.8291 & 1.0000 \\
\bottomrule
\end{tabular}%
}
\end{table}

\subsection{Ideal Quantum Encoding Performance}
Under noise-free statevector simulation, with measurement observables estimated using 8,192 shots, Angle Encoding achieves near-perfect fidelity ($\bar{\mathcal{F}}_Q = 0.99998 \pm 0.00002$) and reconstruction MSE of $(1.16 \pm 0.76) \times 10^{-5}$, with observable agreement $S_Z = 0.999985$. The minor deviation from unity arises solely from finite shot sampling.

\subsection{Noise Sensitivity and Transmon Simulation}

\begin{figure}[t!]
\centering
\includegraphics[width=0.88\textwidth]{../figures/pdf/fig06_noise_channel_comparison.pdf}
\caption{Systematic noise sensitivity comparison across seven isolated noise mechanisms: single- and two-qubit depolarizing noise, bit-flip, phase-flip, amplitude damping, phase damping, and readout assignment error.\label{fig:noise_channels}}
\end{figure}

\begin{figure}[t!]
\centering
\includegraphics[width=0.88\textwidth]{../figures/pdf/fig11_hardware_calibrated.pdf}
\caption{Hardware-informed transmon simulation results comparing state fidelity and observable agreement across encoding architectures on Qiskit's \texttt{GenericBackendV2}.\label{fig:hw_calibrated}}
\end{figure}

Table~\ref{tab:main_results} presents the primary benchmark results under the hardware-informed transmon noise model (\texttt{GenericBackendV2}). Angle Encoding exhibits exceptional stability, preserving state fidelity $\FQ = 0.9989 \pm 0.0002$ and observable agreement $\SZ = 0.99998 \pm 0.00002$. In sharp contrast, entangling architectures experience severe state corruption:
\begin{itemize}
    \item \textbf{AE + Entanglement (\AEE{}):} State fidelity drops to $\FQ = 0.9609 \pm 0.0014$, representing a 35-fold increase in state infidelity ($1 - \FQ = 3.91\%$).
    \item \textbf{IQP Feature Map:} State fidelity degrades to $\FQ = 0.9257 \pm 0.0028$, with state infidelity reaching $7.43\%$.
\end{itemize}

\begin{table}[t!]
\centering
\small
\caption{Benchmark results under the hardware-informed transmon noise model (\texttt{GenericBackendV2}, 8,192 shots).\label{tab:main_results}}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccc}
\toprule
Encoding Architecture & State Fidelity $\bar{\mathcal{F}}_Q$ & Observable Agreement $\bar{S}_Z$ & Distortion $\Delta Z$ & Reconstruction MSE $\bar{\varepsilon}_{\text{rec}}$ \\
\midrule
Angle Encoding (\AEenc{}) & $\mathbf{0.9989 \pm 0.0002}$ & $\mathbf{0.99998 \pm 0.00002}$ & $\mathbf{0.0069 \pm 0.0028}$ & $\mathbf{(1.52 \pm 1.25)\times 10^{-5}}$ \\
AE + Entanglement (\AEE{}) & $0.9609 \pm 0.0014$ & $0.99996 \pm 0.00002$ & $0.0097 \pm 0.0035$ & N/A (non-invertible) \\
IQP Feature Map & $0.9257 \pm 0.0028$ & $0.99982 \pm 0.00010$ & $0.0195 \pm 0.0053$ & N/A (non-invertible) \\
\bottomrule
\end{tabular}%
}
\end{table}

\textbf{Decoupling State Fidelity from Marginal Observable Agreement:} A critical methodological insight emerges from comparing $\SZ$ and $\FQ$. While \AEE{} and \IQP{} maintain marginal observable agreement $\SZ \ge 0.9998$, their true state fidelities degrade sharply to $0.9609$ and $0.9257$. Because $\SZ$ projects the 16-dimensional quantum state onto single-qubit Pauli-$Z$ marginals, it is blind to off-diagonal coherence loss and multi-qubit phase corruption. Evaluating quantum feature maps purely through single-qubit expectation values creates a misleading illusion of hardware robustness.

\subsection{Controlled Depth Ablation: Isolating the Entanglement Penalty}
To separate the effect of circuit depth from two-qubit entangling operations, we conduct controlled depth ablation experiments holding logical circuit depth constant:
\begin{enumerate}
    \item \textbf{Ablation at Depth 5:} A separable circuit with depth 5 (consisting solely of single-qubit rotations) incurs a state infidelity of $1 - \FQ = 0.408\%$. Inserting 3 CNOT gates to form \AEE{} at identical depth increases infidelity to $4.119\%$---a \textbf{10.1-fold increase in state corruption} (entangling gates account for $90.1\%$ of additional infidelity).
    \item \textbf{Ablation at Depth 13:} A separable circuit at depth 13 exhibits state infidelity of $0.996\%$. Adding 6 CNOT gates to form \IQP{} increases infidelity to $7.402\%$---a \textbf{7.4-fold increase} (entangling gates account for $86.5\%$ of additional infidelity).
\end{enumerate}
These controlled-depth ablations indicate that two-qubit entangling gates contribute substantially more to state degradation than the additional single-qubit depth in the tested configurations.

\subsection{When Richardson ZNE Degrades Performance Under Finite-Shot Sampling}

\begin{figure}[t!]
\centering
\includegraphics[width=0.85\textwidth]{../figures/pdf/fig09_mitigation_performance.pdf}
\caption{Error mitigation benchmark across Linear Zero-Noise Extrapolation (ZNE), two-point Richardson ZNE, and Measurement Error Mitigation (MEM), plotting observable distortion $(1 - S_Z) \times 10^{-5}$ and illustrating the finite-sample variance amplification of Richardson extrapolation.\label{fig:mitigation}}
\end{figure}

Table~\ref{tab:mitigation} reports observable agreement $\SZ$ before and after error mitigation under transmon noise.

\begin{table}[t!]
\centering
\small
\caption{Error mitigation performance under hardware-informed transmon noise (8,192 shots).\label{tab:mitigation}}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccc}
\toprule
Mitigation Technique & Scale Factors ($\lambda$) & \AEenc{} ($S_Z$) & \AEE{} ($S_Z$) & \IQP{} ($S_Z$) \\
\midrule
Unmitigated (Noisy) & $\lambda = 1$ & 0.999970 & 0.999958 & 0.999824 \\
Linear ZNE & $\lambda \in \{1, 2\}$ & $\mathbf{0.999976}$ & $\mathbf{0.999965}$ & $\mathbf{0.999841}$ \\
Richardson ZNE & $\lambda \in \{1, 3\}$ & 0.999957 & 0.999942 & 0.999798 \\
Measurement Error Mitigation (MEM) & N/A & 0.999972 & 0.999960 & 0.999830 \\
\bottomrule
\end{tabular}%
}
\end{table}

\textbf{Mathematical Explanation of Richardson ZNE Degradation:}
Under two-point Richardson extrapolation, the zero-noise estimator is $\hat{E}_{\text{Rich}}(0) = 1.5 \hat{E}(1) - 0.5 \hat{E}(3)$. Assuming independent measurement errors across noise scales with sampling variance $\sigma^2 / N$, the variance of the Richardson estimator is:
\begin{equation}
  \operatorname{Var}\left(\hat{E}_{\text{Rich}}(0)\right) = (1.5)^2 \operatorname{Var}(\hat{E}(1)) + (-0.5)^2 \operatorname{Var}(\hat{E}(3)) = 2.25 \frac{\sigma_1^2}{N} + 0.25 \frac{\sigma_3^2}{N} \approx 2.5 \frac{\sigma^2}{N}
\end{equation}
Under the stated assumption of independent measurement errors with approximately equal variance at the two noise scales ($\sigma_1^2 \approx \sigma_3^2 \approx \sigma^2$), the two-point Richardson estimator has $2.5\times$ the variance of an individual unmitigated estimator. Under the finite-shot noise regime and parameter settings examined here ($N = 8,192$), two-point Richardson extrapolation increased estimator variance and did not improve observable agreement. When physical gate bias is smaller than sampling uncertainty, Richardson ZNE inflates total mean squared error, degrading observable accuracy.

\subsection{Kernel Bridge: Frobenius Distortion and Target Alignment}
Table~\ref{tab:kernel_bridge} evaluates the bridge between circuit fidelity, Gram matrix distortion, and Kernel-Target Alignment (KTA).

\begin{table}[t!]
\centering
\small
\caption{Kernel bridge analysis: Frobenius distortion and Kernel-Target Alignment (KTA).\label{tab:kernel_bridge}}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccc}
\toprule
Encoding Map & State Fidelity $\FQ$ & Rel. Frobenius Distortion ($\delta_F$) & KTA (Ideal) & KTA (Noisy) \\
\midrule
Angle Encoding (\AEenc{}) & 0.9989 & $\mathbf{0.201\%}$ & 0.0133 & 0.0133 \\
AE + Entanglement (\AEE{}) & 0.9609 & $7.021\%$ & 0.0145 & 0.0149 \\
IQP Feature Map & 0.9257 & $13.030\%$ & 0.0128 & 0.0138 \\
\bottomrule
\end{tabular}%
}
\end{table}

Physical state infidelity directly translates into Gram matrix distortion: \AEenc{} experiences negligible Frobenius distortion ($0.201\%$), whereas \IQP{} exhibits $13.03\%$ distortion. However, Kernel-Target Alignment remains uniformly low across all maps ($\approx 0.013 - 0.015$), indicating that none of the static quantum feature maps achieve strong linear alignment with daily SPY return directions.

\subsection{Downstream Predictive Performance}

\begin{figure}[t!]
\centering
\includegraphics[width=0.98\textwidth]{../figures/pdf/fig06_forecasting_performance.pdf}
\caption{Out-of-sample directional forecasting performance, ranking discriminability, and transaction-cost friction decay across classical and quantum models: (a) Directional accuracy (\%) on holdout evaluation ($N_{\text{eval}} = 376$ sessions) with 95\% bootstrap confidence intervals, compared against the random benchmark (50\%) and prevailing class trend (53.7\%); (b) Area Under the ROC Curve (ROC-AUC) with 95\% bootstrap confidence intervals; (c) Annualized Net Sharpe ratio decay across transaction friction tiers ($c \in \{0, 5, 10, 20\}\,\text{bps}$), highlighting the turnover penalty on complex non-linear models.\label{fig:downstream_pred}}
\end{figure}

Two complementary out-of-sample evaluations are reported: a fixed holdout from July 2022 through December 2023 ($N_{\text{eval}} = 376$), used for the primary benchmark and economic backtest (Table~\ref{tab:predictive_results}), and an extended chronological 2022--2023 test period ($N = 503$), reported in Supplementary Table~S4 as a sensitivity analysis.

\begin{table}[t!]
\centering
\small
\caption{Out-of-sample directional forecasting benchmark (Fixed Holdout: July 2022--December 2023, $N_{\text{eval}} = 376$).\label{tab:predictive_results}}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{llccccc}
\toprule
Model Architecture & Encoding / Noise Condition & Accuracy & Balanced Acc & ROC-AUC [95\% Bootstrap CI] & F1-Score & DM $p$-val \\
\midrule
Logistic Regression & Classical Features (N/A) & 51.33\% & 50.00\% & 0.5191 [0.4607, 0.5787] & 0.6784 & Benchmark \\
SVM (RBF Kernel) & Classical Features (N/A) & 51.33\% & 50.00\% & 0.4613 [0.4047, 0.5232] & 0.6784 & 1.0000 \\
Random Forest & Classical Features (N/A) & 51.60\% & 50.46\% & 0.4896 [0.4294, 0.5440] & 0.6642 & 0.8476 \\
QSVM (\AEenc{}) & Ideal Simulation (0 CX) & 51.33\% & 50.00\% & 0.4669 [0.4106, 0.5293] & 0.6784 & 1.0000 \\
QSVM (\AEenc{}) & Noisy Transmon (0 CX) & 52.13\% & 50.81\% & 0.4380 [0.3814, 0.4955] & 0.6809 & 0.1792 \\
QSVM (\AEenc{}) & Mitigated ZNE (0 CX) & 52.13\% & 50.81\% & 0.4371 [0.3806, 0.4941] & 0.6809 & 0.1792 \\
QSVM (\AEE{}) & Ideal Simulation (3 CX) & 51.33\% & 50.00\% & 0.4590 [0.4036, 0.5241] & 0.6784 & 1.0000 \\
QSVM (\AEE{}) & Noisy Transmon (3 CX) & 50.80\% & 49.73\% & 0.4413 [0.3876, 0.4988] & 0.6714 & 0.4144 \\
QSVM (\IQP{}) & Ideal Simulation (6 CX) & 51.33\% & 50.00\% & 0.4926 [0.4360, 0.5532] & 0.6784 & 1.0000 \\
QSVM (\IQP{}) & Noisy Transmon (6 CX) & 53.99\% & 52.89\% & 0.4381 [0.3850, 0.4950] & 0.6778 & 0.0763 \\
\bottomrule
\end{tabular}%
}
\end{table}

\textbf{Econometric Assessment:}
Directional forecasting accuracy ranges between 50.80\% and 53.99\%, consistent with weak-form market efficiency for daily liquid equities. The apparent divergence between directional accuracy ($53.99\%$) and ROC-AUC ($0.4381$) for some QSVM specifications reflects the thresholded classification rule and the ranking behavior of the continuous decision scores under prevailing class prevalence ($51.33\%$ positive sessions). Specifically, the decision function intercept shifts toward the dominant class drift, capturing upward direction at the default threshold $f(\mathbf{x}) \ge 0$ (achieving $94.3\%$ sensitivity on positive sessions), whereas the continuous decision margin ranks are perturbed by kernel matrix noise; therefore, accuracy is not interpreted in isolation. Balanced accuracy confirms that when class-prevalence bias is adjusted, the advantage is marginal ($52.89\%$ vs $50.00\%$) and non-significant under the Diebold--Mariano test ($p = 0.0763$). The Diebold--Mariano tests do not reject the null hypothesis of equal predictive accuracy at conventional significance levels ($p > 0.07$ across all specifications), indicating that neither classical non-linear models nor quantum kernel specifications achieve statistically significant predictive outperformance over the linear baseline.

\subsection{Financial Indicator Dynamics and Multi-Distribution Robustness}

\begin{figure}[t!]
\centering
\includegraphics[width=0.92\textwidth]{../figures/pdf/fig07_financial_distribution_robustness.pdf}
\caption{Robustness of quantum feature maps across empirical SPY indicator distributions and synthetic input distributions: (a) Trajectory of the four selected financial indicators over the 2023 calendar trading year ($N = 250$ sessions, strictly terminating December 29, 2023); (b) True state fidelity $\mathcal{F}_Q$ across empirical SPY, uniform $\mathcal{U}(0,1)$, standard Gaussian $\mathcal{N}(0,1)$, and correlated Gaussian distributions.\label{fig:financial_case}}
\end{figure}

Table~\ref{tab:walk_forward} reports expanding-window walk-forward validation across five distinct market regimes from 2019 to 2023.

\begin{table}[t!]
\centering
\small
\caption{Expanding-window walk-forward validation across market regimes (2019--2023). QSVM denotes the noisy Angle Encoding configuration unless otherwise stated.\label{tab:walk_forward}}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{llcccccc}
\toprule
Test Year & Market Regime & $N_{\text{test}}$ & LR Acc. & LR AUC & QSVM-AE (Noisy) Acc. & QSVM-AE (Noisy) AUC & SPY Sharpe \\
\midrule
2019 & Pre-COVID Expansion & 252 & 57.94\% & 0.4556 & 59.52\% & 0.5479 & 2.30 \\
2020 & COVID-19 Shock & 253 & 57.31\% & 0.5276 & 57.31\% & 0.4575 & 0.60 \\
2021 & Post-Stimulus Rally & 252 & 58.33\% & 0.5164 & 58.33\% & 0.5738 & 2.18 \\
2022 & Rate Tightening Shock & 251 & 43.03\% & 0.5249 & 43.03\% & 0.5636 & -0.75 \\
2023 & Disinflation Rebound & 249 & 55.82\% & 0.4683 & 56.22\% & 0.5182 & 1.90 \\
\bottomrule
\end{tabular}%
}
\end{table}

Performance varies markedly across macro environments: all models achieve higher accuracy during sustained bull regimes (2019 and 2021, $\sim 58--59\%$), but drop to $\sim 43\%$ during the 2022 monetary tightening regime. Across all regimes, QSVM and Logistic Regression track each other closely, confirming the absence of structural quantum advantage.

\subsection{Economic Significance and Transaction Friction Backtest}
Table~\ref{tab:economic_results} details economic backtesting across transaction friction tiers ($0, 5, 10, 20\,\text{bps}$) on the primary fixed holdout sample ($N_{\text{eval}} = 376$, July 2022--December 2023).

\begin{table}[t!]
\centering
\small
\caption{Economic performance across transaction friction tiers ($c \in \{0, 5, 10, 20\}\,\text{bps}$) on primary holdout ($N = 376$).\label{tab:economic_results}}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lccccccr}
\toprule
Trading Strategy & Ann. Vol & Gross SR (0 bps) & Net SR (5 bps) & Net SR (10 bps) & Net SR (20 bps) & Turnover & Max DD \\
\midrule
Passive Long (\SPY{}) & 17.14\% & 1.04 & 1.04 & 1.04 & 1.04 & $0.0\times$ & 16.68\% \\
Logistic Regression & 17.14\% & 1.04 & 1.04 & 1.04 & 1.03 & $0.7\times$ & 16.68\% \\
SVM (RBF Kernel) & 17.14\% & 1.04 & 1.04 & 1.04 & 1.03 & $0.7\times$ & 16.68\% \\
Random Forest & 16.97\% & 1.07 & 0.98 & 0.90 & 0.73 & $28.8\times$ & 16.68\% \\
QSVM (\AEenc{}, Ideal) & 17.14\% & 1.04 & 1.04 & 1.04 & 1.03 & $0.7\times$ & 16.68\% \\
QSVM (\AEenc{}, Noisy) & 17.01\% & 1.17 & 1.15 & 1.13 & 1.09 & $7.4\times$ & 15.39\% \\
QSVM (\AEE{}, Noisy) & 16.88\% & 0.93 & 0.90 & 0.87 & 0.82 & $8.7\times$ & 19.38\% \\
QSVM (\IQP{}, Noisy) & 16.16\% & 1.28 & 1.18 & 1.07 & 0.86 & $34.2\times$ & 19.77\% \\
\bottomrule
\end{tabular}%
}
\end{table}

\textbf{Economic Assessment and Turnover Mechanism:}\par\noindent
Passive Long SPY exhibits $0.0\times$ turnover as a static buy-and-hold benchmark. Classical Logistic Regression, SVM, and ideal QSVM exhibit $0.7\times$ turnover because the models' predicted probabilities remain consistently above the classification threshold across the entire test set ($w_t = 1 \ \forall t$); hence, the strategy executes a single entry trade on day 1 ($1/376 \times 252 = 0.67\times \approx 0.7\times$) and zero subsequent rebalancing trades. In contrast, Random Forest and noisy IQP exhibit active day-to-day position rebalancing, generating $28.8\times$ and $34.2\times$ annualized turnover, respectively. High-turnover strategies suffer severe erosion under realistic friction: Random Forest (turnover $28.8\times$) experiences a Sharpe ratio decay from 1.07 down to 0.73 at 20 bps, while noisy \IQP{} (turnover $34.2\times$) collapses from 1.28 down to 0.86. In contrast, shallow \AEenc{} maintains modest turnover ($0.7\times$ to $7.4\times$), preserving its net Sharpe ratio above 1.09.

% =========================================================================
% 6. DISCUSSION
% =========================================================================
\section{Discussion}
\label{sec:discussion}

\subsection{Which Feature Map is Most Noise-Resilient, and Why?}
Across all experimental evaluations, separable Angle Encoding (\AEenc{}) consistently demonstrates superior noise resilience, achieving state fidelity $\FQ = 0.9989$ and near-zero Frobenius Gram matrix distortion ($0.201\%$). In contrast, entangling architectures experience severe fidelity loss (\AEE{}: $3.91\%$ infidelity; \IQP{}: $7.43\%$ infidelity). The physical mechanism is direct: \AEenc{} requires zero two-qubit gates, executing in $\tau = 35\,\si{\nano\second}$ via fast single-qubit microwave pulses. Because two-qubit cross-resonance gates require substantially longer pulse durations ($\tau_{2Q} = 280\,\si{\nano\second}$) and have error rates an order of magnitude higher than single-qubit gates, entangling circuits accumulate environmental decoherence and pulse infidelities rapidly.

\subsection{The Role of Circuit Depth versus Entangling Gates}
Our controlled-depth ablations indicate that two-qubit entangling gates contribute substantially more to state degradation than the additional single-qubit depth in the tested configurations. When logical depth is held constant at $d=5$, inserting 3 CNOT gates increases state infidelity by a factor of $10.1$ ($90.1\%$ of additional infidelity attributable to entangling operations). Similarly, at depth $d=13$, adding 6 CNOT gates increases infidelity by a factor of $7.4$ ($86.5\%$ attributable to entangling operations). This finding carries critical implications for quantum financial algorithms: For the tested configurations, minimizing two-qubit gate counts has a substantially larger effect on state preservation than the additional single-qubit depth.

\subsection{When Richardson ZNE Degrades Performance in Finite-Shot Regimes}
While Zero-Noise Extrapolation is widely considered a standard mitigation technique, our analytical derivation and empirical results reveal that two-point Richardson ZNE degrades observable agreement relative to unmitigated measurements. Richardson extrapolation acts as a high-pass filter that amplifies finite-sample measurement variance by $2.5\times$ under independent equal-variance sampling. In financial applications where daily signal increments are minuscule ($\Delta x \sim 10^{-3}$), this variance amplification drowns the subtle market signal in statistical sampling noise.

\subsection{Connecting Quantum Robustness to Financial Prediction}
A central finding of this study is that \textbf{quantum state robustness does not automatically produce downstream financial predictive advantage}. Although \AEenc{} preserves quantum states with $99.89\%$ fidelity, QSVM with \AEenc{} achieves directional accuracy of $52.13\%$---statistically indistinguishable from classical Logistic Regression ($51.33\%$, DM test $p = 0.179$). In financial time series, predictive utility is bounded primarily by low signal-to-noise ratios and market efficiency, not by representational expressivity.

% =========================================================================
% 7. ROBUSTNESS AND SENSITIVITY ANALYSIS
% =========================================================================
\section{Robustness and Sensitivity Analysis}
\label{sec:robustness}

\subsection{Stability Across Synthetic Feature Distributions}
To verify that our findings are not artifacts of the empirical SPY distribution, we benchmarked all three feature maps across uniform $\mathcal{U}(0, 1)$, standard normal $\mathcal{N}(0, 1)$, and correlated Gaussian distributions. Across all distributions, the relative ranking of architectures remains invariant: \AEenc{} achieves $\FQ \ge 0.998$, while \AEE{} and \IQP{} experience sharp fidelity drops. These results suggest that, for the tested distributions and circuit configurations, hardware-noise vulnerability is driven primarily by circuit topology and physical gate characteristics rather than by the specific statistical properties of the input features.

\subsection{Regime Invariance Across Walk-Forward Windows}
Walk-forward validation across 2019--2023 demonstrates that model performance tracks macroeconomic conditions rather than quantum circuit specification. During high-volatility liquidity shocks (COVID-19 shock in 2020), both classical and quantum models experience accuracy fluctuations, yet QSVM models never achieve statistically significant separation from classical baselines.

% =========================================================================
% 8. LIMITATIONS
% =========================================================================
\section{Limitations}
\label{sec:limitations}

\begin{enumerate}
    \item \textbf{Simulated Hardware Environment:} All experiments were performed using Qiskit Aer with hardware-informed transmon noise models derived from \texttt{GenericBackendV2} rather than physical dilution refrigerator quantum hardware.
    \item \textbf{Single-Asset Empirical Scope:} The empirical analysis is restricted to daily S\&P 500 ETF (\SPY{}) data from 2015 to 2023. Cross-asset generalization to equities, commodities, or fixed income remains an open empirical question.
    \item \textbf{Qubit Count Constraint:} Circuits were evaluated on 4 qubits, requiring indicator dimensionality reduction.
    \item \textbf{No Demonstration of Quantum Advantage:} The empirical evidence does not establish quantum supremacy or economic advantage over classical methods.
\end{enumerate}

% =========================================================================
% 9. CONCLUSION
% =========================================================================
\section{Conclusion}
\label{sec:conclusion}

This study provides a rigorous, hardware-informed benchmark evaluating the vulnerability of quantum financial feature maps to realistic physical noise. By establishing the empirical link between physical noise channels, quantum state fidelity, Gram matrix distortion, and downstream financial prediction, we demonstrate a clear expressivity--robustness trade-off: deep entangling feature maps suffer severe state corruption under hardware noise, while shallow separable encodings preserve quantum information with high fidelity. In downstream directional return forecasting, quantum kernel models perform on par with classical linear baselines without generating statistically significant predictive improvement over classical baselines. Within the SPY benchmark and noise models considered here, shallow product-state encodings combined with classical feature engineering provide the most reliable noise-resilient baseline for near-term quantum financial learning.

\section*{Funding}
The authors received no specific funding for this research.

\section*{Disclosure Statement}
The authors report there are no competing financial or non-financial interests to declare.

\section*{Data and Software Availability}
Computations were executed in Python 3.11.14 using Qiskit 2.5.2, Qiskit-Aer 0.17.2, NumPy 1.26.4, SciPy 1.13.1, Pandas 2.2.2, Scikit-Learn 1.4.2, Matplotlib 3.8.4, and yfinance 1.7.0. All code, processed dataset pipelines, and figure generation scripts are openly available in the project repository at \url{https://github.com/priyanka292c/noise-resilient-encoding}.

\bibliographystyle{plainnat}
\bibliography{references}

\end{document}
"""

with open(TEX_PATH, "w", encoding="utf-8") as f:
    f.write(content.strip() + "\n")

print(f"Successfully generated revised Quantitative Finance LaTeX manuscript: {TEX_PATH}")
