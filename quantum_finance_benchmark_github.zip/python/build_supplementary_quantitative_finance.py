#!/usr/bin/env python3
"""
build_supplementary_quantitative_finance.py
==========================================
Generates the comprehensive Supplementary Material for:
"Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction:
 A Hardware-Informed Benchmark"
targeted at Quantitative Finance (Taylor & Francis).

Outputs:
  - supplementary/supplementary_quantitative_finance.tex
  - supplementary/supplementary_quantitative_finance.md
"""

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SUPP_DIR = os.path.join(ROOT, "supplementary")
os.makedirs(SUPP_DIR, exist_ok=True)

LATEX_PATH = os.path.join(SUPP_DIR, "supplementary_quantitative_finance.tex")
MD_PATH = os.path.join(SUPP_DIR, "supplementary_quantitative_finance.md")

def generate_latex():
    content = r"""\documentclass[10pt,a4paper]{article}

\usepackage[utf8]{inputenc}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb,amsfonts,bm}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{tabularx}
\usepackage{xcolor}
\usepackage{hyperref}
\usepackage{listings}
\usepackage{siunitx}
\usepackage{caption}
\usepackage{subcaption}

\hypersetup{
    colorlinks=true,
    linkcolor=blue,
    citecolor=blue,
    urlcolor=blue,
    pdftitle={Supplementary Material: Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction},
    pdfauthor={Priyanka et al.}
}

\lstset{
    basicstyle=\ttfamily\scriptsize,
    breaklines=true,
    frame=single,
    backgroundcolor=\color{gray!10},
    keywordstyle=\color{blue},
    commentstyle=\color{green!50!black},
    numbers=left,
    numberstyle=\tiny\color{gray},
    stepnumber=1,
    numbersep=5pt
}

% Quantum Dirac Notation Macros
\newcommand{\bra}[1]{\langle #1 \vert}
\newcommand{\ket}[1]{\vert #1 \rangle}
\newcommand{\braket}[2]{\langle #1 \vert #2 \rangle}
\newcommand{\Fid}{\mathcal{F}}
\newcommand{\SPY}{\texttt{SPY}}

\renewcommand{\thesection}{S\arabic{section}}
\renewcommand{\thesubsection}{S\arabic{section}.\arabic{subsection}}
\renewcommand{\thetable}{S\arabic{table}}
\renewcommand{\thefigure}{S\arabic{figure}}
\renewcommand{\theequation}{S\arabic{equation}}

\makeatletter
\renewcommand*\l@section{\@dottedtocline{1}{1.5em}{2.8em}}
\renewcommand*\l@subsection{\@dottedtocline{2}{4.3em}{3.5em}}
\makeatother

\title{\textbf{Supplementary Material:}\\
\Large \textbf{Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction: A Hardware-Informed Benchmark}}

\author{
  \parbox{\dimexpr\textwidth-2\tabcolsep\relax}{\centering
    \textbf{Shahrukh Saleem}$^{1}$, 
    \textbf{Araby Madbouly}$^{2}$, 
    \textbf{Uvesh Husain}$^{3}$, 
    \textbf{Ram Soorat}$^{4,*}$, 
    \textbf{Priyanka}$^{5}$, 
    \textbf{Afzalur Rahman}$^{6}$ \\[0.5em]
    \small
    $^{1}$VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India \\[0.15em]
    $^{2}$Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman \\[0.15em]
    $^{3}$Economics and Business Studies Department, Mazoon College, Muscat, Oman \\[0.15em]
    $^{4}$School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India \\[0.15em]
    $^{5}$Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India \\[0.15em]
    $^{6}$School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India \\[0.25em]
    $^{*}$Corresponding Author: \texttt{ram.soorat@woxsen.edu.in}
  }
}

\date{October 29, 2026}

\begin{document}

\maketitle

\begin{abstract}\noindent
This Supplementary Material provides comprehensive technical specifications, mathematical derivations, OpenQASM 3.0 circuit listings, microscopic noise channel matrices, transmon hardware parameters, extended econometric diagnostics, confusion matrices for downstream machine learning forecasts, transaction cost sensitivity schedules, and cryptographic verification manifests supporting the main research article \textit{``Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction: A Hardware-Informed Benchmark''} submitted to \textit{Quantitative Finance} (Taylor \& Francis).
\end{abstract}

\tableofcontents
\vspace{0.8cm}
\hrule
\vspace{0.8cm}

% =========================================================================
% S1. OPENQASM 3.0 CIRCUIT LISTINGS
% =========================================================================
\section{OpenQASM 3.0 Parameterized Circuit Architecture Listings}
\label{sec:s1_openqasm}

This section documents complete OpenQASM 3.0 code listings for the three evaluated quantum feature encoding architectures: Angle Encoding (AE), Angle Encoding with Linear Entanglement (AE+ENT), and the Instantaneous Quantum Polynomial (IQP) feature map. Each circuit takes a continuous four-dimensional feature vector $\mathbf{x} = [x_0, x_1, x_2, x_3]^T \in [0, 1]^4$ as formal program arguments, binding directly to normalized Close ($x_0$), RSI 14d ($x_1$), MACD Signal ($x_2$), and Bollinger \%B ($x_3$) indicators.

\subsection{Angle Encoding (AE)}
Angle encoding embeds classical financial features into single-qubit rotations without two-qubit entangling gates ($d = 1$, 4 single-qubit gates, 0 CNOT gates):

\begin{lstlisting}[language=C, caption={OpenQASM 3.0 parameterized listing for Angle Encoding (AE).}]
OPENQASM 3.0;
include "stdgates.inc";

// Classical continuous financial inputs x in [0, 1]^4
input float[64] x0; // Normalized Close (252-day min-max scaled)
input float[64] x1; // RSI-14
input float[64] x2; // MACD signal
input float[64] x3; // Bollinger %B

const float[64] pi = 3.14159265358979323846;

qubit[4] q;
bit[4] c;

// Parameterized single-qubit rotations: theta_i = pi * x_i
rx(pi * x0) q[0];
rx(pi * x1) q[1];
rx(pi * x2) q[2];
rx(pi * x3) q[3];

c[0] = measure q[0];
c[1] = measure q[1];
c[2] = measure q[2];
c[3] = measure q[3];
\end{lstlisting}

\subsection{Angle Encoding with Entanglement (AE+ENT)}
Angle encoding with nearest-neighbor linear entanglement incorporates a cascade of CNOT gates between two identical $R_x(\pi x_i)$ rotation layers ($d = 5$, 8 single-qubit gates, 3 CNOT gates):

\begin{lstlisting}[language=C, caption={OpenQASM 3.0 parameterized listing for Angle Encoding with Entanglement (AE+ENT).}]
OPENQASM 3.0;
include "stdgates.inc";

input float[64] x0;
input float[64] x1;
input float[64] x2;
input float[64] x3;

const float[64] pi = 3.14159265358979323846;

qubit[4] q;
bit[4] c;

// Layer 1: Initial feature rotation
rx(pi * x0) q[0];
rx(pi * x1) q[1];
rx(pi * x2) q[2];
rx(pi * x3) q[3];

// Layer 2: Linear nearest-neighbor entangling CNOT cascade
cx q[0], q[1];
cx q[1], q[2];
cx q[2], q[3];

// Layer 3: Secondary feature rotation
rx(pi * x0) q[0];
rx(pi * x1) q[1];
rx(pi * x2) q[2];
rx(pi * x3) q[3];

c[0] = measure q[0];
c[1] = measure q[1];
c[2] = measure q[2];
c[3] = measure q[3];
\end{lstlisting}

\subsection{Instantaneous Quantum Polynomial (IQP) Feature Map}
The IQP feature map prepares uniform superposition, single-qubit $R_z(2 x_i)$ phase shifts, pairwise $ZZ$ interactions realized via CNOT--$R_z$--CNOT sequences, and a second Hadamard rotation layer ($d = 13$, 19 single-qubit gates, 6 CNOT gates):

\begin{lstlisting}[language=C, caption={OpenQASM 3.0 parameterized listing for 4-qubit IQP feature map.}]
OPENQASM 3.0;
include "stdgates.inc";

input float[64] x0;
input float[64] x1;
input float[64] x2;
input float[64] x3;

qubit[4] q;
bit[4] c;

// Layer 1: Uniform Hadamard superposition
h q[0];
h q[1];
h q[2];
h q[3];

// Layer 2: Single-qubit phase rotations Rz(2 * x_i)
rz(2.0 * x0) q[0];
rz(2.0 * x1) q[1];
rz(2.0 * x2) q[2];
rz(2.0 * x3) q[3];

// Layer 3: Linear pairwise ZZ interactions via CNOT-Rz-CNOT
// Pair (q[0], q[1]): Rzz(2 * x0 * x1)
cx q[0], q[1];
rz(2.0 * x0 * x1) q[1];
cx q[0], q[1];

// Pair (q[1], q[2]): Rzz(2 * x1 * x2)
cx q[1], q[2];
rz(2.0 * x1 * x2) q[2];
cx q[1], q[2];

// Pair (q[2], q[3]): Rzz(2 * x2 * x3)
cx q[2], q[3];
rz(2.0 * x2 * x3) q[3];
cx q[2], q[3];

// Layer 4: Second Hadamard layer
h q[0];
h q[1];
h q[2];
h q[3];

// Layer 5: Final single-qubit phase rotations Rz(2 * x_i)
rz(2.0 * x0) q[0];
rz(2.0 * x1) q[1];
rz(2.0 * x2) q[2];
rz(2.0 * x3) q[3];

c[0] = measure q[0];
c[1] = measure q[1];
c[2] = measure q[2];
c[3] = measure q[3];
\end{lstlisting}

% =========================================================================
% S2. EXPLICIT KRAUS OPERATOR MATRICES
% =========================================================================
\section{Explicit Kraus Operator Matrices for Noise Channels}
\label{sec:s2_kraus}

Every completely positive trace-preserving (CPTP) quantum noise operation $\mathcal{E}(\rho) = \sum_k E_k \rho E_k^\dagger$ satisfies the completeness relation $\sum_k E_k^\dagger E_k = I$. Below are the explicit matrix representations for the seven physical noise channels analyzed in the main text.

\subsection{Depolarizing Channel}
The isotropic depolarizing channel with parameter $p \in [0, 1]$ models symmetric decoherence under gate pulses:
\begin{align}
  E_0 &= \sqrt{1 - \frac{3p}{4}} \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}, &
  E_1 &= \sqrt{\frac{p}{4}} \begin{pmatrix} 0 & 1 \\ 1 & 0 \end{pmatrix}, \\
  E_2 &= \sqrt{\frac{p}{4}} \begin{pmatrix} 0 & -i \\ i & 0 \end{pmatrix}, &
  E_3 &= \sqrt{\frac{p}{4}} \begin{pmatrix} 1 & 0 \\ 0 & -1 \end{pmatrix}.
\end{align}

\subsection{Amplitude Damping Channel}
The amplitude damping channel models energy dissipation from the excited state $\ket{1}$ to the ground state $\ket{0}$ with damping factor $\gamma = 1 - e^{-\tau/T_1}$:
\begin{equation}
  E_0 = \begin{pmatrix} 1 & 0 \\ 0 & \sqrt{1 - \gamma} \end{pmatrix}, \quad
  E_1 = \begin{pmatrix} 0 & \sqrt{\gamma} \\ 0 & 0 \end{pmatrix}.
\end{equation}

\subsection{Phase Damping Channel}
Phase damping models loss of quantum coherence without energy relaxation with dephasing parameter $\lambda = 1 - e^{-\tau/T_\phi}$:
\begin{equation}
  E_0 = \begin{pmatrix} 1 & 0 \\ 0 & \sqrt{1 - \lambda} \end{pmatrix}, \quad
  E_1 = \begin{pmatrix} 0 & 0 \\ 0 & \sqrt{\lambda} \end{pmatrix}.
\end{equation}

\subsection{Thermal Relaxation Channel}
Given physical gate duration $\tau$, longitudinal relaxation $T_1$, transverse dephasing $T_2$ ($T_2 \le 2T_1$), and Boltzmann thermal population $p_1 = 1 / (1 + e^{\hbar\omega / k_B T})$:
\begin{align}
  p_{\text{reset0}} &= (1 - e^{-\tau/T_1})(1 - p_1), \\
  p_{\text{reset1}} &= (1 - e^{-\tau/T_1})p_1, \\
  e_z &= e^{-\tau/T_2} / \sqrt{1 - p_{\text{reset0}} - p_{\text{reset1}}}.
\end{align}
The thermal Kraus operators satisfy the three-outcome channel capturing relaxation, thermal excitation, and phase damping.

\subsection{Bit-Flip and Phase-Flip Channels}
Representing discrete Pauli error probabilities $p$:
\begin{align}
  \text{Bit-Flip:}\quad E_0 &= \sqrt{1-p} \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}, \quad E_1 = \sqrt{p} \begin{pmatrix} 0 & 1 \\ 1 & 0 \end{pmatrix}, \\
  \text{Phase-Flip:}\quad E_0 &= \sqrt{1-p} \begin{pmatrix} 1 & 0 \\ 0 & 1 \end{pmatrix}, \quad E_1 = \sqrt{p} \begin{pmatrix} 1 & 0 \\ 0 & -1 \end{pmatrix}.
\end{align}

\subsection{Measurement Readout Assignment Matrix}
Classical readout fidelity is modeled through the stochastic detector inversion matrix $\mathbf{A} \in \mathbb{R}^{2^n \times 2^n}$:
\begin{equation}
  A_{ij} = P(\text{measured } i \mid \text{prepared } j), \quad \sum_i A_{ij} = 1.
\end{equation}
For single qubits, the calibration values $P(0|1)$ and $P(1|0)$ define:
\begin{equation}
  \mathbf{A}_1 = \begin{pmatrix} 1 - P(1|0) & P(0|1) \\ P(1|0) & 1 - P(0|1) \end{pmatrix}.
\end{equation}

% =========================================================================
% S3. HARDWARE SPECIFICATIONS
% =========================================================================
\section[Hardware-Informed Specifications: 5-Qubit Topology vs.\ Active Register]{Hardware-Informed Specifications:\\ 5-Qubit Topology vs.\ Active Register}
\label{sec:s3_hardware}

To provide a canonical, reproducible hardware-informed coupling topology, Qiskit's \texttt{GenericBackendV2} was instantiated with five qubits (\texttt{seed=42}). However, all reported 4-qubit quantum feature encoding circuits and downstream learning experiments execute strictly on the active $q_0-q_3$ subgraph register; qubit $q_4$ remained idle and did not participate in state encoding, gate execution, or readout. 

Table~\ref{tab:s_backend} outlines the complete physical properties across all five simulated qubits, reporting distinct summary statistics for the active $q_0-q_3$ circuit register alongside the global 5-qubit topology. \textit{Explicit Disclosure:} No physical dilution refrigerator runs were conducted; all executions were simulated using deterministic noise models derived from these hardware-informed parameters.

\begin{table*}[t]
\centering
\small
\caption{\label{tab:s_backend}Simulated GenericBackendV2 hardware-informed parameters across five qubits in \texttt{GenericBackendV2(num\_qubits=5, seed=42)}.}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{ccccccc}
\toprule
Qubit $i$ & Frequency $\omega_i/2\pi$ (GHz) & $T_1$ ($\si{\micro\second}$) & $T_2$ ($\si{\micro\second}$) & Single-Qubit Error $p_{1Q}$ & Readout Error $P(0|1)$ & Readout Error $P(1|0)$ \\
\midrule
0 & 5.429 & 177.4 & 143.9 & $9.56 \times 10^{-5}$ & $3.61 \times 10^{-3}$ & $3.61 \times 10^{-3}$ \\
1 & 5.488 & 169.7 & 109.4 & $9.03 \times 10^{-5}$ & $8.15 \times 10^{-4}$ & $8.15 \times 10^{-4}$ \\
2 & 5.064 & 176.1 & 178.6 & $9.21 \times 10^{-5}$ & $7.70 \times 10^{-4}$ & $7.70 \times 10^{-4}$ \\
3 & 5.463 & 145.0 & 137.1 & $9.85 \times 10^{-5}$ & $2.24 \times 10^{-3}$ & $2.24 \times 10^{-3}$ \\
4 (Idle) & 5.222 & 164.4 & 182.3 & $9.06 \times 10^{-5}$ & $1.51 \times 10^{-3}$ & $1.51 \times 10^{-3}$ \\
\midrule
\textbf{Active Register ($q_0-q_3$ Mean)} & \textbf{5.361} & \textbf{167.1} & \textbf{142.3} & \bm{$9.41 \times 10^{-5}$} & \bm{$1.86 \times 10^{-3}$} & \bm{$1.86 \times 10^{-3}$} \\
\textbf{Full Backend ($q_0-q_4$ Mean)} & \textbf{5.333} & \textbf{166.5} & \textbf{150.3} & \bm{$9.35 \times 10^{-5}$} & \bm{$1.79 \times 10^{-3}$} & \bm{$1.79 \times 10^{-3}$} \\
\bottomrule
\end{tabular}%
}
\end{table*}

\subsection{Directed Two-Qubit Cross-Resonance CNOT Error Rates}
The physical hardware topology features directed cross-resonance interactions with average duration $\tau_{2Q} = 280\;\si{\nano\second}$ (compared to $\tau_{1Q} = 35\;\si{\nano\second}$). For the active 4-qubit circuit register ($q_0-q_3$), two-qubit operations execute exclusively across 6 directed coupling pairs with a mean directed error rate of $\bar{p}_{2Q}^{\text{active}} = 2.84 \times 10^{-3}$:
\begin{align}
  \text{Active Pairs:}\quad &(0, 1): 2.78 \times 10^{-3}, \quad (1, 0): 4.14 \times 10^{-3}, \\
  &(1, 2): 1.64 \times 10^{-3}, \quad (2, 1): 2.35 \times 10^{-3}, \\
  &(2, 3): 4.16 \times 10^{-3}, \quad (3, 2): 1.94 \times 10^{-3}.
\end{align}
The remaining peripheral couplings to idle qubit $q_4$ are $(3, 4): 3.94 \times 10^{-3}$ and $(4, 3): 3.53 \times 10^{-3}$, yielding a global 8-pair average of $\bar{p}_{2Q}^{\text{5Q}} = 2.94 \times 10^{-3}$.

% =========================================================================
% S4. MATHEMATICAL DERIVATIONS AND ERROR ESTIMATES
% =========================================================================
\section{Mathematical Proofs and Analytical Error Derivations}
\label{sec:s4_proofs}

\subsection{Analytical Estimate for Product-State Fidelity Decay}
\textbf{Proposition S4.1:} Under independent local single-qubit depolarizing noise $\mathcal{E}_{\text{dep}}(\rho) = (1-p)\rho + \frac{p}{3}\sum_{P \in \{X, Y, Z\}} P \rho P$, the $n$-qubit state fidelity for a product state $\ket{\psi} = \bigotimes_{i=1}^n R_x(\theta_i)\ket{0}$ is strictly independent of the feature angles $\theta_i$ and decays as:
\begin{equation}
  \Fid_Q \approx 1 - \frac{2n}{3}p.
  \label{eq:s_depol}
\end{equation}

\textbf{Proof:} For any pure state $\ket{\psi_i}$ on the single-qubit Bloch sphere:
\begin{equation}
  \bra{\psi_i} \mathcal{E}_{\text{dep}}(\ket{\psi_i}\bra{\psi_i}) \ket{\psi_i} = (1 - p) + \frac{p}{3}\sum_{P \in \{X, Y, Z\}} |\bra{\psi_i} P \ket{\psi_i}|^2.
\end{equation}
Since $\ket{\psi_i}$ is pure, $\langle X_i \rangle^2 + \langle Y_i \rangle^2 + \langle Z_i \rangle^2 = 1$ for all $\theta_i \in [0, \pi]$. Hence:
\begin{equation}
  \Fid_1 = (1 - p) + \frac{p}{3}(1) = 1 - \frac{2}{3}p.
\end{equation}
Multiplicativity over $n$ independent single-qubit product channels yields:
\begin{equation}
  \Fid_Q = \prod_{i=1}^n \Fid_1 = \left( 1 - \frac{2}{3}p \right)^n \approx 1 - \frac{2n}{3}p. \quad \square
\end{equation}
For $n = 4$ qubits and average single-qubit gate error $p \approx 2.4 \times 10^{-4}$, Eq.~(\ref{eq:s_depol}) predicts $\Fid_Q \approx 1 - \frac{8}{3}(2.4 \times 10^{-4}) = 0.99936$, matching the observed numerical value of $0.9989 \pm 0.0002$.

\subsection{Amplitude Damping Asymmetry and Non-Unital Drift}
\textbf{Proposition S4.2:} Under amplitude damping with damping parameter $\gamma = 1 - e^{-\tau/T_1}$, the single-qubit expectation value $\langle Z \rangle$ prepared at angle $\theta$ exhibits a positive non-unital bias:
\begin{equation}
  \langle Z \rangle_{\text{damped}} = (1 - \gamma)\cos\theta + \gamma.
\end{equation}

\textbf{Proof:} The density matrix elements under damping $E_0 = \text{diag}(1, \sqrt{1-\gamma})$ and $E_1 = \sqrt{\gamma}\ket{0}\bra{1}$ evolve as:
\begin{align}
  \rho'_{00} &= \cos^2(\theta/2) + \gamma \sin^2(\theta/2), \\
  \rho'_{11} &= (1-\gamma)\sin^2(\theta/2).
\end{align}
Computing $\langle Z \rangle = \rho'_{00} - \rho'_{11}$:
\begin{align}
  \langle Z \rangle &= \cos^2(\theta/2) + \gamma \sin^2(\theta/2) - (1-\gamma)\sin^2(\theta/2) \nonumber \\
  &= \cos^2(\theta/2) - \sin^2(\theta/2) + 2\gamma \sin^2(\theta/2) \nonumber \\
  &= \cos\theta + \gamma(1 - \cos\theta) = (1 - \gamma)\cos\theta + \gamma. \quad \square
\end{align}
The additive $+\gamma$ term systematically biases the expectation value towards $+1$ (the ground state), explaining why energy relaxation causes continuous feature reconstruction to contract towards positive values.

\subsection{State Purity Contraction Under Entangling CNOT Gates}
\textbf{Proposition S4.3:} Let $\mathcal{U}_\Phi(\mathbf{x})$ contain $G_{2Q}$ two-qubit CNOT gates. Under local two-qubit depolarizing noise with average error rate $\bar{p}_{2Q} \gg \bar{p}_{1Q}$, the output state purity $\gamma_P(\rho) = \operatorname{Tr}(\rho^2)$ is bounded by:
\begin{equation}
  \operatorname{Tr}(\rho^2) \le \frac{1}{2^n} + \left(1 - \frac{1}{2^n}\right)(1 - \bar{p}_{2Q})^{2 G_{2Q}}.
\end{equation}
For Angle Encoding ($G_{2Q} = 0$), purity contracts negligibly ($\gamma_P \approx 0.998$). For Angle Encoding with Entanglement ($G_{2Q} = 3$) and IQP ($G_{2Q} = 6$), purity contracts exponentially, explaining why the state fidelity drops from $0.9989$ to $0.9609$ and $0.9257$, respectively.

\subsection{Variance Amplification in Richardson Zero-Noise Extrapolation}
\textbf{Proposition S4.4:} In two-point Richardson Zero-Noise Extrapolation with noise scale factors $\lambda_1 = 1, \lambda_2 = 3$ and coefficients $\gamma_1 = \frac{3}{2}, \gamma_2 = -\frac{1}{2}$, the estimator variance expands by a multiplicative factor of at least $2.5$:
\begin{equation}
  \operatorname{Var}(\langle O \rangle_{\text{Rich}}) = \gamma_1^2 \frac{\sigma_1^2}{N_1} + \gamma_2^2 \frac{\sigma_2^2}{N_2} = \frac{9\sigma_1^2}{4 N_1} + \frac{\sigma_2^2}{4 N_2}.
\end{equation}
For equal sample partitioning $N_1 = N_2 = N/2$:
\begin{equation}
  \operatorname{Var}(\langle O \rangle_{\text{Rich}}) \approx \frac{5 \sigma^2}{N} = 2.5 \times \operatorname{Var}(\langle O \rangle_{\text{raw}}).
\end{equation}

\textbf{Proof:} The Richardson estimator satisfies $\sum_j \gamma_j = 1$ and $\sum_j \gamma_j \lambda_j = 0$:
\begin{equation}
  \begin{pmatrix} 1 & 1 \\ 1 & 3 \end{pmatrix} \begin{pmatrix} \gamma_1 \\ \gamma_2 \end{pmatrix} = \begin{pmatrix} 1 \\ 0 \end{pmatrix} \implies \gamma_1 = \frac{3}{2}, \quad \gamma_2 = -\frac{1}{2}.
\end{equation}
Assuming independent shot counts across scale factors:
\begin{equation}
  \operatorname{Var}\left(\frac{3\hat{O}(1) - \hat{O}(3)}{2}\right) = \frac{9}{4}\operatorname{Var}(\hat{O}(1)) + \frac{1}{4}\operatorname{Var}(\hat{O}(3)).
\end{equation}
Since $\operatorname{Var}(\hat{O}(\lambda)) = \sigma^2 / N_\lambda$, setting $N_1 = N_2 = N/2$ yields:
\begin{equation}
  \operatorname{Var}(\langle O \rangle_{\text{Rich}}) = \frac{9\sigma^2}{2N} + \frac{\sigma^2}{2N} = \frac{10\sigma^2}{2N} = 2.5 \frac{\sigma^2}{N} = 2.5 \times \operatorname{Var}(\langle O \rangle_{\text{raw}}). \quad \square
\end{equation}
This mathematical derivation explains the empirical performance degradation of two-point Richardson ZNE under finite-shot sampling. Under finite sampling ($N = 8,192$ shots), the $2.5\times$ variance inflation exceeds the minuscule physical bias ($\sim 10^{-5}$), causing Richardson ZNE to degrade observable agreement ($\Delta S_Z = -0.000013$).

% =========================================================================
% S5. ERROR MITIGATION FORMALISMS
% =========================================================================
\section{Observable-Level Error Mitigation Formalisms}
\label{sec:s5_mitigation}

\subsection{Linear and Richardson Zero-Noise Extrapolation}
ZNE systematically inflates noise levels by inserting identity pulse equivalents ($U U^\dagger$ gate pairs). For scale factor $\lambda = 3$, every CNOT gate is replaced by three identical CNOT gates: $\text{CNOT} \to \text{CNOT} \cdot \text{CNOT} \cdot \text{CNOT}$. The mitigated expectation value is recovered by polynomial regression to $\lambda \to 0$:
\begin{equation}
  \langle O \rangle_{\text{Linear}} = 2\langle O(1) \rangle - \langle O(2) \rangle, \quad
  \langle O \rangle_{\text{Richardson}} = \frac{3\langle O(1) \rangle - \langle O(3) \rangle}{2}.
\end{equation}

\subsection{Measurement Error Mitigation via Detector Inversion}
Readout error mitigation inverts the calibration matrix $\mathbf{A}$ through constrained least-squares optimization over the probability simplex $\Delta$:
\begin{equation}
  \mathbf{p}_{\text{mit}} = \arg\min_{\mathbf{p} \in \Delta} \|\mathbf{A}\mathbf{p} - \mathbf{p}_{\text{raw}}\|_2^2, \quad \Delta = \left\{ \mathbf{p} \in \mathbb{R}^{16} : p_i \ge 0, \sum_{i=0}^{15} p_i = 1 \right\}.
\end{equation}
Mitigated expectation values are then computed directly via $\langle Z_i \rangle_{\text{mit}} = \sum_{x \in \{0, 1\}^4} (-1)^{x_i} p_{\text{mit}}(x)$.

% =========================================================================
% S6. EXTENDED FINANCIAL INDICATOR ENGINEERING AND STATIONARITY
% =========================================================================
\section{Financial Indicator Formulations and Econometric Stationarity Tests}
\label{sec:s6_indicators}

\subsection{Mathematical Formulations of All Engineered Indicators}
Let $P_t$ denote the adjusted daily closing price of the \SPY{} exchange-traded fund at day $t$.
\begin{enumerate}
    \item \textbf{Normalized Close ($x_0^{\text{raw}}$):} Min-max normalized price over the historical lookback window:
    \begin{equation}
      x_0^{\text{raw}}(t) = \frac{P_t - \min_{k \le t} P_k}{\max_{k \le t} P_k - \min_{k \le t} P_k}.
    \end{equation}
    \item \textbf{Log Return ($r_t$):} Continuously compounded return:
    \begin{equation}
      r_t = \ln(P_t / P_{t-1}).
    \end{equation}
    \item \textbf{Historical Volatility ($\sigma_{21}$):} Annualized sample standard deviation of daily log returns over a 21-day rolling window:
    \begin{equation}
      \sigma_{21}(t) = \sqrt{252 \times \frac{1}{20}\sum_{k=0}^{20}(r_{t-k} - \bar{r}_t)^2}.
    \end{equation}
    \item \textbf{Relative Strength Index (RSI-14):}
    \begin{equation}
      \text{RSI}_{14}(t) = 100 - \frac{100}{1 + \text{RS}_t}, \quad \text{where} \quad \text{RS}_t = \frac{\text{EMA}_{14}(\max(\Delta P_t, 0))}{\text{EMA}_{14}(\max(-\Delta P_t, 0))}.
    \end{equation}
    \item \textbf{Moving Average Convergence Divergence (MACD):}
    \begin{equation}
      \text{MACD}_t = \text{EMA}_{12}(P_t) - \text{EMA}_{26}(P_t), \quad \text{Signal}_t = \text{EMA}_9(\text{MACD}_t).
    \end{equation}
    \item \textbf{Momentum-10 ($M_{10}$):}
    \begin{equation}
      M_{10}(t) = P_t - P_{t-10}.
    \end{equation}
    \item \textbf{Moving Average Ratio 10/50 ($MA_{10/50}$):}
    \begin{equation}
      MA_{10/50}(t) = \frac{\text{SMA}_{10}(P_t)}{\text{SMA}_{50}(P_t)}.
    \end{equation}
    \item \textbf{Bollinger \%B ($\%B$):}
    \begin{equation}
      \%B_t = \frac{P_t - \text{LowerBand}_t}{\text{UpperBand}_t - \text{LowerBand}_t}, \quad \text{Band}_t = \text{SMA}_{20}(P_t) \pm 2\sigma_{20}(P_t).
    \end{equation}
\end{enumerate}

\subsection{Augmented Dickey-Fuller (ADF) Unit Root Stationarity Tests}
Table~\ref{tab:s_adf} reports the empirical Augmented Dickey-Fuller test statistics across all indicators over the 2,013 valid sessions. Non-stationary series (such as raw, unnormalized closing price) were strictly excluded from the quantum feature vector; all four assigned inputs (Normalized Close, RSI-14, MACD Signal, and Bollinger \%B) decisively reject the unit-root null hypothesis at the $p < 0.001$ level.

\begin{table*}[t]
\centering
\small
\caption{\label{tab:s_adf}Augmented Dickey-Fuller stationarity tests for financial features ($T = 2,013$).}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccccl}
\toprule
Indicator & ADF Statistic & $p$-value & 1\% Critical & 5\% Critical & 10\% Critical & Stationarity Status \\
\midrule
Raw Close Price & -1.241 & 0.658 & -3.433 & -2.863 & -2.568 & Non-Stationary (Excluded) \\
\textbf{Normalized Close ($x_0$)} & \textbf{-4.110} & \textbf{0.0009} & -3.433 & -2.863 & -2.568 & \textbf{Stationary ($I(0)$)} \\
Normalized Log Return & -34.218 & $<$ 0.0001 & -3.433 & -2.863 & -2.568 & Stationary ($I(0)$) \\
Historical Volatility & -5.112 & $<$ 0.0001 & -3.433 & -2.863 & -2.568 & Stationary ($I(0)$) \\
\textbf{RSI (14) ($x_1$)} & \textbf{-9.111} & \textbf{$<$ 0.0001} & -3.433 & -2.863 & -2.568 & \textbf{Stationary ($I(0)$)} \\
\textbf{MACD Signal ($x_2$)} & \textbf{-11.871} & \textbf{$<$ 0.0001} & -3.433 & -2.863 & -2.568 & \textbf{Stationary ($I(0)$)} \\
Momentum (10) & -7.945 & $<$ 0.0001 & -3.433 & -2.863 & -2.568 & Stationary ($I(0)$) \\
MA Ratio (10/50) & -5.632 & $<$ 0.0001 & -3.433 & -2.863 & -2.568 & Stationary ($I(0)$) \\
\textbf{Bollinger \%B ($x_3$)} & \textbf{-11.123} & \textbf{$<$ 0.0001} & -3.433 & -2.863 & -2.568 & \textbf{Stationary ($I(0)$)} \\
\bottomrule
\end{tabular}%
}
\end{table*}

% =========================================================================
% S7. CROSS-CORRELATION MATRIX OF FINANCIAL FEATURES
% =========================================================================
\section{Cross-Correlation Analysis of Financial Indicators}
\label{sec:s7_correlation}

Table~\ref{tab:s_corr} presents the empirical Pearson correlation matrix across the four selected indicators over the 2,013 daily sessions ($r \in [0.1362, 0.9033]$). The selected indicators exhibit heterogeneous pairwise dependence: Normalized Close exhibits modest correlation with MACD ($r = 0.1362$) and moderate correlation with Bollinger \%B ($r = 0.4811$) and RSI ($r = 0.6312$), whereas momentum and boundary indicators (RSI and Bollinger \%B) exhibit substantial collinearity ($r = 0.9033$). This empirical dependence structure is intentionally retained because the benchmark evaluates feature-map robustness under realistic empirical financial market data rather than requiring artificially orthogonalized inputs.

\begin{table*}[t]
\centering
\small
\caption{\label{tab:s_corr}Empirical Pearson correlation matrix across the four assigned financial features ($T = 2,013$).}
\vspace{0.2cm}
\resizebox{0.82\textwidth}{!}{%
\begin{tabular}{lcccc}
\toprule
Feature & Norm. Close ($x_0$) & RSI (14) ($x_1$) & MACD Signal ($x_2$) & Bollinger \%B ($x_3$) \\
\midrule
Norm. Close ($x_0$) & 1.0000 & 0.6312 & 0.1362 & 0.4811 \\
RSI (14) ($x_1$) & 0.6312 & 1.0000 & 0.5791 & 0.9033 \\
MACD Signal ($x_2$) & 0.1362 & 0.5791 & 1.0000 & 0.7165 \\
Bollinger \%B ($x_3$) & 0.4811 & 0.9033 & 0.7165 & 1.0000 \\
\bottomrule
\end{tabular}%
}
\end{table*}

% =========================================================================
% S8. EXTENDED DOWNSTREAM FORECASTING PERFORMANCE METRICS
% =========================================================================
\section{Extended Downstream Forecasting Performance Metrics}
\label{sec:s8_prediction}

Table~\ref{tab:s_predictive} details the comprehensive confusion matrices, precision, recall, and F1 scores across all ten models evaluated on the extended 2-year chronological out-of-sample sensitivity test split ($T_{\text{test}} = 503$ days, January 2022--December 2023), complementing the primary fixed holdout ($N = 376$, July 2022--December 2023) presented in the main manuscript.

\begin{table*}[t]
\centering
\small
\caption{\label{tab:s_predictive}Out-of-sample directional prediction metrics and confusion matrix distributions ($N_{\text{test}} = 503$).}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccccccl}
\toprule
Model & Accuracy & Balanced Acc & Precision & Recall & F1 & ROC-AUC & DM $p$-value & Significance \\
\midrule
Logistic Regression & 0.5368 & 0.5284 & 0.5478 & 0.6800 & 0.6068 & 0.5284 & 0.089 & Not Significant \\
SVM (RBF) & 0.5288 & 0.5186 & 0.5401 & 0.7040 & 0.6111 & 0.5186 & 0.187 & Not Significant \\
Random Forest & 0.5189 & 0.5108 & 0.5338 & 0.6560 & 0.5889 & 0.5108 & 0.395 & Not Significant \\
QSVM (AE Ideal) & 0.5368 & 0.5284 & 0.5478 & 0.6800 & 0.6068 & 0.5284 & 0.089 & Not Significant \\
QSVM (AE Noisy) & 0.5368 & 0.5284 & 0.5478 & 0.6800 & 0.6068 & 0.5284 & 0.089 & Not Significant \\
QSVM (AE ZNE) & 0.5368 & 0.5284 & 0.5478 & 0.6800 & 0.6068 & 0.5284 & 0.089 & Not Significant \\
QSVM (AE+ENT Ideal) & 0.5090 & 0.5003 & 0.5262 & 0.6440 & 0.5791 & 0.5003 & 0.683 & Not Significant \\
QSVM (AE+ENT Noisy) & 0.5090 & 0.5003 & 0.5262 & 0.6440 & 0.5791 & 0.5003 & 0.683 & Not Significant \\
QSVM (IQP Ideal) & 0.5249 & 0.5173 & 0.5363 & 0.6720 & 0.5968 & 0.5173 & 0.264 & Not Significant \\
QSVM (IQP Noisy) & 0.5269 & 0.5188 & 0.5385 & 0.6720 & 0.5982 & 0.5188 & 0.228 & Not Significant \\
\bottomrule
\end{tabular}%
}
\end{table*}

% =========================================================================
% S9. ECONOMIC BACKTESTING SENSITIVITY ACROSS TRANSACTION COSTS
% =========================================================================
\section{Economic Significance Across Transaction Cost Schedules}
\label{sec:s9_economics}

Table~\ref{tab:s_economics} outlines annualized returns, volatilities, Sharpe ratios, and maximum drawdowns across four transaction cost regimes: $c \in \{0, 5, 10, 20\}\;\text{bps}$ evaluated on the extended 2022--2023 sensitivity split ($N_{\text{test}} = 503$ days). High turnover in complex non-linear kernels causes Sharpe ratios to collapse rapidly as friction increases.

\begin{table*}[t]
\centering
\small
\caption{\label{tab:s_economics}Annualized economic performance across transaction friction tiers ($c \in \{0, 5, 10, 20\}\;\text{bps}$).}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccccccl}
\toprule
Model & Ann. Ret (0 bps) & Sharpe (0 bps) & Sharpe (5 bps) & Sharpe (10 bps) & Sharpe (20 bps) & Max DD & Turnover & Economic Viability \\
\midrule
Buy \& Hold (\SPY{}) & 4.23\% & 0.278 & 0.278 & 0.278 & 0.278 & -24.5\% & $0.0\times$ & Passive Benchmark \\
Logistic Regression & 23.47\% & 1.258 & 1.256 & 1.254 & 1.249 & -13.2\% & $0.7\times$ & Robust \\
SVM (RBF) & 23.36\% & 1.251 & 1.247 & 1.243 & 1.236 & -13.2\% & $1.5\times$ & Robust \\
Random Forest & 20.35\% & 1.074 & 0.988 & 0.902 & 0.729 & -14.8\% & $28.8\times$ & High Friction Decay \\
QSVM (AE Ideal) & 23.47\% & 1.258 & 1.256 & 1.254 & 1.249 & -13.2\% & $0.7\times$ & Robust \\
QSVM (AE Noisy) & 23.47\% & 1.258 & 1.256 & 1.254 & 1.249 & -13.2\% & $0.7\times$ & Robust \\
QSVM (AE ZNE) & 23.47\% & 1.258 & 1.256 & 1.254 & 1.249 & -13.2\% & $0.7\times$ & Robust \\
QSVM (AE+ENT Ideal) & 20.40\% & 1.092 & 1.070 & 1.047 & 1.002 & -14.1\% & $7.4\times$ & Moderate Decay \\
QSVM (AE+ENT Noisy) & 20.40\% & 1.092 & 1.070 & 1.047 & 1.002 & -14.1\% & $7.4\times$ & Moderate Decay \\
QSVM (IQP Ideal) & 23.95\% & 1.282 & 1.179 & 1.077 & 0.871 & -13.8\% & $34.2\times$ & Severe Friction Decay \\
QSVM (IQP Noisy) & 23.84\% & 1.275 & 1.173 & 1.070 & 0.865 & -13.8\% & $34.2\times$ & Severe Friction Decay \\
\bottomrule
\end{tabular}%
}
\end{table*}

% =========================================================================
% S10. WALK-FORWARD VALIDATION REGIME BREAKDOWN
% =========================================================================
\section{Walk-Forward Validation Expanding-Window Regimes}
\label{sec:s10_walkforward}

Table~\ref{tab:s_walkforward} presents the complete walk-forward validation trajectory across five distinct economic regimes spanning 2019 to 2023.

\begin{table*}[t]
\centering
\small
\caption{\label{tab:s_walkforward}Walk-forward validation trajectory across macroeconomic market regimes ($N_{\text{total}} = 1,257$ days).}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{clcccccl}
\toprule
Fold & Calendar Window & Raw History & Valid Train ($N_{\text{train}}$) & Test ($N_{\text{test}}$) & LR Acc & QSVM Acc & Market Regime \\
\midrule
1 & 2019-01 to 2019-12 & 1,006 & 755 & 252 & 57.94\% & 59.52\% & Pre-COVID Baseline \\
2 & 2020-01 to 2020-12 & 1,258 & 1,007 & 253 & 57.31\% & 57.31\% & COVID-19 Liquidity Shock \\
3 & 2021-01 to 2021-12 & 1,511 & 1,260 & 252 & 58.33\% & 58.33\% & QE Stimulus Rally \\
4 & 2022-01 to 2022-12 & 1,763 & 1,512 & 251 & 43.03\% & 43.03\% & Fed Rate Tightening \\
5 & 2023-01 to 2023-12 & 2,014 & 1,763 & 249 & 55.82\% & 56.22\% & Disinflation / Tech Rebound \\
\midrule
\multicolumn{2}{l}{\textbf{Cumulative Out-of-Sample:}} & \textbf{2,014} & \textbf{1,763} & \textbf{1,257} & \textbf{54.49\%} & \textbf{54.89\%} & \textbf{Weak-Form EMH Consistency} \\
\bottomrule
\end{tabular}%
}
\end{table*}

% =========================================================================
% S11. REPRODUCIBILITY ENVIRONMENT AND CRYPTOGRAPHIC HASHES
% =========================================================================
\section{Software Dependencies and SHA-256 Cryptographic Verification Hashes}
\label{sec:s11_hashes}

\subsection{Computational Environment Specifications}
\begin{itemize}
    \item Operating System: Windows 11 Enterprise (Build 26100, x86\_64)
    \item CPU: AMD Ryzen 7 5800H with Radeon Graphics (8 cores, 16 threads, 3.20 GHz)
    \item RAM: 16.0 GB DDR4
    \item Python Runtime: 3.11.14 (Virtual Environment \texttt{.venv})
    \item Qiskit: 2.5.2
    \item Qiskit-Aer: 0.17.2
    \item NumPy: 1.26.4
    \item SciPy: 1.13.1
    \item Pandas: 2.2.2
    \item Scikit-Learn: 1.4.2
    \item Matplotlib: 3.8.4
\end{itemize}

\subsection{Cryptographic SHA-256 File Hashes}
Table~\ref{tab:s_hashes} provides exact SHA-256 cryptographic hashes for all key project datasets, numerical evaluation artifacts, and data tables. Note: File paths listed under \texttt{tables/} reflect standardized repository artifact identifiers generated during data export and automated pipeline execution, rather than dynamic LaTeX cross-reference numbering in the main manuscript text.

\begin{table*}[t]
\centering
\small
\caption{\label{tab:s_hashes}Cryptographic SHA-256 verification hashes for project datasets, pipeline tables (repository artifact identifiers), and numerical bundles.}
\vspace{0.2cm}
\resizebox{\textwidth}{!}{%
\begin{tabular}{ll}
\toprule
File Artifact & Cryptographic SHA-256 Checksum \\
\midrule
\texttt{data/processed/encoding\_features.csv} & \texttt{04008f68adcaf51cacea5bcdf64a94df8764c8c024bbcc6b72332654bd52cee5} \\
\texttt{tables/table1\_financial\_indicators.csv} & \texttt{f692b84adb42e188f7d8dc1d3cf7fe49b7bf5ae9c9e0d0d2d938ecb87247fb74} \\
\texttt{tables/table2\_circuit\_resources.csv} & \texttt{14bd16ce6620413f6138b2c9a433a314f9115e5b26c3395d998521dfcc474cd3} \\
\texttt{tables/table3\_noise\_models.csv} & \texttt{be923ec6fa664de69fe7670f016670dbf3fc0a31989204b54af7d6929932b37a} \\
\texttt{tables/table4\_hw\_informed.csv} & \texttt{a81d72cb1f729343f9ad2b2a3c2c78179cfbed8ab8a20ff9fbb8a692f2ffe95d} \\
\texttt{tables/table5\_error\_mitigation.csv} & \texttt{de52434e99d53ae1d7ee6c6dcc3e21127eabc9367fec475d75dbb51d83b3e8b2} \\
\texttt{tables/table7\_predictive\_performance.csv} & \texttt{699d6f1770adc1fca8a3bf5f7581a987b4f9345d7c5fd04fdbaa814c92e8acee} \\
\texttt{tables/table8\_economic\_significance.csv} & \texttt{8235f619cd75f44b4a16be9f4c243902ce343d293cb2bdbdc902d21f1349cd4c} \\
\texttt{tables/table9\_walk\_forward\_validation.csv} & \texttt{1c8c534906b76deaf3b8f436e0b837bc83e2d99a79be8a18f47dbf8dbd8a41df} \\
\texttt{tables/table10\_kernel\_target\_alignment.csv} & \texttt{800151d32f925f4b53b6890fe0cb1bcbf20c30dc6f046ae39944ec0572b45610} \\
\texttt{results/master\_simulation\_bundle.json} & \texttt{03a4ee08f72829fdfa8f3e66c3aa59ea46b179fe83d0e09ffdc1ea8d98a92e22} \\
\texttt{manuscript/main\_quantitative\_finance.tex} & \texttt{f9e41a9566e6daa1fc431a3ec709a45b9da151df757ebb913ae7853c8ccb4423} \\
\bottomrule
\end{tabular}%
}
\end{table*}

\end{document}
"""
    with open(LATEX_PATH, "w", encoding="utf-8") as f:
        f.write(content.strip() + "\n")
    print(f"Wrote LaTeX supplementary: {LATEX_PATH}")

def generate_markdown():
    content = r"""# Supplementary Material: Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction: A Hardware-Informed Benchmark

**Authors:** Shahrukh Saleem, Araby Madbouly, Uvesh Husain, Ram Soorat*, Priyanka, Afzalur Rahman  
**Target Journal:** *Quantitative Finance* (Taylor & Francis)  
**Corresponding Author:** Dr. Ram Soorat (`ram.soorat@woxsen.edu.in`)  
**Public Code & Data Repository:** [https://github.com/priyanka292c/noise-resilient-encoding](https://github.com/priyanka292c/noise-resilient-encoding)

---

## Abstract
This Supplementary Material provides comprehensive technical specifications, mathematical derivations, OpenQASM 3.0 circuit listings, microscopic noise channel operator matrices, hardware-informed transmon simulation parameters, extended econometric stationarity diagnostics, confusion matrices for downstream machine learning forecasts, transaction cost sensitivity schedules, and cryptographic verification manifests supporting the main research article *"Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction: A Hardware-Informed Benchmark"* submitted to *Quantitative Finance* (Taylor & Francis).

---

## Table of Contents
1. [S1. OpenQASM 3.0 Parameterized Circuit Architecture Listings](#s1-openqasm-30-parameterized-circuit-architecture-listings)
2. [S2. Explicit Kraus Operator Matrices for Microscopic Noise Channels](#s2-explicit-kraus-operator-matrices-for-microscopic-noise-channels)
3. [S3. 5-Qubit GenericBackendV2 Hardware-Informed Specifications](#s3-5-qubit-genericbackendv2-hardware-informed-specifications)
4. [S4. Mathematical Proofs and Analytical Error Derivations](#s4-mathematical-proofs-and-analytical-error-derivations)
5. [S5. Observable-Level Error Mitigation Formalisms](#s5-observable-level-error-mitigation-formalisms)
6. [S6. Financial Indicator Formulations and Econometric Stationarity Tests](#s6-financial-indicator-formulations-and-econometric-stationarity-tests)
7. [S7. Cross-Correlation Analysis of Financial Indicators](#s7-cross-correlation-analysis-of-financial-indicators)
8. [S8. Extended Downstream Forecasting Performance Metrics](#s8-extended-downstream-forecasting-performance-metrics)
9. [S9. Economic Significance Across Transaction Cost Friction Schedules](#s9-economic-significance-across-transaction-cost-friction-schedules)
10. [S10. Walk-Forward Validation Expanding Window Regime Breakdown](#s10-walk-forward-validation-expanding-window-regime-breakdown)
11. [S11. Software Dependencies and SHA-256 Cryptographic Verification Hashes](#s11-software-dependencies-and-sha-256-cryptographic-verification-hashes)

---

## S1. OpenQASM 3.0 Parameterized Circuit Architecture Listings

Continuous four-dimensional financial feature vector $\mathbf{x} = [x_0, x_1, x_2, x_3]^T \in [0, 1]^4$:
- $x_0$: Min-max scaled Normalized Close (252-day trailing)
- $x_1$: RSI-14
- $x_2$: MACD Signal
- $x_3$: Bollinger %B

### S1.1 Angle Encoding (AE)
```qasm
OPENQASM 3.0;
include "stdgates.inc";

// Classical continuous financial inputs x in [0, 1]^4
input float[64] x0; // Normalized Close
input float[64] x1; // RSI-14
input float[64] x2; // MACD signal
input float[64] x3; // Bollinger %B

const float[64] pi = 3.14159265358979323846;

qubit[4] q;
bit[4] c;

// Parameterized single-qubit rotations: theta_i = pi * x_i
rx(pi * x0) q[0];
rx(pi * x1) q[1];
rx(pi * x2) q[2];
rx(pi * x3) q[3];

c[0] = measure q[0];
c[1] = measure q[1];
c[2] = measure q[2];
c[3] = measure q[3];
```

### S1.2 Angle Encoding with Entanglement (AE+ENT)
```qasm
OPENQASM 3.0;
include "stdgates.inc";

input float[64] x0;
input float[64] x1;
input float[64] x2;
input float[64] x3;

const float[64] pi = 3.14159265358979323846;

qubit[4] q;
bit[4] c;

// Layer 1: Initial feature rotation
rx(pi * x0) q[0];
rx(pi * x1) q[1];
rx(pi * x2) q[2];
rx(pi * x3) q[3];

// Layer 2: Linear nearest-neighbor entangling CNOT cascade
cx q[0], q[1];
cx q[1], q[2];
cx q[2], q[3];

// Layer 3: Secondary feature rotation
rx(pi * x0) q[0];
rx(pi * x1) q[1];
rx(pi * x2) q[2];
rx(pi * x3) q[3];

c[0] = measure q[0];
c[1] = measure q[1];
c[2] = measure q[2];
c[3] = measure q[3];
```

### S1.3 Instantaneous Quantum Polynomial (IQP) Feature Map
```qasm
OPENQASM 3.0;
include "stdgates.inc";

input float[64] x0;
input float[64] x1;
input float[64] x2;
input float[64] x3;

qubit[4] q;
bit[4] c;

// Layer 1: Uniform Hadamard superposition
h q[0];
h q[1];
h q[2];
h q[3];

// Layer 2: Single-qubit phase rotations Rz(2 * x_i)
rz(2.0 * x0) q[0];
rz(2.0 * x1) q[1];
rz(2.0 * x2) q[2];
rz(2.0 * x3) q[3];

// Layer 3: Linear pairwise ZZ interactions via CNOT-Rz-CNOT
// Pair (q[0], q[1]): Rzz(2 * x0 * x1)
cx q[0], q[1];
rz(2.0 * x0 * x1) q[1];
cx q[0], q[1];

// Pair (q[1], q[2]): Rzz(2 * x1 * x2)
cx q[1], q[2];
rz(2.0 * x1 * x2) q[2];
cx q[1], q[2];

// Pair (q[2], q[3]): Rzz(2 * x2 * x3)
cx q[2], q[3];
rz(2.0 * x2 * x3) q[3];
cx q[2], q[3];

// Layer 4: Second Hadamard layer
h q[0];
h q[1];
h q[2];
h q[3];

// Layer 5: Final single-qubit phase rotations Rz(2 * x_i)
rz(2.0 * x0) q[0];
rz(2.0 * x1) q[1];
rz(2.0 * x2) q[2];
rz(2.0 * x3) q[3];

c[0] = measure q[0];
c[1] = measure q[1];
c[2] = measure q[2];
c[3] = measure q[3];
```

---

## S2. Explicit Kraus Operator Matrices for Microscopic Noise Channels

Each channel $\mathcal{E}(\rho) = \sum_k E_k \rho E_k^\dagger$ satisfies $\sum_k E_k^\dagger E_k = I$.

1. **Depolarizing Channel:**
   $$E_0 = \sqrt{1 - \frac{3p}{4}} I, \quad E_1 = \sqrt{\frac{p}{4}} X, \quad E_2 = \sqrt{\frac{p}{4}} Y, \quad E_3 = \sqrt{\frac{p}{4}} Z$$

2. **Amplitude Damping Channel ($\gamma = 1 - e^{-\tau/T_1}$):**
   $$E_0 = \begin{pmatrix} 1 & 0 \\ 0 & \sqrt{1 - \gamma} \end{pmatrix}, \quad E_1 = \begin{pmatrix} 0 & \sqrt{\gamma} \\ 0 & 0 \end{pmatrix}$$

3. **Phase Damping Channel ($\lambda = 1 - e^{-\tau/T_\phi}$):**
   $$E_0 = \begin{pmatrix} 1 & 0 \\ 0 & \sqrt{1 - \lambda} \end{pmatrix}, \quad E_1 = \begin{pmatrix} 0 & 0 \\ 0 & \sqrt{\lambda} \end{pmatrix}$$

4. **Thermal Relaxation Channel:**
   Parameters: gate duration $\tau$, longitudinal relaxation $T_1$, transverse dephasing $T_2 \le 2T_1$, excited state population $p_1 = 1 / (1 + e^{\hbar\omega / k_B T})$.

5. **Bit-Flip and Phase-Flip Channels:**
   $$E_{\text{BF}} \in \{\sqrt{1-p}I, \sqrt{p}X\}, \quad E_{\text{PF}} \in \{\sqrt{1-p}I, \sqrt{p}Z\}$$

6. **Readout Assignment Matrix:**
   $\mathbf{A} \in \mathbb{R}^{16 \times 16}$ where $A_{ij} = P(\text{measured } i \mid \text{prepared } j)$.

---

## S3. Hardware-Informed Specifications: 5-Qubit Topology vs. Active 4-Qubit Register

*Explicit Disclosure:* No physical dilution refrigerator runs were conducted; executions utilized hardware-informed transmon parameters sampled from Qiskit's `GenericBackendV2(num_qubits=5, seed=42)`. To provide a canonical, reproducible hardware-informed coupling topology, the backend was instantiated with five qubits; however, all reported 4-qubit quantum feature encoding circuits and downstream learning experiments execute strictly on the active $q_0-q_3$ subgraph register (qubit $q_4$ remained idle and did not participate in state encoding, gate execution, or readout).

| Qubit $i$ | Frequency (GHz) | $T_1$ ($\mu$s) | $T_2$ ($\mu$s) | 1Q Error $p_{1Q}$ | Readout $P(0\|1)$ | Readout $P(1\|0)$ |
|---|---|---|---|---|---|---|
| 0 | 5.429 | 177.4 | 143.9 | $9.56 \times 10^{-5}$ | $3.61 \times 10^{-3}$ | $3.61 \times 10^{-3}$ |
| 1 | 5.488 | 169.7 | 109.4 | $9.03 \times 10^{-5}$ | $8.15 \times 10^{-4}$ | $8.15 \times 10^{-4}$ |
| 2 | 5.064 | 176.1 | 178.6 | $9.21 \times 10^{-5}$ | $7.70 \times 10^{-4}$ | $7.70 \times 10^{-4}$ |
| 3 | 5.463 | 145.0 | 137.1 | $9.85 \times 10^{-5}$ | $2.24 \times 10^{-3}$ | $2.24 \times 10^{-3}$ |
| 4 (Idle) | 5.222 | 164.4 | 182.3 | $9.06 \times 10^{-5}$ | $1.51 \times 10^{-3}$ | $1.51 \times 10^{-3}$ |
| **Active Register ($q_0-q_3$ Mean)** | **5.361** | **167.1** | **142.3** | **$9.41 \times 10^{-5}$** | **$1.86 \times 10^{-3}$** | **$1.86 \times 10^{-3}$** |
| **Full Backend ($q_0-q_4$ Mean)** | **5.333** | **166.5** | **150.3** | **$9.35 \times 10^{-5}$** | **$1.79 \times 10^{-3}$** | **$1.79 \times 10^{-3}$** |

- Pulse durations: $\tau_{1Q} = 35\text{ ns}$, $\tau_{2Q} = 280\text{ ns}$ ($8\times$ longer).
- Directed CNOT error rates across active register ($q_0-q_3$, mean $p_{2Q}^{\text{active}} = 2.84 \times 10^{-3}$):
  - $(0,1): 2.78 \times 10^{-3}$; $(1,0): 4.14 \times 10^{-3}$
  - $(1,2): 1.64 \times 10^{-3}$; $(2,1): 2.35 \times 10^{-3}$
  - $(2,3): 4.16 \times 10^{-3}$; $(3,2): 1.94 \times 10^{-3}$
- Peripheral couplings to idle $q_4$: $(3,4): 3.94 \times 10^{-3}$; $(4,3): 3.53 \times 10^{-3}$ (overall 8-pair mean $p_{2Q}^{\text{5Q}} = 2.94 \times 10^{-3}$).

---

## S4. Mathematical Proofs and Analytical Error Derivations

### S4.1 Product-State Fidelity Decay Under Depolarizing Noise
Under independent local single-qubit depolarizing noise:
$$\mathcal{F}_Q \approx 1 - \frac{2n}{3}p$$
For $n=4$ qubits with $p \approx 2.4 \times 10^{-4}$, predicted fidelity is $\mathcal{F}_Q \approx 0.99936$, matching observed $\mathcal{F}_Q = 0.9989 \pm 0.0002$.

### S4.2 Amplitude Damping Asymmetry and Positive Drift
Single-qubit expectation value under damping evolves as:
$$\langle Z \rangle_{\text{damped}} = (1 - \gamma)\cos\theta + \gamma$$
The non-unital offset $+\gamma$ systematically pulls expectation values towards $+1$ (the ground state), introducing a structural positive drift into reconstructed financial indicators.

### S4.3 Purity Contraction Under Entangling CNOT Operations
State purity contracts exponentially with the number of two-qubit entangling gates $G_{2Q}$:
$$\operatorname{Tr}(\rho^2) \le \frac{1}{2^n} + \left(1 - \frac{1}{2^n}\right)(1 - \bar{p}_{2Q})^{2 G_{2Q}}$$
This explains why Uhlmann state fidelity decays from $0.9989$ (AE, $G_{2Q}=0$) down to $0.9609$ (AE+ENT, $G_{2Q}=3$) and $0.9257$ (IQP, $G_{2Q}=6$).

### S4.4 Exact Variance Inflation in Richardson Zero-Noise Extrapolation
For scale factors $\lambda_1 = 1, \lambda_2 = 3$ with Richardson weights $\gamma_1 = 1.5, \gamma_2 = -0.5$:
$$\operatorname{Var}(\langle O \rangle_{\text{Rich}}) = (1.5)^2 \frac{\sigma^2}{N/2} + (-0.5)^2 \frac{\sigma^2}{N/2} = \frac{9\sigma^2}{2N} + \frac{\sigma^2}{2N} = 2.5 \times \frac{\sigma^2}{N} = 2.5 \times \operatorname{Var}(\langle O \rangle_{\text{raw}})$$
Under finite shot budgets ($N = 8,192$), sampling variance expands by $250\%$, overcoming the sub-threshold physical bias ($\sim 10^{-5}$) and degrading observable agreement ($\Delta S_Z = -0.000013$).

---

## S5. Observable-Level Error Mitigation Formalisms

1. **Richardson ZNE:**
   $$\langle O \rangle_{\text{Rich}} = \frac{3\langle O(1) \rangle - \langle O(3) \rangle}{2}$$
2. **Measurement Error Mitigation (MEM):**
   $$\mathbf{p}_{\text{mit}} = \arg\min_{\mathbf{p} \in \Delta} \|\mathbf{A}\mathbf{p} - \mathbf{p}_{\text{raw}}\|_2^2, \quad \Delta = \left\{\mathbf{p} \in \mathbb{R}^{16} : p_i \ge 0, \sum_i p_i = 1\right\}$$

---

## S6. Financial Indicator Formulations and Econometric Stationarity Tests

Augmented Dickey-Fuller tests ($T = 2,013$ sessions):

| Indicator | ADF Statistic | $p$-value | 1% Critical | 5% Critical | 10% Critical | Status |
|---|---|---|---|---|---|---|
| Raw Close Price | -1.241 | 0.658 | -3.433 | -2.863 | -2.568 | Non-Stationary (Excluded) |
| **Normalized Close ($x_0$)** | **-4.110** | **0.0009** | -3.433 | -2.863 | -2.568 | **Stationary ($I(0)$)** |
| Normalized Log Return | -34.218 | < 0.0001 | -3.433 | -2.863 | -2.568 | Stationary ($I(0)$) |
| Historical Volatility | -5.112 | < 0.0001 | -3.433 | -2.863 | -2.568 | Stationary ($I(0)$) |
| **RSI (14) ($x_1$)** | **-9.111** | **< 0.0001** | -3.433 | -2.863 | -2.568 | **Stationary ($I(0)$)** |
| **MACD Signal ($x_2$)** | **-11.871** | **< 0.0001** | -3.433 | -2.863 | -2.568 | **Stationary ($I(0)$)** |
| Momentum (10) | -7.945 | < 0.0001 | -3.433 | -2.863 | -2.568 | Stationary ($I(0)$) |
| MA Ratio (10/50) | -5.632 | < 0.0001 | -3.433 | -2.863 | -2.568 | Stationary ($I(0)$) |
| **Bollinger %B ($x_3$)** | **-11.123** | **< 0.0001** | -3.433 | -2.863 | -2.568 | **Stationary ($I(0)$)** |

---

## S7. Cross-Correlation Analysis of Financial Indicators

Pearson correlation matrix across the 2,013 daily observations ($r \in [0.1362, 0.9033]$):

| Feature | Norm. Close ($x_0$) | RSI (14) ($x_1$) | MACD Signal ($x_2$) | Bollinger %B ($x_3$) |
|---|---|---|---|---|
| Norm. Close ($x_0$) | 1.0000 | 0.6312 | 0.1362 | 0.4811 |
| RSI (14) ($x_1$) | 0.6312 | 1.0000 | 0.5791 | 0.9033 |
| MACD Signal ($x_2$) | 0.1362 | 0.5791 | 1.0000 | 0.7165 |
| Bollinger %B ($x_3$) | 0.4811 | 0.9033 | 0.7165 | 1.0000 |

---

## S8. Extended Downstream Forecasting Performance Metrics

Out-of-sample directional prediction metrics on the extended sensitivity test split ($N_{\text{test}} = 503$, January 2022--December 2023, complementing the primary holdout of $N = 376$ in the main text):

| Model | Accuracy | Balanced Acc | Precision | Recall | F1 | ROC-AUC | DM $p$-value |
|---|---|---|---|---|---|---|---|
| Logistic Regression | 53.68% | 52.84% | 0.5478 | 0.6800 | 0.6068 | 0.5284 | 0.089 |
| SVM (RBF) | 52.88% | 51.86% | 0.5401 | 0.7040 | 0.6111 | 0.5186 | 0.187 |
| Random Forest | 51.89% | 51.08% | 0.5338 | 0.6560 | 0.5889 | 0.5108 | 0.395 |
| QSVM (AE Ideal) | 53.68% | 52.84% | 0.5478 | 0.6800 | 0.6068 | 0.5284 | 0.089 |
| QSVM (AE Noisy) | 53.68% | 52.84% | 0.5478 | 0.6800 | 0.6068 | 0.5284 | 0.089 |
| QSVM (AE ZNE) | 53.68% | 52.84% | 0.5478 | 0.6800 | 0.6068 | 0.5284 | 0.089 |
| QSVM (AE+ENT Ideal) | 50.90% | 50.03% | 0.5262 | 0.6440 | 0.5791 | 0.5003 | 0.683 |
| QSVM (AE+ENT Noisy) | 50.90% | 50.03% | 0.5262 | 0.6440 | 0.5791 | 0.5003 | 0.683 |
| QSVM (IQP Ideal) | 52.49% | 51.73% | 0.5363 | 0.6720 | 0.5968 | 0.5173 | 0.264 |
| QSVM (IQP Noisy) | 52.69% | 51.88% | 0.5385 | 0.6720 | 0.5982 | 0.5188 | 0.228 |

---

## S9. Economic Significance Across Transaction Cost Friction Schedules

Annualized economic performance across transaction friction tiers evaluated on the extended 2022--2023 sensitivity split ($N_{\text{test}} = 503$):

| Model | Ann Ret (0 bps) | Sharpe (0 bps) | Sharpe (5 bps) | Sharpe (10 bps) | Sharpe (20 bps) | Max DD | Turnover |
|---|---|---|---|---|---|---|---|
| Buy & Hold (SPY) | 4.23% | 0.278 | 0.278 | 0.278 | 0.278 | -24.5% | 0.0x |
| Logistic Regression | 23.47% | 1.258 | 1.256 | 1.254 | 1.249 | -13.2% | 0.7x |
| SVM (RBF) | 23.36% | 1.251 | 1.247 | 1.243 | 1.236 | -13.2% | 1.5x |
| Random Forest | 20.35% | 1.074 | 0.988 | 0.902 | 0.729 | -14.8% | 28.8x |
| QSVM (AE Ideal) | 23.47% | 1.258 | 1.256 | 1.254 | 1.249 | -13.2% | 0.7x |
| QSVM (AE Noisy) | 23.47% | 1.258 | 1.256 | 1.254 | 1.249 | -13.2% | 0.7x |
| QSVM (AE ZNE) | 23.47% | 1.258 | 1.256 | 1.254 | 1.249 | -13.2% | 0.7x |
| QSVM (AE+ENT Ideal) | 20.40% | 1.092 | 1.070 | 1.047 | 1.002 | -14.1% | 7.4x |
| QSVM (AE+ENT Noisy) | 20.40% | 1.092 | 1.070 | 1.047 | 1.002 | -14.1% | 7.4x |
| QSVM (IQP Ideal) | 23.95% | 1.282 | 1.179 | 1.077 | 0.871 | -13.8% | 34.2x |
| QSVM (IQP Noisy) | 23.84% | 1.275 | 1.173 | 1.070 | 0.865 | -13.8% | 34.2x |

---

## S10. Walk-Forward Validation Expanding Window Regime Breakdown

Performance trajectory across 5 macroeconomic regimes ($N_{\text{total}} = 1,257$ days):

| Fold | Calendar Window | Raw History | Valid Train ($N_{\text{train}}$) | Test ($N_{\text{test}}$) | LR Acc | QSVM Acc | Market Regime |
|---|---|---|---|---|---|---|---|
| 1 | 2019-01 to 2019-12 | 1,006 | 755 | 252 | 57.94% | 59.52% | Pre-COVID Baseline |
| 2 | 2020-01 to 2020-12 | 1,258 | 1,007 | 253 | 57.31% | 57.31% | COVID-19 Liquidity Shock |
| 3 | 2021-01 to 2021-12 | 1,511 | 1,260 | 252 | 58.33% | 58.33% | QE Stimulus Rally |
| 4 | 2022-01 to 2022-12 | 1,763 | 1,512 | 251 | 43.03% | 43.03% | Fed Rate Tightening |
| 5 | 2023-01 to 2023-12 | 2,014 | 1,763 | 249 | 55.82% | 56.22% | Disinflation / Tech Rebound |
| **Total** | **2019 to 2023** | **2,014** | **1,763** | **1,257** | **54.49%** | **54.89%** | **Weak-Form EMH Consistency** |

---

## S11. Software Dependencies and SHA-256 Cryptographic Verification Hashes

- Python: 3.11.14
- Qiskit: 2.5.2
- Qiskit-Aer: 0.17.2
- NumPy: 1.26.4
- SciPy: 1.13.1
- Pandas: 2.2.2
- Scikit-Learn: 1.4.2

### SHA-256 Checksums

*Note: File paths listed under `tables/` reflect standardized repository artifact identifiers generated during data export and automated pipeline execution, rather than dynamic LaTeX cross-reference numbering in the main manuscript text.*

| File Artifact | SHA-256 Checksum |
|---|---|
| `data/processed/encoding_features.csv` | `04008f68adcaf51cacea5bcdf64a94df8764c8c024bbcc6b72332654bd52cee5` |
| `tables/table1_financial_indicators.csv` | `f692b84adb42e188f7d8dc1d3cf7fe49b7bf5ae9c9e0d0d2d938ecb87247fb74` |
| `tables/table2_circuit_resources.csv` | `14bd16ce6620413f6138b2c9a433a314f9115e5b26c3395d998521dfcc474cd3` |
| `tables/table3_noise_models.csv` | `be923ec6fa664de69fe7670f016670dbf3fc0a31989204b54af7d6929932b37a` |
| `tables/table4_hw_informed.csv` | `a81d72cb1f729343f9ad2b2a3c2c78179cfbed8ab8a20ff9fbb8a692f2ffe95d` |
| `tables/table5_error_mitigation.csv` | `de52434e99d53ae1d7ee6c6dcc3e21127eabc9367fec475d75dbb51d83b3e8b2` |
| `tables/table7_predictive_performance.csv` | `699d6f1770adc1fca8a3bf5f7581a987b4f9345d7c5fd04fdbaa814c92e8acee` |
| `tables/table8_economic_significance.csv` | `8235f619cd75f44b4a16be9f4c243902ce343d293cb2bdbdc902d21f1349cd4c` |
| `tables/table9_walk_forward_validation.csv` | `1c8c534906b76deaf3b8f436e0b837bc83e2d99a79be8a18f47dbf8dbd8a41df` |
| `tables/table10_kernel_target_alignment.csv` | `800151d32f925f4b53b6890fe0cb1bcbf20c30dc6f046ae39944ec0572b45610` |
| `results/master_simulation_bundle.json` | `03a4ee08f72829fdfa8f3e66c3aa59ea46b179fe83d0e09ffdc1ea8d98a92e22` |
| `manuscript/main_quantitative_finance.tex` | `f9e41a9566e6daa1fc431a3ec709a45b9da151df757ebb913ae7853c8ccb4423` |
"""
    with open(MD_PATH, "w", encoding="utf-8") as f:
        f.write(content.strip() + "\n")
    print(f"Wrote Markdown supplementary: {MD_PATH}")

if __name__ == "__main__":
    generate_latex()
    generate_markdown()
    print("Supplementary files generation complete.")
