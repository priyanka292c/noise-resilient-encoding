#!/usr/bin/env python3
"""
19_generate_supplementary_docx.py
==================================
Generates a complete, professionally formatted Microsoft Word document
for the Supplementary Material of the Physical Review Applied paper:
"Noise Resilient Quantum Circuits for Financial Indicator Encoding and
Hardware Aware Benchmarking"

Output:
  supplementary/supplementary.docx
"""

import os
import sys
import csv
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml, OxmlElement
from docx.oxml.ns import nsdecls, qn

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SUPP_DIR = os.path.join(ROOT, "supplementary")
FIGURES_DIR = os.path.join(ROOT, "figures", "png")
os.makedirs(SUPP_DIR, exist_ok=True)


def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = parse_xml(
        f'<w:tcMar {nsdecls("w")}>\n'
        f'  <w:top w:w="{top}" w:type="dxa"/>\n'
        f'  <w:bottom w:w="{bottom}" w:type="dxa"/>\n'
        f'  <w:left w:w="{left}" w:type="dxa"/>\n'
        f'  <w:right w:w="{right}" w:type="dxa"/>\n'
        f'</w:tcMar>'
    )
    tcPr.append(tcMar)


def set_cell_shading(cell, color_hex):
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{color_hex}"/>')
    cell._tc.get_or_add_tcPr().append(shd)


def add_section_h(doc, title):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(16)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(title)
    r.bold = True
    r.font.name = "Arial"
    r.font.size = Pt(13)
    r.font.color.rgb = RGBColor(0x0F, 0x2C, 0x59)
    return p


def add_subsection_h(doc, title):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(11)
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(title)
    r.bold = True
    r.font.name = "Arial"
    r.font.size = Pt(11)
    r.font.color.rgb = RGBColor(0x33, 0x4E, 0x68)
    return p


def add_body_p(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.15
    r = p.add_run(text)
    r.font.name = "Times New Roman"
    r.font.size = Pt(10.5)
    r.font.color.rgb = RGBColor(0x22, 0x22, 0x22)
    return p


def add_code_block(doc, code_str):
    tbl = doc.add_table(rows=1, cols=1)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tbl.autofit = True
    cell = tbl.cell(0, 0)
    set_cell_shading(cell, "F1F5F9")
    set_cell_margins(cell, top=120, bottom=120, left=180, right=180)
    
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.line_spacing = 1.05
    r = p.add_run(code_str.strip())
    r.font.name = "Consolas"
    r.font.size = Pt(8.5)
    r.font.color.rgb = RGBColor(0x0F, 0x17, 0x2A)


def create_styled_table(doc, headers, data_rows, caption_lbl, caption_txt):
    p_cap = doc.add_paragraph()
    p_cap.paragraph_format.space_before = Pt(10)
    p_cap.paragraph_format.space_after = Pt(3)
    p_cap.paragraph_format.keep_with_next = True
    
    r_lbl = p_cap.add_run(caption_lbl + ": ")
    r_lbl.bold = True
    r_lbl.font.name = "Times New Roman"
    r_lbl.font.size = Pt(9.5)
    r_lbl.font.color.rgb = RGBColor(0x0F, 0x2C, 0x59)
    
    r_txt = p_cap.add_run(caption_txt)
    r_txt.font.name = "Times New Roman"
    r_txt.font.size = Pt(9.5)

    num_rows = len(data_rows) + 1
    num_cols = len(headers)
    table = doc.add_table(rows=num_rows, cols=num_cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True

    # Header Row
    for c_idx, h_text in enumerate(headers):
        cell = table.cell(0, c_idx)
        cell.text = h_text
        set_cell_shading(cell, "0F2C59")
        set_cell_margins(cell, top=120, bottom=120, left=140, right=140)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for run in p.runs:
            run.bold = True
            run.font.name = "Times New Roman"
            run.font.size = Pt(9.0)
            run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

    # Data Rows
    for r_idx, row in enumerate(data_rows):
        bg = "F8FAFC" if r_idx % 2 == 1 else "FFFFFF"
        for c_idx, val in enumerate(row):
            cell = table.cell(r_idx + 1, c_idx)
            cell.text = str(val).strip()
            set_cell_shading(cell, bg)
            set_cell_margins(cell, top=80, bottom=80, left=120, right=120)
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if c_idx > 0 else WD_ALIGN_PARAGRAPH.LEFT
            for run in p.runs:
                run.font.name = "Times New Roman"
                run.font.size = Pt(8.5)
                run.font.color.rgb = RGBColor(0x22, 0x22, 0x22)

    doc.add_paragraph().paragraph_format.space_after = Pt(8)


def generate_supplementary_docx():
    print("[INFO] Building Supplementary Material DOCX...")
    doc = docx.Document()

    # Set 1-inch margins
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)

    # Title & Metadata
    p_title = doc.add_paragraph()
    p_title.paragraph_format.space_before = Pt(24)
    p_title.paragraph_format.space_after = Pt(4)
    r_title = p_title.add_run("SUPPLEMENTARY MATERIAL")
    r_title.bold = True
    r_title.font.name = "Arial"
    r_title.font.size = Pt(16)
    r_title.font.color.rgb = RGBColor(0x0F, 0x2C, 0x59)

    p_sub = doc.add_paragraph()
    p_sub.paragraph_format.space_after = Pt(12)
    r_sub = p_sub.add_run(
        "Noise-Resilient Quantum Circuits for Financial Indicator Encoding "
        "Under Realistic Device Noise"
    )
    r_sub.font.name = "Times New Roman"
    r_sub.font.size = Pt(12)
    r_sub.bold = True
    r_sub.font.color.rgb = RGBColor(0x33, 0x4E, 0x68)

    p_auth = doc.add_paragraph()
    p_auth.paragraph_format.space_after = Pt(18)
    r_auth = p_auth.add_run(
        "Shahrukh Saleem,1 Araby Madbouly,2 Uvesh Husain,3 Ram Soorat,4,* Priyanka,5 and Afzalur Rahman6\n"
        "1 VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India\n"
        "2 Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman\n"
        "3 Economics and Business Studies Department, Mazoon College, Muscat, Oman\n"
        "4 School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India\n"
        "5 Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India\n"
        "6 School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India\n"
        "* Corresponding author: ram.soorat@woxsen.edu.in\n"
        "(October 2026)"
    )
    r_auth.font.name = "Times New Roman"
    r_auth.font.size = Pt(10)
    r_auth.font.italic = True
    r_auth.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

    # S0. Graphical Abstract Overview
    add_section_h(doc, "S0. Publication Graphical Abstract")
    add_body_p(doc, "The comprehensive visual overview of the research pipeline, quantum feature encoding architectures, microscopic noise models, and hardware benchmark results is summarized below.")

    ga_path = os.path.join(FIGURES_DIR, "graphical_abstract.png")
    if os.path.exists(ga_path):
        p_img = doc.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_img.paragraph_format.space_before = Pt(6)
        p_img.paragraph_format.space_after = Pt(4)
        run_img = p_img.add_run()
        run_img.add_picture(ga_path, width=Inches(6.2))

        p_cap = doc.add_paragraph()
        p_cap.paragraph_format.space_after = Pt(12)
        r_lbl = p_cap.add_run("FIG. S1: ")
        r_lbl.bold = True
        r_lbl.font.name = "Times New Roman"
        r_lbl.font.size = Pt(9)
        r_txt = p_cap.add_run("Full 4-stage graphical abstract summarizing financial data ingestion, quantum circuit implementations (AE, AEE, IQP), physical device calibration, and quantitative fidelity mitigation on superconducting transmon QPUs.")
        r_txt.font.name = "Times New Roman"
        r_txt.font.size = Pt(9)

    # S1. OpenQASM 3.0 Listings
    add_section_h(doc, "S1. Complete Parameterized OpenQASM 3.0 Circuit Listings")
    add_body_p(doc, "Below are the complete, parameterized OpenQASM 3.0 circuit listings for the three feature encoding circuits accepting formal inputs x = [x0, x1, x2, x3]^T in [0, 1]^4, exactly matching the simulation implementation in python/04_quantum_encoding.py and python/encoding_utils.py.")

    add_subsection_h(doc, "S1.1 Angle Encoding (AE)")
    ae_code = """OPENQASM 3.0;
include "stdgates.inc";

// Classical continuous inputs x in [0, 1]^4
input float[64] x0;
input float[64] x1;
input float[64] x2;
input float[64] x3;

const float[64] pi = 3.14159265358979323846;

qubit[4] q;
bit[4] c;

// Parameterized single-qubit feature rotations: theta_i = pi * x_i
rx(pi * x0) q[0];
rx(pi * x1) q[1];
rx(pi * x2) q[2];
rx(pi * x3) q[3];

c[0] = measure q[0];
c[1] = measure q[1];
c[2] = measure q[2];
c[3] = measure q[3];"""
    add_code_block(doc, ae_code)

    add_subsection_h(doc, "S1.2 Angle Encoding with Entanglement (AEE)")
    aee_code = """OPENQASM 3.0;
include "stdgates.inc";

// Classical continuous inputs x in [0, 1]^4
input float[64] x0;
input float[64] x1;
input float[64] x2;
input float[64] x3;

const float[64] pi = 3.14159265358979323846;

qubit[4] q;
bit[4] c;

// Layer 1: Initial feature rotation
rx(pi * x0) q[0];
rx(pi * x1) q[1];
rx(pi * x2) q[2];
rx(pi * x3) q[3];

// Layer 2: Linear nearest-neighbor entangling CNOT cascade
cx q[0], q[1];
cx q[1], q[2];
cx q[2], q[3];

// Layer 3: Secondary feature rotation
rx(pi * x0) q[0];
rx(pi * x1) q[1];
rx(pi * x2) q[2];
rx(pi * x3) q[3];

c[0] = measure q[0];
c[1] = measure q[1];
c[2] = measure q[2];
c[3] = measure q[3];"""
    add_code_block(doc, aee_code)

    add_subsection_h(doc, "S1.3 Instantaneous Quantum Polynomial (IQP) Feature Map")
    iqp_code = """OPENQASM 3.0;
include "stdgates.inc";

// Classical continuous inputs x in [0, 1]^4
input float[64] x0;
input float[64] x1;
input float[64] x2;
input float[64] x3;

qubit[4] q;
bit[4] c;

// Layer 1: Uniform Hadamard superposition
h q[0];
h q[1];
h q[2];
h q[3];

// Layer 2: Single-qubit phase rotations Rz(2 * x_i)
rz(2.0 * x0) q[0];
rz(2.0 * x1) q[1];
rz(2.0 * x2) q[2];
rz(2.0 * x3) q[3];

// Layer 3: Linear pairwise ZZ interactions via CNOT-Rz-CNOT
// Pair (q[0], q[1]): Rzz(2 * x0 * x1)
cx q[0], q[1];
rz(2.0 * x0 * x1) q[1];
cx q[0], q[1];

// Pair (q[1], q[2]): Rzz(2 * x1 * x2)
cx q[1], q[2];
rz(2.0 * x1 * x2) q[2];
cx q[1], q[2];

// Pair (q[2], q[3]): Rzz(2 * x2 * x3)
cx q[2], q[3];
rz(2.0 * x2 * x3) q[3];
cx q[2], q[3];

// Layer 4: Second Hadamard layer
h q[0];
h q[1];
h q[2];
h q[3];

// Layer 5: Final single-qubit phase rotations Rz(2 * x_i)
rz(2.0 * x0) q[0];
rz(2.0 * x1) q[1];
rz(2.0 * x2) q[2];
rz(2.0 * x3) q[3];

c[0] = measure q[0];
c[1] = measure q[1];
c[2] = measure q[2];
c[3] = measure q[3];"""
    add_code_block(doc, iqp_code)

    # S2. Kraus Operators
    add_section_h(doc, "S2. Explicit Kraus Matrices for Microscopic Noise Channels")
    add_body_p(doc, "Every completely positive trace-preserving (CPTP) quantum map satisfies sum_k E_k^dagger E_k = I.")
    add_body_p(doc, "1. Depolarizing Channel: E0 = sqrt(1 - 3p/4) I,  E1 = sqrt(p/4) X,  E2 = sqrt(p/4) Y,  E3 = sqrt(p/4) Z.")
    add_body_p(doc, "2. Amplitude Damping Channel: E0 = [[1, 0], [0, sqrt(1-gamma)]],  E1 = [[0, sqrt(gamma)], [0, 0]], where gamma = 1 - exp(-tau/T1).")
    add_body_p(doc, "3. Phase Damping Channel: E0 = [[1, 0], [0, sqrt(1-lambda)]],  E1 = [[0, 0], [0, sqrt(lambda)]], where lambda = 1 - exp(-tau/T_phi).")
    add_body_p(doc, "4. Thermal Relaxation Channel: Combines longitudinal T1 relaxation and transverse T2 dephasing subject to the physical constraint T2 <= 2*T1.")

    # S3. Device Calibration Parameters
    add_section_h(doc, "S3. 5-Qubit Hardware-Informed GenericBackendV2 Specifications")
    add_body_p(doc, "The physical parameters instantiated for the 5-qubit hardware-informed superconducting transmon device model (GenericBackendV2, seed=42) are listed below. Parameters are sampled from historical transmon distributions; no physical cryogenic QPU was accessed:")

    headers_calib = ["Qubit i", "Freq (GHz)", "T1 (us)", "T2 (us)", "1Q Error", "Readout Error"]
    rows_calib = [
        ["0", "5.429", "177.4", "143.9", "9.56 x 10^-5", "3.61 x 10^-3"],
        ["1", "5.488", "169.7", "109.4", "9.03 x 10^-5", "8.15 x 10^-4"],
        ["2", "5.064", "176.1", "178.6", "9.21 x 10^-5", "7.70 x 10^-4"],
        ["3", "5.463", "145.0", "137.1", "9.85 x 10^-5", "2.24 x 10^-3"],
        ["4", "5.222", "164.4", "182.3", "9.06 x 10^-5", "1.51 x 10^-3"]
    ]
    create_styled_table(doc, headers_calib, rows_calib, "TABLE S1", "Representative hardware-informed transmon parameters across all five qubits in GenericBackendV2(num_qubits=5, seed=42).")

    # S4. Mathematical Proofs
    add_section_h(doc, "S4. Mathematical Derivations and Error Estimates")
    add_subsection_h(doc, "Analytical Estimate for State Fidelity Under Local Depolarizing Noise")
    add_body_p(doc, "Statement: For a single qubit prepared in pure state |psi_i⟩ = R_x(theta_i)|0⟩ under depolarizing noise with parameter p, the Bloch vector identity <X>^2 + <Y>^2 + <Z>^2 = 1 implies F_1 = (1 - p) + (p/3)(1) = 1 - 2p/3. For an n-qubit product state under n independent channels, F_Q = (1 - 2p/3)^n approx 1 - 2np/3. For n=4 and p = 2.4 x 10^-4, F_Q approx 0.99936, reflecting gate-level depolarizing error.")

    add_subsection_h(doc, "Proposition: Amplitude Damping Asymmetry on Pauli Expectation Values")
    add_body_p(doc, "Statement: Under amplitude damping with parameter gamma = 1 - exp(-tau/T1), the expectation value <Z> of a state prepared at angle theta undergoes non-unital relaxation: <Z>_damped = (1 - gamma)*cos(theta) + gamma. The constant offset +gamma introduces a systematic positive bias toward the ground state |0⟩.")

    add_subsection_h(doc, "Proposition: Purity Contraction Under Entangling Gate Errors")
    add_body_p(doc, "Statement: For parameterized feature maps with two-qubit gate count G_2Q and error rate p_2Q, the purity satisfies Tr(rho^2) <= 1/2^n + (1 - 1/2^n)(1 - p_2Q)^(2*G_2Q). As G_2Q grows from 0 (AE) to 3 (AEE) and 6 (IQP), the state contracts exponentially toward the maximally mixed state.")

    add_subsection_h(doc, "Proposition: Variance Amplification in Richardson Zero-Noise Extrapolation")
    add_body_p(doc, "Statement: Richardson extrapolation with scale factors lambda = {1, 3} and coefficients gamma1 = 3/2, gamma2 = -1/2 amplifies estimator variance by at least 2.5x: Var(<O>_ZNE) = 2.5 * Var(<O>_raw). This necessitates an expanded shot budget (N = 8,192 shots) to suppress sampling variance below physical signal recovery.")

    # S5. Error Mitigation
    add_section_h(doc, "S5. Error Mitigation Formalism")
    add_body_p(doc, "Both ZNE and MEM operate exclusively on observable measurement statistics; they mitigate expectation values (S_Z) rather than preparing purified quantum density matrices.")
    add_body_p(doc, "1. Richardson ZNE: Expectation values are evaluated at lambda1 = 1 and lambda2 = 3 using unitary gate folding (U -> U U^dagger U). The zero-noise estimate is given by <O>_ZNE = (3*<O(1)> - <O(3)>) / 2.")
    add_body_p(doc, "2. Measurement Error Mitigation: Given assignment matrix A in R^(16x16), mitigated probabilities are obtained via regularized simplex inversion: p_mit = argmin_{p in Delta} ||A*p - p_raw||_2^2.")

    # S6. Extended Numerical Results
    add_section_h(doc, "S6. Extended Microscopic Noise Degradation Results")
    headers_noise = ["Channel", "p = 0.001", "p = 0.005", "p = 0.010", "p = 0.050"]
    rows_noise = [
        ["Depolarizing", "0.99998", "0.99989", "0.99978", "0.99891"],
        ["Amplitude Damping", "0.99995", "0.99975", "0.99950", "0.99750"],
        ["Phase Damping", "1.00000", "1.00000", "1.00000", "1.00000"],
        ["Thermal Relaxation", "0.99994", "0.99971", "0.99941", "0.99710"],
        ["Bit Flip", "0.99997", "0.99985", "0.99970", "0.99850"],
        ["Phase Flip", "1.00000", "1.00000", "1.00000", "1.00000"],
        ["Readout Error", "0.99940", "0.99700", "0.99400", "0.97000"]
    ]
    create_styled_table(doc, headers_noise, rows_noise, "TABLE S2", "Mean state fidelity degradation across microscopic noise channels for Angle Encoding.")

    # S7. Financial Feature Correlation
    add_section_h(doc, "S7. Cross-Correlation Analysis of Financial Indicators")
    headers_corr = ["Feature", "Log Return", "RSI (14)", "MACD", "Bollinger %B"]
    rows_corr = [
        ["Log Return", "1.0000", "0.2841", "0.1287", "0.3124"],
        ["RSI (14)", "0.2841", "1.0000", "0.6723", "0.8145"],
        ["MACD", "0.1287", "0.6723", "1.0000", "0.5412"],
        ["Bollinger %B", "0.3124", "0.8145", "0.5412", "1.0000"]
    ]
    create_styled_table(doc, headers_corr, rows_corr, "TABLE S3", "Empirical Pearson correlation matrix across the four assigned financial features.")

    # S8. SHA-256 Hashes
    add_section_h(doc, "S8. Cryptographic SHA-256 Verification Checksums")
    headers_hash = ["Artifact File", "SHA-256 Checksum"]
    rows_hash = [
        ["data/processed/encoding_features.csv", "5e411e8796f7dc535649d24f037cfff3d3c1291ea129d97dfb5c13a5fb68120d"],
        ["results/ideal_simulation_results.csv", "7c1988b59dbd8e6726e7af098409f08526ee94a5068b27654fd493347dbe8d87"],
        ["results/hardware_informed_results.csv", "b9ef63f98e4f24e59804ab14d2e987cf6a01161437d3137e738d2ecfcaf3b91f"],
        ["results/noise_sweep_results.csv", "5eb3e4817fc3c633f75e6c0c67ccd56bb0c130ea44e72370e7158b93e7a10c4a"],
        ["results/mitigation_results.csv", "6563d512bef6d87fb23ca1427598df7dc796d3a910825a1289cfb74ac7b1d494"],
        ["results/comprehensive_metrics_summary.csv", "83ecf9304db30ee31eab212f41df2d87018e5f36db2d2fc20ac3ebaaee931867"],
        ["results/statistical_inference_report.csv", "a1738293dc32562998568b90442cae2159f99f50017f5207b9938e135133a2b7"],
        ["results/master_simulation_bundle.json", "03a4ee08f72829fdfa8f3e66c3aa59ea46b179fe83d0e09ffdc1ea8d98a92e22"]
    ]
    create_styled_table(doc, headers_hash, rows_hash, "TABLE S4", "Cryptographic SHA-256 verification checksums for key project data files and numerical result bundles.")

    out_path = os.path.join(SUPP_DIR, "supplementary.docx")
    doc.save(out_path)
    print(f"[OK] Supplementary DOCX successfully written: {out_path} ({os.path.getsize(out_path):,} bytes)")


if __name__ == "__main__":
    generate_supplementary_docx()
