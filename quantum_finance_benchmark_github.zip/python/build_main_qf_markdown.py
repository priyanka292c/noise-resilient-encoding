"""
build_main_qf_markdown.py
=========================
Generates the comprehensive, submission-ready Markdown manuscript for:
Journal: Quantitative Finance (Taylor & Francis)
Title: Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction: A Hardware-Informed Benchmark
"""

import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MD_PATH = os.path.join(ROOT, "manuscript", "main_quantitative_finance.md")

content = r"""# Noise-Resilient Quantum Feature Encoding for Financial Time-Series Prediction: A Hardware-Informed Benchmark

**Shahrukh Saleem**$^1$, **Araby Madbouly**$^2$, **Uvesh Husain**$^3$, **Ram Soorat**$^{4,*}$, **Priyanka**$^5$, and **Afzalur Rahman**$^6$  
$^1$*VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, Tamil Nadu, India*  
$^2$*Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman*  
$^3$*Economics and Business Studies Department, Mazoon College, Muscat, Oman*  
$^4$*School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India*  
$^5$*Department of Physics and Astrophysics, University of Delhi, New Delhi, Delhi 110007, India*  
$^6$*School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India*  
$^*$*Corresponding Author. Email: ram.soorat@woxsen.edu.in*

**Target Journal:** *Quantitative Finance* (Taylor & Francis)  
**Date:** October 29, 2026

---

### ABSTRACT

Quantum feature maps offer expressive representations for non-linear financial time series, but their practical utility on Noisy Intermediate-Scale Quantum (NISQ) processors is constrained by decoherence and gate infidelities. Using daily S&P 500 ETF (SPY) data from 2015–2023 (2,013 valid trading days), we present a hardware-informed benchmark of four-qubit Angle Encoding (AE), Angle Encoding with Entanglement (AE+ENT), and Instantaneous Quantum Polynomial (IQP) circuits under isolated noise channels and a hardware-informed superconducting-transmon noise model. We find a clear expressivity–robustness trade-off: two-qubit entangling gates reduce Uhlmann state fidelity from 0.9989 for AE to 0.9609 for AE+ENT and 0.9257 for IQP, while marginal $Z$-observable agreement remains above 0.9998. Under finite-shot sampling (8,192 shots), two-point Richardson zero-noise extrapolation amplifies measurement variance by $2.5\times$ and fails to improve observable agreement. In next-day directional forecasting, quantum kernel support vector machines achieve 50.8%–54.0% accuracy, with Diebold–Mariano tests showing no statistically significant outperformance over the linear baseline ($p > 0.07$). Transaction costs substantially reduce the Sharpe ratios of high-turnover quantum strategies. These results show that state preservation is important for quantum financial representations but does not by itself guarantee predictive or economic advantage.

**Keywords:** Quantitative finance; Quantum machine learning; Quantum feature encoding; Financial time-series prediction; NISQ computing; Noise resilience; Error mitigation; Zero-noise extrapolation; Kernel methods.  
**JEL Classifications:** C45, C53, C58, G11, G14.

---

## 1. INTRODUCTION

### 1.1 Financial Time-Series Prediction and Quantitative Modelling
Predicting asset price dynamics, volatility regimes, and market direction remains one of the central challenges in quantitative finance, empirical asset pricing, and systemic risk management (Cont 2001, Gu et al. 2020). Financial time series present unique econometric difficulties: low signal-to-noise ratios, non-stationarity, regime shifts, heavy-tailed return distributions, and complex non-linear interactions among technical, fundamental, and macroeconomic indicators (Fama 1970, Engle 1982). In classical econometrics and financial machine learning, researchers have sought to overcome these challenges by projecting raw price histories and technical indicators into higher-dimensional representations where non-linear patterns may become linearly separable (Hastie et al. 2009, Dixon et al. 2020).

Kernel-based methods, such as Support Vector Machines (SVM) and Kernel Ridge Regression, have long been utilized to capture non-linear market dependencies without explicitly computing high-dimensional coordinates (Schölkopf and Smola 2002, Kim 2003, Huang et al. 2005). However, classical kernels (e.g., Gaussian Radial Basis Functions or polynomial kernels) are constrained by fixed mathematical geometries and can suffer from computational bottlenecks or the curse of dimensionality when scaling to complex multi-factor distributions (Gu et al. 2020, Chen 2026). Consequently, quantitative researchers have increasingly examined non-classical computing paradigms to assess whether quantum mechanical principles can provide more expressive representations of financial data.

### 1.2 Quantum Machine Learning in Finance
Quantum Machine Learning (QML) represents a growing interdisciplinary field at the intersection of computational physics, computer science, and mathematical finance (Biamonte et al. 2017, Orús et al. 2019, Egger et al. 2020). Within quantitative finance, proposed quantum applications span three major domains: combinatorial portfolio optimization via variational quantum algorithms (Brandhofer et al. 2023, Buonaiuto et al. 2023, Carrascal et al. 2024, Olowoyo and Abiona 2026, Wu and Wang 2026), derivative valuation and risk estimation via quantum amplitude estimation (Woerner and Egger 2019, Stamatopoulos et al. 2020, Martin et al. 2021, Li et al. 2026), and non-linear market forecasting via Quantum Neural Networks (QNN) and Quantum Kernel Methods (QKM) (Rebentrost et al. 2018, Herman et al. 2023, Naik et al. 2025, Doosti et al. 2026, Muzzioli et al. 2026).

Central to quantum learning is the *quantum feature map* $\Phi: \mathbf{x} \mapsto |\Phi(\mathbf{x})\rangle\langle\Phi(\mathbf{x})|$, which embeds a classical feature vector $\mathbf{x} \in \mathbb{R}^d$ into the state space of an $n$-qubit quantum system—a complex projective Hilbert space $\mathbb{C}^{2^n}$ of dimension $2^n$ (Havlíček et al. 2019, Schuld and Killoran 2019). By engineering multi-qubit entangling gates, quantum circuits can generate quantum kernels:
$$k(\mathbf{x}, \mathbf{x}') = |\langle\Phi(\mathbf{x})|\Phi(\mathbf{x}')\rangle|^2 = \operatorname{Tr}\left[\rho(\mathbf{x})\rho(\mathbf{x}')\right]$$
which cannot be efficiently estimated on classical computers under plausible computational complexity assumptions (Bremner et al. 2016, Liu et al. 2021).

### 1.3 Hardware Noise in Quantum Financial Modelling
Despite the theoretical appeal of exponentially large Hilbert spaces, practical quantum computing is severely constrained by the physical realities of the Noisy Intermediate-Scale Quantum (NISQ) era (Preskill 2018, Bharti et al. 2022). Near-term quantum processors lack fault-tolerant quantum error correction and are subject to multiple physical noise sources:
1. **Environmental Decoherence:** Longitudinal energy relaxation ($T_1$) and transverse dephasing ($T_2$), which cause quantum superpositions to decay toward thermal equilibrium (Krantz et al. 2019, Devoret and Schoelkopf 2013).
2. **Coherent and Stochastic Gate Infidelities:** Control pulse imperfections and imperfect Hamiltonian dynamics that induce depolarizing transitions and systematic phase errors. Crucially, two-qubit entangling operations (e.g., CNOT gates) typically exhibit error rates 5 to 20 times higher than single-qubit rotations (Blais et al. 2021).
3. **Measurement Readout Errors:** Inefficiencies in quantum state discrimination where measurement apparatuses introduce classical bit-flip confusion during the readout stage (Maciejewski et al. 2020).

When financial data are mapped into a quantum processor, physical noise acts as an irreversible quantum channel $\mathcal{E}$, transforming the intended pure state $\rho(\mathbf{x}) = |\Phi(\mathbf{x})\rangle\langle\Phi(\mathbf{x})|$ into a mixed state $\rho_{\text{noisy}}(\mathbf{x}) = \mathcal{E}(\rho(\mathbf{x}))$. As noise accumulates with increasing circuit depth and entangling gate density, the state distribution contracts toward the maximally mixed state $I/2^n$, diminishing the geometric separability of the feature space and corrupting the encoded financial signals.

### 1.4 Research Gap
Although recent literature has explored quantum computing concepts for financial use cases (Orús et al. 2019, Egger et al. 2020, Herman et al. 2023, Naik et al. 2025), significant gaps remain between theoretical quantum circuit design and empirical financial econometrics:
- **Lack of Hardware-Informed Financial Benchmarking:** The majority of existing quantum finance studies evaluate algorithms under ideal, noiseless conditions or simple toy distributions, providing little empirical evidence regarding how realistic hardware noise channels affect financial representations.
- **Conflation of Marginal Agreement with State Preservation:** Prior benchmarks have frequently relied on single-qubit marginal expectation agreement, which can mask severe multi-qubit entanglement and phase corruption.
- **Unexamined Error Mitigation Under Finite Shots:** Quantum error mitigation techniques—such as Zero-Noise Extrapolation (ZNE)—are often treated as universal solutions without investigating whether higher-order extrapolation amplifies sampling variance under realistic shot budgets.
- **Absence of Downstream Predictive and Economic Evaluation:** Circuit-level fidelity studies rarely connect representation robustness to downstream out-of-sample directional prediction, statistical significance testing, and transaction-cost-adjusted economic performance.

### 1.5 Research Questions
To address these gaps, this study investigates five explicit research questions:
- **RQ1:** How sensitive are different quantum feature encoding architectures (Angle Encoding, Angle Encoding with Entanglement, and Instantaneous Quantum Polynomial maps) to isolated physical noise channels when encoding empirical financial indicators?
- **RQ2:** How do circuit depth and two-qubit entangling gates govern the rate of quantum state degradation under realistic superconducting transmon noise?
- **RQ3:** Can quantum error mitigation methods (Linear ZNE, Richardson ZNE, and MEM) recover uncorrupted expectation values, or does polynomial extrapolation introduce detrimental sampling variance?
- **RQ4:** Does representation-level noise resilience translate into improved downstream financial directional forecasting accuracy when compared to standard classical machine learning baselines?
- **RQ5:** Are observed performance differentials economically meaningful and resilient after accounting for trading friction and transaction costs?

### 1.6 Positioning Statement and Summary of Scientific Contributions
The objective of this investigation is not to claim quantum advantage, but to determine whether currently accessible quantum representations retain sufficient information under realistic hardware-informed noise to justify their application in quantitative financial learning. Grounded entirely in empirical evidence, this paper establishes the following contributions:
1. **Reproducible Financial Time-Series Benchmark:** We construct a clean, leak-free empirical dataset using daily S&P 500 ETF (SPY) data from 2015 to 2023 ($2,013$ valid trading days) with eight financial indicators and strict chronological walk-forward boundaries.
2. **Systematic Encoding Architecture Comparison:** We benchmark three distinct quantum feature maps (AE, AE+ENT, and IQP), demonstrating that non-entangled AE maintains near-perfect fidelity ($\mathcal{F}_Q = 0.9989 \pm 0.0002$), while entangling maps suffer substantial state corruption ($\mathcal{F}_Q = 0.9609$ for AE+ENT and $\mathcal{F}_Q = 0.9257$ for IQP).
3. **Multi-Channel Physical Noise Decomposition:** We isolate the degradation caused by seven physical noise channels alongside a hardware-informed transmon noise model (`GenericBackendV2`), showing that within the tested configurations, two-qubit entangling gates account for the dominant share of observed state infidelity.
4. **Mathematical and Numerical Audit of Error Mitigation:** We provide an analytical and empirical assessment of finite-shot variance amplification in two-point Richardson ZNE, showing that two-point Richardson extrapolation amplifies finite-sample variance by $2.5\times$ under independent equal-variance sampling, degrading observable agreement under realistic shot noise.
5. **Downstream Financial Forecasting and Economic Evaluation:** We benchmark Quantum Kernel SVMs against classical models (Logistic Regression, Support Vector Machines, and Random Forests), evaluating directional accuracy, ROC-AUC with 95% bootstrap confidence intervals, Diebold--Mariano forecast error tests, and transaction-cost-adjusted backtesting across friction tiers ($0, 5, 10, 20\,\text{bps}$).
6. **Characterization of the Expressivity-Robustness Trade-Off:** We find that within the tested configurations, while complex entangling feature maps offer greater theoretical expressivity, their vulnerability to physical noise diminishes representational quality compared to shallow, noise-resilient product-state encodings for near-term quantitative finance applications.

![Figure 1: End-to-End Quantitative Finance Research Framework](../figures/pdf/fig01_workflow.pdf)
*Figure 1: End-to-end quantitative finance research framework and computational workflow. (a) Daily SPDR S&P 500 ETF (SPY) market data ingestion spanning 2015–2023 ($T = 2,013$ valid trading sessions), chronologically partitioned into in-sample calibration (2015–2021) and out-of-sample holdout (2022–2023) periods. (b) Empirical probability densities of the four engineered causal technical indicators ($x_0$: Normalized Close, $x_1$: RSI-14, $x_2$: MACD Signal, $x_3$: Bollinger %B). (c) Four-qubit quantum feature map architectures: separable Angle Encoding (AE, depth $d=1$, 0 CX), Angle Encoding with Linear Entanglement (AE+ENT, depth $d=5$, 3 CX), and Instantaneous Quantum Polynomial (IQP, depth $d=13$, 6 CX). (d) Microscopic hardware-informed transmon noise modeling based on Qiskit's GenericBackendV2 (mean $T_1 = 166.5\,\mu\text{s}$, $T_2 = 150.3\,\mu\text{s}$, $\tau_{1Q} = 35\,\text{ns}$, $\tau_{2Q} = 280\,\text{ns}$). (e) Quantum error mitigation via Linear and two-point Richardson Zero-Noise Extrapolation (ZNE) and Measurement Error Mitigation (MEM). (f) Multi-metric verification exposing the divergence between genuine Uhlmann state fidelity $\mathcal{F}_Q$ and marginal observable agreement $S_Z$, demonstrating that single-qubit marginals mask multi-qubit phase corruption.*

---

## 2. DATA AND METHODOLOGY

### 2.1 Financial Dataset Description and Construction
The empirical analysis uses daily market trading records for the SPDR S&P 500 ETF Trust (Ticker: `SPY`, traded on NYSE Arca), the most liquid equity exchange-traded fund in global financial markets. Historical market data spanning January 1, 2015, through December 31, 2023 ($2,264$ raw trading sessions) were retrieved via the Yahoo Finance API (`yfinance` v1.7.0) on January 15, 2024, calibrated in Eastern Standard/Daylight Time (US/Eastern). To account fully for cash dividend disbursements and historical corporate actions without introducing artificial return jumps, we construct all returns and volatility series from the daily Adjusted Close price $P_t$. Trading dates strictly follow the official NYSE calendar, and missing records are verified to be zero. An initial warm-up window of 252 trading days (one calendar trading year) is allocated to ensure all rolling technical indicators stabilize, yielding an effective sample of $T = 2,013$ valid trading days ($2,012$ forward directional targets $y_{t+1}$).

### 2.2 Data Preprocessing and Leakage Prevention
To guarantee econometric validity and prevent data leakage:
1. All technical indicators at time $t$ are constructed strictly using price information available at or before the market close of day $t$ ($\tau \le t$).
2. Indicator normalization parameters (rolling minimums, maximums, and standard deviations) are computed over trailing historical windows, ensuring no future information enters historical representations.
3. Chronological partitioning is strictly enforced, avoiding random train-test splitting that would introduce look-ahead bias (Gu et al. 2020, Dixon et al. 2020).

### 2.3 Financial Indicator Formulation
To capture multi-scale market dynamics across price trend, momentum, volatility, and mean-reversion, we construct eight standard quantitative indicators:
1. **Normalized Close ($x_{1,t}$):** 252-day rolling min-max scaling of the closing price:
   $$x_{1,t} = \frac{C_t - \min_{\tau \in [t-251, t]} C_\tau}{\max_{\tau \in [t-251, t]} C_\tau - \min_{\tau \in [t-251, t]} C_\tau} \in [0, 1]$$
2. **Normalized Log Return ($x_{2,t}$):** 1-day logarithmic return scaled by 20-day trailing volatility and mapped to $[0, 1]$.
3. **Historical Volatility ($x_{3,t}$):** 20-day annualized sample standard deviation of daily log returns:
   $$\sigma_t^{(20)} = \sqrt{\frac{252}{19} \sum_{k=0}^{19} (r_{t-k} - \bar{r}_t)^2}$$
4. **Relative Strength Index ($x_{4,t}$):** 14-day RSI measuring momentum:
   $$\text{RSI}_t^{(14)} = 100 - \frac{100}{1 + \text{RS}_t}, \quad x_{4,t} = \frac{\text{RSI}_t^{(14)}}{100} \in [0, 1]$$
5. **MACD Signal Difference ($x_{5,t}$):** The difference between the 12-day and 26-day Exponential Moving Averages (EMA) minus the 9-day signal line, normalized via logistic transformation into $[0, 1]$.
6. **Momentum-10 ($x_{6,t}$):** 10-day price ratio $C_t / C_{t-10}$, capturing short-term momentum.
7. **Moving Average Ratio ($x_{7,t}$):** Ratio of the 10-day and 50-day Simple Moving Averages ($\text{SMA}_{10} / \text{SMA}_{50}$).
8. **Bollinger Bands %B ($x_{8,t}$):** Relative position of the close within a 20-day, $2\sigma$ Bollinger Band:
   $$\%B_t = \frac{C_t - (\mu_t - 2\sigma_t)}{4\sigma_t}, \quad x_{8,t} = \operatorname{clip}(\%B_t, 0, 1)$$

**Feature Selection for 4-Qubit Encodings:** We select four complementary indicators spanning distinct market dimensions:
$$\mathbf{x}_t = \left[x_{1,t} \ (\text{Price Level}), \ x_{4,t} \ (\text{Momentum}), \ x_{5,t} \ (\text{Trend}), \ x_{8,t} \ (\text{Volatility-Bound})\right]^\top \in [0, 1]^4$$

| Indicator Symbol | Indicator Name | Market Dimension | Window / Lookback | Feature Inclusion |
| :--- | :--- | :--- | :--- | :--- |
| $x_{1,t}$ | Normalized Close | Intermediate Price Level | 252-day trailing min-max | Primary (Qubit 0) |
| $x_{2,t}$ | Normalized Log Return | Short-Term Return | 1-day / 20-day vol | Secondary Audit |
| $x_{3,t}$ | Historical Volatility | Regime Volatility | 20-day annualized | Secondary Audit |
| $x_{4,t}$ | Relative Strength Index | Momentum | 14-day exponential | Primary (Qubit 1) |
| $x_{5,t}$ | MACD Signal Difference | Trend Crossover | 12/26/9 EMA cascade | Primary (Qubit 2) |
| $x_{6,t}$ | Momentum-10 | Price Ratio | 10-day trailing | Secondary Audit |
| $x_{7,t}$ | Moving Average Ratio | Trend Horizon | 10-day / 50-day SMA | Secondary Audit |
| $x_{8,t}$ | Bollinger Bands %B | Volatility Band Location | 20-day ($2\sigma$ envelope) | Primary (Qubit 3) |

### 2.4 Prediction Target Formulation
The downstream financial learning task is next-day market directional forecasting:
$$y_{t+1} = \begin{cases} 1, & \text{if } r_{t+1} = \ln(C_{t+1}/C_t) > 0 \\ 0, & \text{if } r_{t+1} \le 0 \end{cases}$$
This binary formulation directly governs market-timing decisions: long position ($y_{t+1} = 1$) versus cash or risk-neutral posture ($y_{t+1} = 0$).

### 2.5 Quantum Circuit Architectures and Gate Decomposition
We evaluate three encoding architectures:
1. **Angle Encoding (AE):** Product-state circuit applying single-qubit rotations $R_x(\pi x_{i,t})$ on independent qubits. Depth $d=1$, 4 single-qubit gates, 0 CNOT gates.
2. **Angle Encoding with Linear Entanglement (AE+ENT):** Applies an initial $R_x(\pi x_{i,t})$ layer, a linear cascade of 3 nearest-neighbor CNOT gates ($\text{CX}_{0,1}, \text{CX}_{1,2}, \text{CX}_{2,3}$), and a second $R_x(\pi x_{i,t})$ layer. Depth $d=5$, 8 single-qubit gates, 3 CNOT gates.
3. **IQP Feature Map (IQP):** Prepares uniform superposition via $H^{\otimes 4}$, followed by single-qubit phase rotations $R_z(2 x_{i,t})$ and pairwise diagonal entangling interactions. For hardware resource accounting and physical transpilation, each logical two-qubit interaction $\exp(-i x_j x_k Z_j Z_k)$ is decomposed into a native $\text{CNOT}_{(j,k)} - R_Z(2 x_j x_k) - \text{CNOT}_{(j,k)}$ sequence, accounting for 2 CNOT gates per interacting pair (6 CNOTs for the 3 nearest-neighbor pairs). The circuit concludes with a second Hadamard layer and single-qubit phase shifts. Depth $d=13$, 19 single-qubit gates, 6 CNOT gates.

![Figure 2: Quantum Circuit Architectures](../figures/pdf/fig02_circuit_architectures.pdf)

| Encoding Architecture | Qubits ($n$) | Circuit Depth ($d$) | 1Q Gates | 2Q Gates (CX) | Total Gates | Entangling Topology |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| Angle Encoding (AE) | 4 | 1 | 4 | 0 | 4 | None (Separable) |
| AE + Entanglement (AE+ENT) | 4 | 5 | 8 | 3 | 11 | Linear Nearest-Neighbor |
| IQP Feature Map (IQP) | 4 | 13 | 19 | 6 | 25 | Linear Nearest-Neighbor |

### 2.6 Noise Models and Hardware-Informed Transmon Parameterization
We evaluate noise through two complementary experimental approaches:
1. **Isolated Microscopic Channels:** Parametric sweeps across seven isolated noise mechanisms: single-qubit depolarizing, two-qubit depolarizing, bit-flip ($X$), phase-flip ($Z$), amplitude damping ($T_1$), phase damping ($T_2$), and classical readout assignment errors.
2. **Hardware-Informed Transmon Noise Model:** Open-system simulation using Qiskit's `GenericBackendV2(num_qubits=5, seed=42)` as a reproducible hardware-informed noisy simulator. The backend was instantiated with five qubits to provide a reproducible hardware-informed backend topology; however, all reported quantum experiments used only the active $q_0-q_3$ subgraph. Hardware summary statistics for the active register are: mean $T_1 = 167.1\ \mu\text{s}$, mean $T_2 = 142.3\ \mu\text{s}$ (median $T_1 = 172.9\ \mu\text{s}$, median $T_2 = 140.5\ \mu\text{s}$ across active qubits $q_0-q_3$), single-qubit error $p_{1Q} \approx 9.41 \times 10^{-5}$ ($\tau_{1Q} = 35\ \text{ns}$), directed two-qubit CNOT errors across the 6 active pairs $p_{2Q} \approx 1.64 \times 10^{-3} - 4.16 \times 10^{-3}$ (mean $2.84 \times 10^{-3}$, $\tau_{2Q} = 280\ \text{ns}$), and readout assignment errors $P(0|1), P(1|0) \approx 0.77 \times 10^{-3} - 2.86 \times 10^{-3}$ (mean $1.86 \times 10^{-3}$). For completeness, full 5-qubit topology statistics ($q_0-q_4$) are also recorded: mean $T_1 = 166.5\ \mu\text{s}$, mean $T_2 = 150.3\ \mu\text{s}$, mean $p_{2Q} = 2.94 \times 10^{-3}$. *Explicit Disclosure:* Computations are conducted via density matrix and shot-based simulation on classical hardware; no cryogenic quantum processors were operated.

### 2.7 Error Mitigation Protocol
We audit three established mitigation strategies:
1. **Linear Zero-Noise Extrapolation (Linear ZNE):** Evaluates observables at noise scale factors $\lambda \in \{1, 2\}$ using pulse folding, estimating zero-noise expectation values via $\langle O \rangle_{\text{mit}} = 2\langle O(1) \rangle - \langle O(2) \rangle$.
2. **Richardson Zero-Noise Extrapolation (Richardson ZNE):** Applies two-point polynomial extrapolation across scale factors $\lambda_1 = 1, \lambda_2 = 3$:
   $$\langle O \rangle_{\text{mit}} = \frac{3\langle O(1) \rangle - \langle O(3) \rangle}{2}$$
   Under the stated assumption of independent measurement errors with approximately equal variance at the two noise scales ($\sigma_1^2 \approx \sigma_2^2 = \sigma^2$), the two-point Richardson estimator has $2.5\times$ the variance of an individual unmitigated estimator:
   $$\operatorname{Var}\left(\langle O \rangle_{\text{mit}}\right) = (1.5)^2 \frac{\sigma^2}{N_1} + (-0.5)^2 \frac{\sigma^2}{N_2} = \frac{9\sigma^2}{4(N/2)} + \frac{\sigma^2}{4(N/2)} = 2.5 \frac{\sigma^2}{N}$$
   Under the finite-shot noise regime ($N = 8,192$) examined here, this sampling variance inflation increases statistical dispersion, explaining why Richardson extrapolation does not improve observable agreement relative to unmitigated measurements.
3. **Measurement Error Mitigation (MEM):** Inverts the empirical readout calibration assignment matrix $\mathbf{A} \in \mathbb{R}^{16 \times 16}$ through regularized least-squares optimization over the probability simplex $\Delta_{16}$.

### 2.8 Trading Strategy and Transaction-Cost Model
To evaluate whether statistical directional predictions translate into economic value, we construct a rule-based quantitative trading strategy subject to realistic proportional transaction costs:
1. **Position Formulation:** At the close of trading session $t$, the model generates next-day directional forecast $\hat{y}_{t+1|t} \in \{0, 1\}$. The portfolio enters a binary long-or-cash position $w_t \in \{0, 1\}$:
   $$w_t = \begin{cases} 1, & \text{if } \hat{y}_{t+1|t} = 1 \ (\text{or continuous decision score } f(\mathbf{x}_t) \ge 0) \\ 0, & \text{if } \hat{y}_{t+1|t} = 0 \ (\text{risk-neutral cash posture}) \end{cases}$$
   Short selling is prohibited ($w_t \in \{0, 1\}$), reflecting common institutional constraints for long-only mutual funds and ETF allocations.
2. **Execution Timing:** Position $w_t$ is executed at the closing price of day $t$ (or opening of $t+1$) and held through the close of trading day $t+1$, earning gross return $w_t r_{t+1}$, where $r_{t+1} = (P_{t+1} - P_t)/P_t$.
3. **Transaction Cost Accounting:** Trading friction is modeled through proportional one-way transaction cost $c \in \{0, 5, 10, 20\}\,\text{bps}$ ($c \in \{0, 0.0005, 0.0010, 0.0020\}$), capturing execution commissions, exchange fees, and bid-ask spread crossing. Net daily return is realized as:
   $$r_{t+1}^{\text{net}} = w_t r_{t+1} - c \cdot |w_t - w_{t-1}|.$$
4. **Annualized Turnover:** Annualized one-way portfolio turnover measures the trading frequency across 252 annual sessions:
   $$\text{Turnover} = \frac{252}{T} \sum_{t=1}^T |w_t - w_{t-1}|.$$
5. **Risk-Adjusted Performance:** Annualized return, annualized volatility, and net Sharpe ratio are computed via standard convention:
   $$\bar{r}^{\text{ann}} = (1 + \bar{r}^{\text{net}})^{252} - 1, \quad \sigma^{\text{ann}} = \sigma(r^{\text{net}})\sqrt{252}, \quad \text{SR} = \frac{\bar{r}^{\text{ann}}}{\sigma^{\text{ann}}}$$
   assuming zero risk-free rate for pure strategy excess return. Maximum Drawdown (MDD) is computed from cumulative wealth $W_t = \prod_{s=1}^t (1 + r_s^{\text{net}})$:
   $$\text{MDD} = \max_{t \in [1, T]} \left( \frac{\max_{s \le t} W_s - W_t}{\max_{s \le t} W_s} \right).$$

---

## 3. RESULTS

### 3.1 Descriptive Statistics and Financial Indicator Properties
Daily S&P 500 ETF returns exhibit negative skewness ($-0.54$) and excess kurtosis ($4.82$), consistent with well-established stylized facts of equity index dynamics (Cont 2001). Pairwise correlation analysis reveals heterogeneous dependence across the four selected indicators, with correlations ranging from 0.1362 to 0.9033 (Supplementary Table S3). Normalized Close exhibits modest correlation with MACD ($r = 0.1362$) and moderate correlation with Bollinger %B ($r = 0.4811$) and RSI ($r = 0.6312$), whereas momentum and boundary indicators (RSI and Bollinger %B) exhibit substantial collinearity ($r = 0.9033$). This realistic empirical dependence structure is intentionally retained: rather than enforcing artificial statistical orthogonality via principal component filtering, our benchmark evaluates the robustness of quantum feature maps under the genuine, correlated feature distributions encountered in production quantitative finance.

### 3.2 Ideal Quantum Encoding Performance
Under noise-free statevector simulation, with measurement observables estimated using 8,192 shots, Angle Encoding achieves near-perfect fidelity ($\bar{\mathcal{F}}_Q = 0.99998 \pm 0.00002$) and reconstruction MSE of $(1.16 \pm 0.76) \times 10^{-5}$, with observable agreement $S_Z = 0.999985$. The minor deviation from unity arises solely from finite shot sampling.

### 3.3 Transmon Simulation and Fidelity Degradation

![Figure 3: Isolated Noise Channels](../figures/pdf/fig06_noise_channel_comparison.pdf)

![Figure 4: Hardware-Informed Simulation](../figures/pdf/fig11_hardware_calibrated.pdf)

| Encoding Architecture | State Fidelity $\bar{\mathcal{F}}_Q$ | Observable Agreement $\bar{S}_Z$ | Distortion $\Delta Z$ | Reconstruction MSE $\bar{\varepsilon}_{\text{rec}}$ |
| :--- | :---: | :---: | :---: | :---: |
| **Angle Encoding (AE)** | $\mathbf{0.9989 \pm 0.0002}$ | $\mathbf{0.99998 \pm 0.00002}$ | $\mathbf{0.0069 \pm 0.0028}$ | $\mathbf{(1.52 \pm 1.25)\times 10^{-5}}$ |
| **AE + Entanglement (AE+ENT)** | $0.9609 \pm 0.0014$ | $0.99996 \pm 0.00002$ | $0.0097 \pm 0.0035$ | N/A (non-invertible) |
| **IQP Feature Map (IQP)** | $0.9257 \pm 0.0028$ | $0.99982 \pm 0.00010$ | $0.0195 \pm 0.0053$ | N/A (non-invertible) |

**Decoupling State Fidelity from Marginal Observable Agreement:** While AE+ENT and IQP maintain marginal observable agreement $S_Z \ge 0.9998$, their true state fidelities degrade sharply to $0.9609$ and $0.9257$. Because $S_Z$ projects the 16-dimensional quantum state onto single-qubit Pauli-$Z$ marginals, it is blind to off-diagonal coherence loss and multi-qubit phase corruption. Evaluating quantum feature maps purely through single-qubit expectation values creates a misleading illusion of hardware robustness.

### 3.4 Controlled Depth Ablation
- **Ablation at Depth 5:** Separable depth-5 circuit incurs $1 - \mathcal{F}_Q = 0.408\%$ infidelity; inserting 3 CNOT gates increases infidelity to $4.119\%$ (10.1-fold increase; entangling gates account for $90.1\%$ of additional infidelity).
- **Ablation at Depth 13:** Separable depth-13 circuit incurs $0.996\%$ infidelity; adding 6 CNOT gates increases infidelity to $7.402\%$ (7.4-fold increase; entangling gates account for $86.5\%$ of additional infidelity).

These controlled-depth ablations indicate that two-qubit entangling gates contribute substantially more to state degradation than the additional single-qubit depth in the tested configurations.

### 3.5 When Richardson ZNE Degrades Performance Under Finite-Shot Sampling

![Figure 5: Error Mitigation Benchmark](../figures/pdf/fig09_mitigation_performance.pdf)

| Mitigation Technique | Scale Factors ($\lambda$) | AE ($S_Z$) | AE+ENT ($S_Z$) | IQP ($S_Z$) |
| :--- | :---: | :---: | :---: | :---: |
| Unmitigated (Noisy) | $\lambda = 1$ | 0.999970 | 0.999958 | 0.999824 |
| **Linear ZNE** | $\lambda \in \{1, 2\}$ | $\mathbf{0.999976}$ | $\mathbf{0.999965}$ | $\mathbf{0.999841}$ |
| **Richardson ZNE** | $\lambda \in \{1, 3\}$ | 0.999957 | 0.999942 | 0.999798 |
| **Measurement Error Mitigation (MEM)** | N/A | 0.999972 | 0.999960 | 0.999830 |

Under two-point Richardson extrapolation, the zero-noise estimator has $2.5\times$ the variance of an individual unmitigated estimator. Under the finite-shot noise regime examined here ($N = 8,192$), this sampling variance inflation increases statistical dispersion, explaining why Richardson extrapolation does not improve observable agreement relative to unmitigated measurements.

### 3.6 Kernel Bridge: Frobenius Distortion and Target Alignment

| Encoding Map | State Fidelity $\mathcal{F}_Q$ | Rel. Frobenius Distortion ($\delta_F$) | KTA (Ideal) | KTA (Noisy) |
| :--- | :---: | :---: | :---: | :---: |
| **Angle Encoding (AE)** | 0.9989 | $\mathbf{0.201\%}$ | 0.0133 | 0.0133 |
| **AE + Entanglement (AE+ENT)** | 0.9609 | $7.021\%$ | 0.0145 | 0.0149 |
| **IQP Feature Map** | 0.9257 | $13.030\%$ | 0.0128 | 0.0138 |

Physical state infidelity directly translates into Gram matrix distortion: AE experiences negligible Frobenius distortion ($0.201\%$), whereas IQP exhibits $13.03\%$ distortion. However, Kernel-Target Alignment remains uniformly low across all maps ($\approx 0.013 - 0.015$), indicating that none of the static quantum feature maps achieve strong linear alignment with daily SPY return directions.

### 3.7 Downstream Predictive Performance

![Figure 6: Downstream Predictive Performance & Economic Friction](../figures/pdf/fig06_forecasting_performance.pdf)

Two complementary out-of-sample evaluations are reported: a fixed holdout from July 2022 through December 2023 ($N_{\text{eval}} = 376$), used for the primary benchmark and economic backtest, and an extended chronological 2022–2023 test period ($N = 503$), reported in Supplementary Table S4 as a sensitivity analysis.

| Model Architecture | Encoding / Noise Condition | Accuracy | Balanced Acc | ROC-AUC [95% Bootstrap CI] | F1-Score | DM $p$-val |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: |
| **Logistic Regression** | Classical Features (N/A) | 51.33% | 50.00% | 0.5191 [0.4607, 0.5787] | 0.6784 | Benchmark |
| **SVM (RBF Kernel)** | Classical Features (N/A) | 51.33% | 50.00% | 0.4613 [0.4047, 0.5232] | 0.6784 | 1.0000 |
| **Random Forest** | Classical Features (N/A) | 51.60% | 50.46% | 0.4896 [0.4294, 0.5440] | 0.6642 | 0.8476 |
| **QSVM (AE)** | Ideal Simulation (0 CX) | 51.33% | 50.00% | 0.4669 [0.4106, 0.5293] | 0.6784 | 1.0000 |
| **QSVM (AE)** | Noisy Transmon (0 CX) | 52.13% | 50.81% | 0.4380 [0.3814, 0.4955] | 0.6809 | 0.1792 |
| **QSVM (AE)** | Mitigated ZNE (0 CX) | 52.13% | 50.81% | 0.4371 [0.3806, 0.4941] | 0.6809 | 0.1792 |
| **QSVM (AE+ENT)** | Ideal Simulation (3 CX) | 51.33% | 50.00% | 0.4590 [0.4036, 0.5241] | 0.6784 | 1.0000 |
| **QSVM (AE+ENT)** | Noisy Transmon (3 CX) | 50.80% | 49.73% | 0.4413 [0.3876, 0.4988] | 0.6714 | 0.4144 |
| **QSVM (IQP)** | Ideal Simulation (6 CX) | 51.33% | 50.00% | 0.4926 [0.4360, 0.5532] | 0.6784 | 1.0000 |
| **QSVM (IQP)** | Noisy Transmon (6 CX) | 53.99% | 52.89% | 0.4381 [0.3850, 0.4950] | 0.6778 | 0.0763 |

**Econometric Assessment:**
Directional forecasting accuracy ranges between 50.80% and 53.99%, consistent with weak-form market efficiency for daily liquid equities. The apparent divergence between directional accuracy ($53.99\%$) and ROC-AUC ($0.4381$) for some QSVM specifications reflects the thresholded classification rule and the ranking behavior of the continuous decision scores under prevailing class prevalence ($51.33\%$ positive sessions). Specifically, the decision function intercept shifts toward the dominant class drift, capturing upward direction at the default threshold $f(\mathbf{x}) \ge 0$ (achieving $94.3\%$ sensitivity on positive sessions), whereas the continuous decision margin ranks are perturbed by kernel matrix noise; therefore, accuracy is not interpreted in isolation. Balanced accuracy confirms that when class-prevalence bias is adjusted, the advantage is marginal ($52.89\%$ vs $50.00\%$) and non-significant under the Diebold–Mariano test ($p = 0.0763$). The Diebold–Mariano tests do not reject the null hypothesis of equal predictive accuracy at conventional significance levels ($p > 0.07$ across all specifications), indicating that neither classical non-linear models nor quantum kernel specifications achieve statistically significant predictive outperformance over the linear baseline.

### 3.8 Financial Indicator Dynamics and Walk-Forward Validation

![Figure 7: Financial Case & Distribution Sensitivity](../figures/pdf/fig07_financial_distribution_robustness.pdf)

| Test Year | Market Regime | $N_{\text{test}}$ | LR Acc. | LR AUC | QSVM-AE (Noisy) Acc. | QSVM-AE (Noisy) AUC | SPY Sharpe |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| 2019 | Pre-COVID Expansion | 252 | 57.94% | 0.4556 | 59.52% | 0.5479 | 2.30 |
| 2020 | COVID-19 Shock | 253 | 57.31% | 0.5276 | 57.31% | 0.4575 | 0.60 |
| 2021 | Post-Stimulus Rally | 252 | 58.33% | 0.5164 | 58.33% | 0.5738 | 2.18 |
| 2022 | Rate Tightening Shock | 251 | 43.03% | 0.5249 | 43.03% | 0.5636 | -0.75 |
| 2023 | Disinflation Rebound | 249 | 55.82% | 0.4683 | 56.22% | 0.5182 | 1.90 |

Performance varies markedly across macro environments: all models achieve higher accuracy during sustained bull regimes (2019 and 2021, $\sim 58–59\%$), but drop to $\sim 43\%$ during the 2022 monetary tightening regime. Across all regimes, QSVM and Logistic Regression track each other closely, confirming the absence of structural quantum advantage.

### 3.9 Economic Significance and Transaction Friction Backtest

| Trading Strategy | Ann. Vol | Gross SR (0 bps) | Net SR (5 bps) | Net SR (10 bps) | Net SR (20 bps) | Turnover | Max DD |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Passive Long (SPY)** | 17.14% | 1.04 | 1.04 | 1.04 | 1.04 | $0.0\times$ | 16.68% |
| **Logistic Regression** | 17.14% | 1.04 | 1.04 | 1.04 | 1.03 | $0.7\times$ | 16.68% |
| **SVM (RBF Kernel)** | 17.14% | 1.04 | 1.04 | 1.04 | 1.03 | $0.7\times$ | 16.68% |
| **Random Forest** | 16.97% | 1.07 | 0.98 | 0.90 | 0.73 | $28.8\times$ | 16.68% |
| **QSVM (AE, Ideal)** | 17.14% | 1.04 | 1.04 | 1.04 | 1.03 | $0.7\times$ | 16.68% |
| **QSVM (AE, Noisy)** | 17.01% | 1.17 | 1.15 | 1.13 | 1.09 | $7.4\times$ | 15.39% |
| **QSVM (AE+ENT, Noisy)** | 16.88% | 0.93 | 0.90 | 0.87 | 0.82 | $8.7\times$ | 19.38% |
| **QSVM (IQP, Noisy)** | 16.16% | 1.28 | 1.18 | 1.07 | 0.86 | $34.2\times$ | 19.77% |

**Economic Assessment and Turnover Mechanism:**
Passive Long SPY exhibits $0.0\times$ turnover as a static buy-and-hold benchmark. Classical Logistic Regression, SVM, and ideal QSVM exhibit $0.7\times$ turnover because the models' predicted probabilities remain consistently above the classification threshold across the entire test set ($w_t = 1 \ \forall t$); hence, the strategy executes a single entry trade on day 1 ($1/376 \times 252 = 0.67\times \approx 0.7\times$) and zero subsequent rebalancing trades. In contrast, Random Forest and noisy IQP exhibit active day-to-day position rebalancing, generating $28.8\times$ and $34.2\times$ annualized turnover, respectively. High-turnover strategies suffer severe erosion under realistic friction: Random Forest (turnover $28.8\times$) experiences a Sharpe ratio decay from 1.07 down to 0.73 at 20 bps, while noisy IQP (turnover $34.2\times$) collapses from 1.28 down to 0.86. In contrast, shallow AE maintains modest turnover ($0.7\times$ to $7.4\times$), preserving its net Sharpe ratio above 1.09.

---

## 4. DISCUSSION AND CONCLUSION

### 4.1 Key Findings and Practical Guidance
1. **Separable Encodings Dominate Under NISQ Noise:** Angle Encoding executes via fast single-qubit microwave pulses ($\tau = 35\ \text{ns}$), avoiding high-error two-qubit operations and preserving state fidelity $\mathcal{F}_Q = 0.9989$.
2. **The Entanglement Penalty:** Two-qubit cross-resonance gates ($\tau_{2Q} = 280\ \text{ns}$) drive the dominant share of state corruption (infidelity increases 10.1-fold at depth 5, and 7.4-fold at depth 13).
3. **Richardson ZNE Variance Inflation:** Under finite shot budgets ($N = 8,192$), two-point Richardson ZNE inflates estimator sampling variance by $2.5\times$, degrading observable accuracy when physical bias is small.
4. **Weak-Form EMH Bounds Financial Utility:** Out-of-sample directional accuracy remains bounded between 50.8% and 54.0%, with no statistically significant quantum advantage over linear baselines. High-turnover models incur severe Sharpe ratio decay under transaction costs.
5. **Stability Across Feature Distributions:** Benchmarking across uniform $\mathcal{U}(0, 1)$, standard normal $\mathcal{N}(0, 1)$, and correlated Gaussian distributions reveals that the relative ranking of architectures remains invariant. These results suggest that, for the tested distributions and circuit configurations, hardware-noise vulnerability is driven primarily by circuit topology and physical gate characteristics rather than by the specific statistical properties of the input features.

### 4.2 Limitations
1. **Simulated Hardware Environment:** Computations were performed using Qiskit Aer with hardware-informed transmon noise models derived from `GenericBackendV2` rather than physical dilution refrigerator quantum hardware.
2. **Single-Asset Scope:** The empirical analysis is restricted to daily S&P 500 ETF (SPY) data from 2015 to 2023. Cross-asset generalization to equities, commodities, or fixed income remains an open empirical question.
3. **Qubit Count Constraint:** Circuits were evaluated on 4 qubits, requiring indicator dimensionality reduction.
4. **No Demonstration of Quantum Advantage:** The empirical evidence does not establish quantum supremacy or economic advantage over classical methods.

### 4.3 Conclusion
Within the SPY benchmark and noise models considered here, shallow product-state encodings combined with classical feature engineering provide the most reliable noise-resilient baseline for near-term quantum financial learning.

---

### Funding
The authors received no specific funding for this research.

### Disclosure Statement
The authors report there are no competing financial or non-financial interests to declare.

### Data and Software Availability
Computations were executed in Python 3.11.14 using Qiskit 2.5.2, Qiskit-Aer 0.17.2, NumPy 1.26.4, SciPy 1.13.1, Pandas 2.2.2, Scikit-Learn 1.4.2, Matplotlib 3.8.4, and yfinance 1.7.0. All code, processed dataset pipelines, and figure generation scripts are openly available in the project repository at https://github.com/priyanka292c/noise-resilient-encoding.
"""

with open(MD_PATH, "w", encoding="utf-8") as f:
    f.write(content.strip() + "\n")

print(f"Successfully generated revised Quantitative Finance Markdown manuscript: {MD_PATH}")
