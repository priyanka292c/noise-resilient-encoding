#!/usr/bin/env python3
"""
build_qf_submission_package.py
==============================
Builds the official Taylor & Francis submission bundle for Quantitative Finance:
  - 01_manuscript (PDF, TeX, MD, BibTeX)
  - 02_supplementary (PDF, TeX, MD)
  - 03_cover_letter (PDF, TeX, MD)
  - 04_figures (Vector PDF figures)
  - 05_tables (CSV and MD tables)
  - 06_code_and_reproducibility (Execution scripts, requirements, config)
Creates Quantitative_Finance_Submission_Package.zip with SHA-256 manifest.
"""

import os
import sys
import shutil
import hashlib
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SUBMISSION_DIR = os.path.join(ROOT, "submission_package")
STAGING_DIR = os.path.join(SUBMISSION_DIR, "bundle_quantitative_finance")
ZIP_NAME = "Quantitative_Finance_Submission_Package.zip"
ZIP_PATH_ROOT = os.path.join(ROOT, ZIP_NAME)
ZIP_PATH_SUB = os.path.join(SUBMISSION_DIR, ZIP_NAME)

def compute_sha256(filepath):
    hasher = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while chunk := f.read(65536):
            hasher.update(chunk)
    return hasher.hexdigest()

def copy_file(src, dst):
    if os.path.exists(src):
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
        return True
    return False

def build_package():
    print("=" * 70)
    print("ASSEMBLING QUANTITATIVE FINANCE (TAYLOR & FRANCIS) SUBMISSION PACKAGE")
    print("=" * 70)

    if os.path.exists(STAGING_DIR):
        shutil.rmtree(STAGING_DIR)
    os.makedirs(STAGING_DIR, exist_ok=True)

    folders = {
        "01_manuscript": os.path.join(STAGING_DIR, "01_manuscript"),
        "02_supplementary": os.path.join(STAGING_DIR, "02_supplementary"),
        "03_cover_letter": os.path.join(STAGING_DIR, "03_cover_letter"),
        "04_figures": os.path.join(STAGING_DIR, "04_figures"),
        "05_tables": os.path.join(STAGING_DIR, "05_tables"),
        "06_code_reproducibility": os.path.join(STAGING_DIR, "06_code_reproducibility")
    }

    for f in folders.values():
        os.makedirs(f, exist_ok=True)

    # 1. Manuscript
    print("\n[1/6] Packaging 01_manuscript...")
    copy_file(os.path.join(ROOT, "manuscript", "main_quantitative_finance.pdf"), os.path.join(folders["01_manuscript"], "main_quantitative_finance.pdf"))
    copy_file(os.path.join(ROOT, "manuscript", "main_quantitative_finance.tex"), os.path.join(folders["01_manuscript"], "main_quantitative_finance.tex"))
    copy_file(os.path.join(ROOT, "manuscript", "main_quantitative_finance.md"), os.path.join(folders["01_manuscript"], "main_quantitative_finance.md"))
    copy_file(os.path.join(ROOT, "manuscript", "references.bib"), os.path.join(folders["01_manuscript"], "references.bib"))
    copy_file(os.path.join(ROOT, "manuscript", "authors.yaml"), os.path.join(folders["01_manuscript"], "authors.yaml"))

    # 2. Supplementary
    print("[2/6] Packaging 02_supplementary...")
    copy_file(os.path.join(ROOT, "supplementary", "supplementary_quantitative_finance.pdf"), os.path.join(folders["02_supplementary"], "supplementary_quantitative_finance.pdf"))
    copy_file(os.path.join(ROOT, "supplementary", "supplementary_quantitative_finance.tex"), os.path.join(folders["02_supplementary"], "supplementary_quantitative_finance.tex"))
    copy_file(os.path.join(ROOT, "supplementary", "supplementary_quantitative_finance.md"), os.path.join(folders["02_supplementary"], "supplementary_quantitative_finance.md"))
    copy_file(os.path.join(ROOT, "supplementary", "supplementary.pdf"), os.path.join(folders["02_supplementary"], "supplementary.pdf"))
    copy_file(os.path.join(ROOT, "supplementary", "supplementary.tex"), os.path.join(folders["02_supplementary"], "supplementary.tex"))

    # 3. Cover Letter
    print("[3/6] Packaging 03_cover_letter...")
    copy_file(os.path.join(ROOT, "manuscript", "cover_letter_quantitative_finance.pdf"), os.path.join(folders["03_cover_letter"], "cover_letter_quantitative_finance.pdf"))
    copy_file(os.path.join(ROOT, "manuscript", "cover_letter_quantitative_finance.tex"), os.path.join(folders["03_cover_letter"], "cover_letter_quantitative_finance.tex"))
    copy_file(os.path.join(SUBMISSION_DIR, "COVER_LETTER_QUANTITATIVE_FINANCE.md"), os.path.join(folders["03_cover_letter"], "COVER_LETTER_QUANTITATIVE_FINANCE.md"))

    # 4. Figures
    print("[4/6] Packaging 04_figures...")
    fig_dir = os.path.join(ROOT, "figures", "pdf")
    if os.path.exists(fig_dir):
        for fig_name in os.listdir(fig_dir):
            if fig_name.endswith(".pdf"):
                copy_file(os.path.join(fig_dir, fig_name), os.path.join(folders["04_figures"], fig_name))

    # 5. Tables
    print("[5/6] Packaging 05_tables...")
    tables_dir = os.path.join(ROOT, "tables")
    if os.path.exists(tables_dir):
        for t_name in os.listdir(tables_dir):
            if t_name.endswith(".csv") or t_name.endswith(".md") or t_name.endswith(".tex"):
                copy_file(os.path.join(tables_dir, t_name), os.path.join(folders["05_tables"], t_name))

    # 6. Code & Reproducibility
    print("[6/6] Packaging 06_code_reproducibility...")
    py_dir = os.path.join(ROOT, "python")
    if os.path.exists(py_dir):
        for py_name in os.listdir(py_dir):
            if py_name.endswith(".py"):
                copy_file(os.path.join(py_dir, py_name), os.path.join(folders["06_code_reproducibility"], py_name))
    copy_file(os.path.join(ROOT, "requirements.txt"), os.path.join(folders["06_code_reproducibility"], "requirements.txt"))
    copy_file(os.path.join(ROOT, "config.yaml"), os.path.join(folders["06_code_reproducibility"], "config.yaml"))
    copy_file(os.path.join(ROOT, "run_all.py"), os.path.join(folders["06_code_reproducibility"], "run_all.py"))
    copy_file(os.path.join(ROOT, "reproduce_all.py"), os.path.join(folders["06_code_reproducibility"], "reproduce_all.py"))
    copy_file(os.path.join(ROOT, "README.md"), os.path.join(folders["06_code_reproducibility"], "README.md"))
    copy_file(os.path.join(ROOT, "LICENSE"), os.path.join(folders["06_code_reproducibility"], "LICENSE"))

    # Generate Manifest
    manifest_lines = []
    print("\nComputing SHA-256 manifest across all packaged files...")
    for root_dir, _, files in os.walk(STAGING_DIR):
        for fname in sorted(files):
            fpath = os.path.join(root_dir, fname)
            rel_path = os.path.relpath(fpath, STAGING_DIR)
            sha = compute_sha256(fpath)
            manifest_lines.append(f"{sha}  {rel_path.replace(os.sep, '/')}")

    manifest_content = "\n".join(manifest_lines) + "\n"
    manifest_path = os.path.join(STAGING_DIR, "MANIFEST_SHA256.txt")
    with open(manifest_path, "w", encoding="utf-8") as f:
        f.write(manifest_content)

    # Build ZIP archive
    print(f"\nCompressing into {ZIP_NAME}...")
    with zipfile.ZipFile(ZIP_PATH_ROOT, "w", zipfile.ZIP_DEFLATED) as zf:
        for root_dir, _, files in os.walk(STAGING_DIR):
            for fname in files:
                fpath = os.path.join(root_dir, fname)
                arcname = os.path.relpath(fpath, STAGING_DIR)
                zf.write(fpath, arcname)

    shutil.copy2(ZIP_PATH_ROOT, ZIP_PATH_SUB)
    print(f"Generated root package: {ZIP_PATH_ROOT} ({os.path.getsize(ZIP_PATH_ROOT):,} bytes)")
    print(f"Generated submission copy: {ZIP_PATH_SUB} ({os.path.getsize(ZIP_PATH_SUB):,} bytes)")

    # Synchronize to dedicated Quantitative_Finance folder
    qf_dir = os.path.join(os.path.dirname(os.path.dirname(ROOT)), "Quantitative_Finance")
    if os.path.exists(qf_dir):
        print(f"\nSynchronizing package to dedicated folder: {qf_dir}...")
        for item in os.listdir(STAGING_DIR):
            s_item = os.path.join(STAGING_DIR, item)
            d_item = os.path.join(qf_dir, item)
            if os.path.isdir(s_item):
                if os.path.exists(d_item):
                    shutil.rmtree(d_item)
                shutil.copytree(s_item, d_item)
            else:
                shutil.copy2(s_item, d_item)
        
        # Copy root convenience files
        shutil.copy2(os.path.join(ROOT, "manuscript", "main_quantitative_finance.pdf"), os.path.join(qf_dir, "main_quantitative_finance.pdf"))
        shutil.copy2(os.path.join(ROOT, "supplementary", "supplementary_quantitative_finance.pdf"), os.path.join(qf_dir, "supplementary_quantitative_finance.pdf"))
        shutil.copy2(os.path.join(ROOT, "manuscript", "cover_letter_quantitative_finance.pdf"), os.path.join(qf_dir, "cover_letter_quantitative_finance.pdf"))
        shutil.copy2(manifest_path, os.path.join(qf_dir, "MANIFEST_SHA256.txt"))
        shutil.copy2(ZIP_PATH_ROOT, os.path.join(qf_dir, ZIP_NAME))
        
        # Copy ZIP to grandparent root
        grandparent_zip = os.path.join(os.path.dirname(os.path.dirname(ROOT)), ZIP_NAME)
        shutil.copy2(ZIP_PATH_ROOT, grandparent_zip)
        print(f"Synchronized to: {grandparent_zip}")
        print(f"Synchronized to: {os.path.join(qf_dir, ZIP_NAME)}")

    print(f"Total packaged files: {len(manifest_lines)}")
    print("=" * 70)
    print("QUANTITATIVE FINANCE SUBMISSION PACKAGE READY")
    print("=" * 70)

if __name__ == "__main__":
    build_package()
