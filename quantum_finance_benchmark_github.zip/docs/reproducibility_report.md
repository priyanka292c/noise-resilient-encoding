# Computational Reproducibility and Audit Report

**Manuscript Title:** Noise-Resilient Quantum Circuits for Financial Indicator Encoding Under Realistic Device Noise

**Generated:** 2026-10-04T05:07:44.284192
**Target Journal:** Physical Review Applied (American Physical Society)
**Platform:** Windows-11-10.0.22631-SP0 | Python 3.12.10

## Verified Reproducibility Assertions

- [x] **Global pseudo-random seed is fixed to 42**
- [x] **Zero look-ahead bias in feature engineering**
- [x] **Multi-metric evaluation cleanly separates genuine state fidelity F_Q from marginal Z-agreement S_Z**
- [x] **Classical inversion explicitly restricted to separable product states**
- [x] **GenericBackendV2 explicitly identified as hardware-informed simulation without physical QPU access**
- [x] **Controlled ablations isolate circuit depth from entangling CNOT gate counts**
- [x] **Decoherence phase diagram respects physical constraint T_2 <= 2 T_1**
- [x] **First-order predictive scaling relation validated (R^2 = 0.9866)**
- [x] **All 85 bibliography citations verified via CrossRef REST API**
- [x] **All 16 publication figures generated programmatically from data**
- [x] **All 12 publication tables generated programmatically from data**

## Data & Manuscript File Hashes (SHA-256)

- `raw_dataset`: `a2c15f27e28f700b81d3d52db5ec258a13aae900034bc9bc917d01fc3f77a726`
- `processed_features`: `5e411e8796f7dc535649d24f037cfff3d3c1291ea129d97dfb5c13a5fb68120d`
- `ideal_results`: `7c1988b59dbd8e6726e7af098409f08526ee94a5068b27654fd493347dbe8d87`
- `hw_results`: `b9ef63f98e4f24e59804ab14d2e987cf6a01161437d3137e738d2ecfcaf3b91f`
- `controlled_metrics`: `09afd047c170fd98070ff174ac28bed5d8c1ba96ba77740ef96f79a4a77ff08e`
- `controlled_depth_ablation`: `af247f861d93f0ba6c568598363f03fb4689e20f81f080203147a5d87dc06a57`
- `noise_landscape_2d`: `7ad678c8ae55e1bdf48844ab4a0c2137de4577187e30d2f1919d78584043195d`
- `t1_t2_phase`: `4aee05a9c9ed3e0ead7ad8d6409803f9e63810cfa3e6183bad28df333ff5bdd5`
- `distribution_sensitivity`: `26606c75ad65e8c2a10fbf5bbfabf4dede26a7acb3c36d93520ac271222d76eb`
- `predictive_scaling_model`: `04d2abead5c4dd583f89865da0916d6e44c4b35bf2386e105a12195d1b7673f7`
- `references_bib`: `65527e5995a5f6d9754128ec7df348941aa89f052ade38ddb33e7977ec6225b2`
- `manuscript_tex`: `3ffc3657cfceabfa1bd0c6008a5024a898168cf0a1af935201619eea51fa4b63`
- `manuscript_pdf`: `9198b248074838a7c56b3f53024a373de020a0d348785660dcda9b585f362493`
- `manuscript_docx`: `a4698a27fb08ddf31630c2708f2d11923a68f42527dcfa265011cb87c3cbc6ea`
- `supplementary_pdf`: `90c2823b7bc1d9384781e1f0acd652b795d1db9fd8496cbf0f76816d4eff39bc`
- `supplementary_docx`: `7a8c74970e9189f542de2257886066a054a6e11c002ba0224d1ff924a52a5269`
- `cover_letter_pdf`: `de40e2ec6d88785c53e8d75f72f73a1d121fd3d0e689bd6c500b13525e906656`
