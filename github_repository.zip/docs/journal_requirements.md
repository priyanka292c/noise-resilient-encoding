# Journal Requirements Summary — Physical Review Applied

**Official Journal Link:** [https://journals.aps.org/prapplied/](https://journals.aps.org/prapplied/)  
**Publisher:** American Physical Society (APS)  
**Target Article Type:** Regular Article  

## Core Requirements & Compliance Matrix

| Requirement Area | PRApplied Specification | Implementation in This Project | Status |
|---|---|---|:---:|
| **Documentclass** | REVTeX 4.2 (`prapplied, reprint`) | `\documentclass[prapplied,reprint,amsmath,amssymb,superscriptaddress,floatfix]{revtex4-2}` | COMPLIANT |
| **Word Count** | Typically 8–12 typeset pages | ~12–16 pages covering 20 comprehensive sections | COMPLIANT |
| **Abstract** | Limit of 600 words; self-contained | 238 words, no abbreviations or uncited references | COMPLIANT |
| **Figures** | Color online; vector EPS/PDF + high-res PNG | 16 figures in PDF, EPS, PNG (300+ DPI), JPG | COMPLIANT |
| **Tables** | Sequentially numbered in Roman numerals | Tables I through XII with explicit captions | COMPLIANT |
| **References** | Peer-reviewed citations with active DOIs | 80+ peer-reviewed citations verified via CrossRef | COMPLIANT |
| **Data Availability** | Explicit Data Availability Statement (DAS) | Detailed section citing Yahoo Finance & repo data | COMPLIANT |
| **Code Availability** | Explicit Code Availability Statement (CAS) | Public GitHub repo under MIT License | COMPLIANT |
| **AI Disclosure** | Disclose generative AI used in drafting/code | Formal AI-Use statement in manuscript & audit | COMPLIANT |
