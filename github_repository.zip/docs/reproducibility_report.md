# Computational Reproducibility and Audit Report

**Manuscript Title:** Noise-Resilient Quantum Circuits for Financial Indicator Encoding Under Realistic Device Noise

**Generated:** 2026-10-04T01:42:56.272076
**Target Journal:** Physical Review Applied (American Physical Society)
**Platform:** Windows-10-10.0.26200-SP0 | Python 3.11.16

## Verified Reproducibility Assertions

- [x] **Global pseudo-random seed is fixed to 42**
- [x] **Zero look-ahead bias in feature engineering**
- [x] **Multi-metric evaluation cleanly separates genuine state fidelity F_Q from marginal Z-agreement S_Z**
- [x] **Classical inversion explicitly restricted to separable product states**
- [x] **GenericBackendV2 explicitly identified as hardware-informed simulation without physical QPU access**
- [x] **Controlled ablations isolate circuit depth from entangling CNOT gate counts**
- [x] **Decoherence phase diagram respects physical constraint T_2 <= 2 T_1**
- [x] **First-order predictive scaling relation validated (R^2 = 0.9866)**
- [x] **All 85 bibliography citations verified via CrossRef REST API**
- [x] **All 16 publication figures generated programmatically from data**
- [x] **All 12 publication tables generated programmatically from data**

## Data & Manuscript File Hashes (SHA-256)

- `raw_dataset`: `a2c15f27e28f700b81d3d52db5ec258a13aae900034bc9bc917d01fc3f77a726`
- `processed_features`: `5e411e8796f7dc535649d24f037cfff3d3c1291ea129d97dfb5c13a5fb68120d`
- `ideal_results`: `7c1988b59dbd8e6726e7af098409f08526ee94a5068b27654fd493347dbe8d87`
- `hw_results`: `b9ef63f98e4f24e59804ab14d2e987cf6a01161437d3137e738d2ecfcaf3b91f`
- `controlled_metrics`: `09afd047c170fd98070ff174ac28bed5d8c1ba96ba77740ef96f79a4a77ff08e`
- `controlled_depth_ablation`: `af247f861d93f0ba6c568598363f03fb4689e20f81f080203147a5d87dc06a57`
- `noise_landscape_2d`: `7ad678c8ae55e1bdf48844ab4a0c2137de4577187e30d2f1919d78584043195d`
- `t1_t2_phase`: `4aee05a9c9ed3e0ead7ad8d6409803f9e63810cfa3e6183bad28df333ff5bdd5`
- `distribution_sensitivity`: `26606c75ad65e8c2a10fbf5bbfabf4dede26a7acb3c36d93520ac271222d76eb`
- `predictive_scaling_model`: `04d2abead5c4dd583f89865da0916d6e44c4b35bf2386e105a12195d1b7673f7`
- `references_bib`: `e791db295fe5a7cad101e97ddcb7fc3ca3bc5362feb50de17fb7dc971413430a`
- `manuscript_tex`: `9719b9c47305c36ad332538c8b3fbd038c7e7015ca4e3314851287e4c431e1d5`
- `manuscript_pdf`: `1f83372ee38fd8fecc461480e5f257c0ec57d5d03d00c2fd46c74b87bf5b63fa`
- `manuscript_docx`: `6ea8876aa34c62097e0579b74145193cca9187f0993c0d383d30bfcf8d2fc5da`
- `supplementary_pdf`: `b64e587ff4371b06f66a2aa32aa8ef97575ea9c336a5c9367cc301e06f4acbdc`
- `supplementary_docx`: `7627d3261ec947916d4b69295ae0aaa259824bbc1b5070458a23c3e9060c4a30`
- `cover_letter_pdf`: `94c9b817cc33e6f2bd6ecd5be398a738973ff37211133f2d6d1a596a84c5e9d9`
