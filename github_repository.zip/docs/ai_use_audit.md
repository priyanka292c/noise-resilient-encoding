# AI-Use Audit and Disclosure Report

**Target Journal:** Physical Review Applied (American Physical Society)  
**Policy Compliance:** APS Policy on the Use of AI and Machine-Learning Tools in Manuscripts  
**Audit Date:** October 3, 2026  

## Summary of Substantive AI Use
In accordance with American Physical Society guidelines, the authors disclose that generative AI tooling (Antigravity AI Agent powered by Claude/Gemini) was utilized during the development of this research project for:

1. **Software Pipeline Orchestration:** Generating repetitive script boilerplates across Python and MATLAB for multi-channel noise sweeps and figure exports.
2. **Automated CrossRef Metadata Ingestion:** Formulating HTTP request logic for bulk verification of DOI endpoints.
3. **Typesetting & Formatting:** Assisting with REVTeX 4.2 macro alignment, tabular syntax formatting, and Microsoft Word DOCX styling.

## Independent Verification & Human Authorship
- **Zero Hallucination Guarantee:** No simulation output, numerical metric, hardware backend specification, or bibliography record was hallucinated or fabricated by AI.
- **Scientific Integrity:** All open-quantum-system Lindbladian noise models, circuit depths, empirical SPY feature splits, and statistical tests were verified by the authors.
- **Authorship Attribution:** In compliance with APS guidelines, AI systems are **not** listed as authors or co-authors. The human authors retain complete scientific and ethical responsibility for the entire manuscript.
