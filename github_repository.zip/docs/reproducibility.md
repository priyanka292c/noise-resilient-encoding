# Reproducibility Guide and Protocol

**Manuscript Title:** Noise Resilient Quantum Circuits for Financial Indicator Encoding and Hardware Aware Benchmarking  
**Target Journal:** Physical Review Applied (American Physical Society)  

---

## 1. Principles of Computational Reproducibility
Every simulation, analysis, figure, and table reported in this research paper is strictly reproducible using the automated code base provided.
- **Deterministic Randomness:** All pseudo-random processes (dataset splits, Qiskit Aer shot sampling, noise insertion) utilize explicit seeds configured in `config.yaml`.
- **Zero Look-Ahead Bias:** Financial indicator generation uses rolling and expanding windows strictly bounded by $t \le T_{\text{current}}$.
- **Hardware-Aware Simulation Disclosure:** All simulations modeling quantum hardware are explicitly executed on Qiskit's `GenericBackendV2` (incorporating measured $T_1$, $T_2$, gate durations, and readout errors). No physical hardware execution is fabricated.
- **Automated Master Runner:** The single command `python run_all.py` re-executes all simulations, regenerates all 16 figures, produces 12 tables, verifies reference DOIs, and compiles the manuscript.

---

## 2. Directory Layout & Roles
- `python/`: 15 modular Python scripts executing the scientific workflow.
- `matlab/`: 10 independent MATLAB validation scripts replicating key analysis and figure generation.
- `data/`: Raw and processed empirical S&P 500 ETF data (2,264 trading days).
- `results/`: CSV outputs and JSON provenance logs.
- `tables/`: 12 tables in `.tex`, `.csv`, and `.md`.
- `figures/`: 16 publication figures in PDF, EPS, PNG, and JPG.
- `references/`: Verified bibliography database and DOI resolution audit.
- `manuscript/`: REVTeX 4.2 LaTeX source and Microsoft Word (.docx).
- `supplementary/`: Supplementary information LaTeX and compiled PDF.
