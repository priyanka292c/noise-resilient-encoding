%% 07_generate_figures.m
% =========================================================================
% Phase 9 — Script 07: Independent MATLAB Figure Generation and Multi-Format Export
%
% Exports to:
% - /figures/matlab/png/
% - /figures/matlab/jpeg/
% - /figures/matlab/pdf/
% - /figures/matlab/eps/
%
% Physical Review Applied Manuscript:
% "Noise Resilient Quantum Circuits for Financial Indicator Encoding
%  and Hardware Aware Benchmarking"
% =========================================================================

clear; clc; close all;
fprintf('=================================================================\n');
fprintf('MATLAB VALIDATION PIPELINE — 07: GENERATE FIGURES\n');
fprintf('=================================================================\n');

current_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(current_dir);

% Create export directories
fig_png = fullfile(root_dir, 'figures', 'matlab', 'png');
fig_jpg = fullfile(root_dir, 'figures', 'matlab', 'jpeg');
fig_pdf = fullfile(root_dir, 'figures', 'matlab', 'pdf');
fig_eps = fullfile(root_dir, 'figures', 'matlab', 'eps');

dirs = {fig_png, fig_jpg, fig_pdf, fig_eps};
for d = 1:length(dirs)
    if ~exist(dirs{d}, 'dir'), mkdir(dirs{d}); end
end

% Load simulation data
hw_csv = fullfile(root_dir, 'results', 'hardware_calibrated_results.csv');
if exist(hw_csv, 'file')
    hw_tab = readtable(hw_csv);
    
    % Figure 1: MATLAB Hardware-Calibrated Boxplot
    f1 = figure('Visible', 'off', 'Position', [100, 100, 700, 500]);
    f_ae = hw_tab.fidelity(strcmp(hw_tab.encoding, 'angle_encoding'));
    f_aee = hw_tab.fidelity(strcmp(hw_tab.encoding, 'angle_encoding_entangled'));
    f_iqp = hw_tab.fidelity(strcmp(hw_tab.encoding, 'iqp_feature_map'));
    
    boxplot([f_ae; f_aee; f_iqp], ...
        [repmat({'Angle Encoding'}, length(f_ae), 1); ...
         repmat({'AE + Entanglement'}, length(f_aee), 1); ...
         repmat({'IQP Feature Map'}, length(f_iqp), 1)]);
    ylabel('State Fidelity F', 'FontSize', 12, 'FontName', 'Times New Roman');
    title('FIG. M1. MATLAB Independent Reproduction: Hardware-Calibrated Fidelity', ...
        'FontSize', 12, 'FontWeight', 'bold', 'FontName', 'Times New Roman');
    grid on;
    
    % Export in all 4 formats
    print(f1, fullfile(fig_png, 'matlab_fig01_hw_fidelity.png'), '-dpng', '-r300');
    print(f1, fullfile(fig_jpg, 'matlab_fig01_hw_fidelity.jpg'), '-djpeg', '-r300');
    print(f1, fullfile(fig_pdf, 'matlab_fig01_hw_fidelity.pdf'), '-dpdf');
    print(f1, fullfile(fig_eps, 'matlab_fig01_hw_fidelity.eps'), '-depsc');
    fprintf('  [OK] Exported matlab_fig01_hw_fidelity (PNG/JPEG/PDF/EPS)\n');
    close(f1);
end

% Figure 2: Noise sweep curves
noise_csv = fullfile(root_dir, 'results', 'noise_sweep_results.csv');
if exist(noise_csv, 'file')
    noise_tab = readtable(noise_csv);
    f2 = figure('Visible', 'off', 'Position', [100, 100, 750, 520]);
    channels = unique(noise_tab.noise_channel);
    hold on;
    colors = lines(length(channels));
    for c = 1:length(channels)
        sub = noise_tab(strcmp(noise_tab.noise_channel, channels{c}), :);
        plot(sub.noise_parameter, sub.fidelity, '-o', 'Color', colors(c, :), ...
            'LineWidth', 1.8, 'MarkerSize', 6, 'DisplayName', strrep(channels{c}, '_', ' '));
    end
    xlabel('Noise Parameter', 'FontSize', 11, 'FontName', 'Times New Roman');
    ylabel('Encoding Fidelity F', 'FontSize', 11, 'FontName', 'Times New Roman');
    title('FIG. M2. MATLAB Cross-Validation: Multi-Channel Noise Degradation', ...
        'FontSize', 12, 'FontWeight', 'bold', 'FontName', 'Times New Roman');
    legend('Location', 'southwest', 'FontSize', 9);
    grid on;
    hold off;
    
    print(f2, fullfile(fig_png, 'matlab_fig02_noise_sweep.png'), '-dpng', '-r300');
    print(f2, fullfile(fig_jpg, 'matlab_fig02_noise_sweep.jpg'), '-djpeg', '-r300');
    print(f2, fullfile(fig_pdf, 'matlab_fig02_noise_sweep.pdf'), '-dpdf');
    print(f2, fullfile(fig_eps, 'matlab_fig02_noise_sweep.eps'), '-depsc');
    fprintf('  [OK] Exported matlab_fig02_noise_sweep (PNG/JPEG/PDF/EPS)\n');
    close(f2);
end

fprintf('=================================================================\n');
