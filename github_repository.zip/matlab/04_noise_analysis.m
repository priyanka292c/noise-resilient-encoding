%% 04_noise_analysis.m
% =========================================================================
% Phase 9 — Script 04: Noise Channel Sensitivity and Dynamics Analysis
%
% Physical Review Applied Manuscript:
% "Noise Resilient Quantum Circuits for Financial Indicator Encoding
%  and Hardware Aware Benchmarking"
% =========================================================================

clear; clc;
fprintf('=================================================================\n');
fprintf('MATLAB VALIDATION PIPELINE — 04: NOISE CHANNEL ANALYSIS\n');
fprintf('=================================================================\n');

current_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(current_dir);
noise_csv = fullfile(root_dir, 'results', 'noise_sweep_results.csv');

if exist(noise_csv, 'file')
    noise_tab = readtable(noise_csv);
    channels = unique(noise_tab.noise_channel);
    fprintf('Characterizing %d physical noise channels:\n', length(channels));
    
    for i = 1:length(channels)
        ch_name = channels{i};
        sub = noise_tab(strcmp(noise_tab.noise_channel, ch_name), :);
        f_min = min(sub.fidelity);
        f_max = max(sub.fidelity);
        f_mean = mean(sub.fidelity);
        fprintf('  - %-22s: Min Fidelity=%.4f, Max=%.4f, Mean=%.4f\n', ch_name, f_min, f_max, f_mean);
    end
    
    % Save noise summary table
    writetable(noise_tab, fullfile(current_dir, 'matlab_noise_analysis.csv'));
    fprintf('  [OK] Saved matlab_noise_analysis.csv\n');
else
    error('Noise sweep results not found: %s', noise_csv);
end
fprintf('=================================================================\n');
