%% 05_metric_analysis.m
% =========================================================================
% Phase 9 — Script 05: Quantitative Metric Calculations and Validation
%
% Physical Review Applied Manuscript:
% "Noise Resilient Quantum Circuits for Financial Indicator Encoding
%  and Hardware Aware Benchmarking"
% =========================================================================

clear; clc;
fprintf('=================================================================\n');
fprintf('MATLAB VALIDATION PIPELINE — 05: METRIC ANALYSIS\n');
fprintf('=================================================================\n');

current_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(current_dir);
ideal_csv = fullfile(root_dir, 'results', 'ideal_simulation_results.csv');
hw_csv = fullfile(root_dir, 'results', 'hardware_calibrated_results.csv');

ideal_tab = readtable(ideal_csv);
hw_tab = readtable(hw_csv);

encodings = unique(ideal_tab.encoding);
fprintf('%-25s | %-16s | %-16s\n', 'Encoding Paradigm', 'Ideal Fidelity', 'HW-Calib Fidelity');
fprintf('-----------------------------------------------------------------\n');

for i = 1:length(encodings)
    enc = encodings{i};
    sub_id = ideal_tab(strcmp(ideal_tab.encoding, enc), :);
    sub_hw = hw_tab(strcmp(hw_tab.encoding, enc), :);
    
    m_id = mean(sub_id.fidelity);
    s_id = std(sub_id.fidelity);
    m_hw = mean(sub_hw.fidelity);
    s_hw = std(sub_hw.fidelity);
    
    fprintf('%-25s | %.6f ± %.6f | %.6f ± %.6f\n', enc, m_id, s_id, m_hw, s_hw);
end

fprintf('=================================================================\n');
