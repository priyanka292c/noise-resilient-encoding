%% run_all_matlab.m
% =========================================================================
% Master MATLAB Pipeline Runner
% Physical Review Applied Manuscript:
% "Noise Resilient Quantum Circuits for Financial Indicator Encoding
%  and Hardware Aware Benchmarking"
%
% Runs all 9 MATLAB validation scripts in sequential order.
% =========================================================================

clear; clc; close all;
fprintf('=================================================================\n');
fprintf('QUANTUM FINANCIAL ENCODING — MASTER MATLAB PIPELINE\n');
fprintf('Physical Review Applied — American Physical Society\n');
fprintf('=================================================================\n\n');

scripts = {
    '01_load_data', ...
    '02_preprocess_data', ...
    '03_reference_analysis', ...
    '04_noise_analysis', ...
    '05_metric_analysis', ...
    '06_statistical_analysis', ...
    '07_generate_figures', ...
    '08_generate_tables', ...
    '09_export_results'
};

t_start = tic;

for s = 1:length(scripts)
    script_name = scripts{s};
    fprintf('[RUNNING] %s.m ...\n', script_name);
    try
        run(script_name);
        fprintf('[COMPLETED] %s.m\n\n', script_name);
    catch ME
        fprintf('[ERROR in %s.m]: %s\n', script_name, ME.message);
        rethrow(ME);
    end
end

elapsed = toc(t_start);
fprintf('=================================================================\n');
fprintf('ALL MATLAB PHASES COMPLETED SUCCESSFULLY (Elapsed: %.2f s)\n', elapsed);
fprintf('=================================================================\n');
