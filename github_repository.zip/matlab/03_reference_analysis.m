%% 03_reference_analysis.m
% =========================================================================
% Phase 9 — Script 03: Reference and Bibliography Audit Analysis
%
% Physical Review Applied Manuscript:
% "Noise Resilient Quantum Circuits for Financial Indicator Encoding
%  and Hardware Aware Benchmarking"
% =========================================================================

clear; clc;
fprintf('=================================================================\n');
fprintf('MATLAB VALIDATION PIPELINE — 03: REFERENCE AUDIT ANALYSIS\n');
fprintf('=================================================================\n');

current_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(current_dir);
ref_csv = fullfile(root_dir, 'references', 'references_verified.csv');
audit_csv = fullfile(root_dir, 'references', 'doi_verification_report.csv');

if exist(ref_csv, 'file')
    refs_tab = readtable(ref_csv);
    fprintf('  [OK] Verified references count: %d\n', height(refs_tab));
    
    % Publication year distribution
    years = refs_tab.year;
    fprintf('  - Earliest publication year: %d\n', min(years));
    fprintf('  - Latest publication year:   %d\n', max(years));
    fprintf('  - Median publication year:   %.0f\n', median(years));
    
    % Peer-reviewed venues summary
    unique_journals = unique(refs_tab.journal);
    fprintf('  - Unique publication journals/venues: %d\n', length(unique_journals));
else
    error('Verified references CSV not found: %s', ref_csv);
end

if exist(audit_csv, 'file')
    audit_tab = readtable(audit_csv);
    n_pass = sum(strcmp(audit_tab.status, 'PASS'));
    n_fail = sum(strcmp(audit_tab.status, 'FAIL'));
    fprintf('  - CrossRef DOI Audit: %d Passed, %d Rejected\n', n_pass, n_fail);
    assert(n_pass >= 80, 'Expected at least 80 verified references');
end

fprintf('=================================================================\n');
