%% 01_load_data.m
% =========================================================================
% Phase 9 — Script 01: Load Dataset and Simulation Results
%
% Physical Review Applied Manuscript:
% "Noise Resilient Quantum Circuits for Financial Indicator Encoding
%  and Hardware Aware Benchmarking"
% =========================================================================

clear; clc;
fprintf('=================================================================\n');
fprintf('MATLAB VALIDATION PIPELINE — 01: LOAD DATA\n');
fprintf('=================================================================\n');

% Locate workspace root
current_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(current_dir);

% File paths
features_file = fullfile(root_dir, 'data', 'processed', 'encoding_features.csv');
ideal_file = fullfile(root_dir, 'results', 'ideal_simulation_results.csv');
noise_file = fullfile(root_dir, 'results', 'noise_sweep_results.csv');
hw_file = fullfile(root_dir, 'results', 'hardware_calibrated_results.csv');
mitig_file = fullfile(root_dir, 'results', 'mitigation_results.csv');

% Load processed financial features
if exist(features_file, 'file')
    features_table = readtable(features_file);
    fprintf('  [OK] Loaded financial features: %d rows, %d cols\n', height(features_table), width(features_table));
else
    error('Processed features file not found: %s', features_file);
end

% Load simulation results
if exist(ideal_file, 'file')
    ideal_table = readtable(ideal_file);
    fprintf('  [OK] Loaded ideal simulation results: %d records\n', height(ideal_table));
end

if exist(noise_file, 'file')
    noise_table = readtable(noise_file);
    fprintf('  [OK] Loaded noise sweep results: %d records\n', height(noise_table));
end

if exist(hw_file, 'file')
    hw_table = readtable(hw_file);
    fprintf('  [OK] Loaded hardware-calibrated results: %d records\n', height(hw_table));
end

if exist(mitig_file, 'file')
    mitig_table = readtable(mitig_file);
    fprintf('  [OK] Loaded mitigation results: %d records\n', height(mitig_table));
end

% Save workspace cache for downstream MATLAB scripts
mat_cache = fullfile(current_dir, 'loaded_data.mat');
save(mat_cache, 'features_table', 'ideal_table', 'noise_table', 'hw_table', 'mitig_table');
fprintf('  [OK] Data cached to %s\n', mat_cache);
fprintf('=================================================================\n');
