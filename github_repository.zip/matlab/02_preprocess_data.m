%% 02_preprocess_data.m
% =========================================================================
% Phase 9 — Script 02: Preprocessing and Statistical Diagnostics
%
% Physical Review Applied Manuscript:
% "Noise Resilient Quantum Circuits for Financial Indicator Encoding
%  and Hardware Aware Benchmarking"
% =========================================================================

clear; clc;
fprintf('=================================================================\n');
fprintf('MATLAB VALIDATION PIPELINE — 02: PREPROCESS DATA\n');
fprintf('=================================================================\n');

current_dir = fileparts(mfilename('fullpath'));
load(fullfile(current_dir, 'loaded_data.mat'), 'features_table');

% Extract indicator columns
data_mat = table2array(features_table(:, 2:end));
var_names = features_table.Properties.VariableNames(2:end);

% Verify normalization bounds [0, 1]
min_vals = min(data_mat, [], 1);
max_vals = max(data_mat, [], 1);
mean_vals = mean(data_mat, 1);
std_vals = std(data_mat, 0, 1);

fprintf('Feature Normalization & Stationarity Diagnostics:\n');
for i = 1:length(var_names)
    fprintf('  - %-20s: Min=%.4f, Max=%.4f, Mean=%.4f, Std=%.4f\n', ...
        var_names{i}, min_vals(i), max_vals(i), mean_vals(i), std_vals(i));
    assert(min_vals(i) >= -0.05 && max_vals(i) <= 1.05, ...
        'Feature %s exceeds expected [0, 1] bounds', var_names{i});
end

% Correlation matrix
corr_mat = corrcoef(data_mat);
fprintf('\nCorrelation Matrix computed across %d indicators.\n', length(var_names));

save(fullfile(current_dir, 'preprocessed_data.mat'), 'data_mat', 'var_names', 'corr_mat');
fprintf('  [OK] Saved preprocessed matrices to preprocessed_data.mat\n');
fprintf('=================================================================\n');
