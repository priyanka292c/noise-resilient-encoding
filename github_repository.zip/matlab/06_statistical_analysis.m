%% 06_statistical_analysis.m
% =========================================================================
% Phase 9 — Script 06: Statistical Inference & Bootstrap Resampling
%
% Physical Review Applied Manuscript:
% "Noise Resilient Quantum Circuits for Financial Indicator Encoding
%  and Hardware Aware Benchmarking"
% =========================================================================

clear; clc;
fprintf('=================================================================\n');
fprintf('MATLAB VALIDATION PIPELINE — 06: STATISTICAL ANALYSIS\n');
fprintf('=================================================================\n');

current_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(current_dir);
hw_csv = fullfile(root_dir, 'results', 'hardware_calibrated_results.csv');
hw_tab = readtable(hw_csv);

rng(42); % Fixed random seed for deterministic reproduction

encodings = {'angle_encoding', 'angle_encoding_entangled', 'iqp_feature_map'};
n_boot = 5000;

fprintf('Bootstrap Resampling (95%% CI, %d resamples):\n', n_boot);
for i = 1:length(encodings)
    enc = encodings{i};
    data = hw_tab.fidelity(strcmp(hw_tab.encoding, enc));
    n = length(data);
    boot_means = zeros(n_boot, 1);
    for b = 1:n_boot
        boot_idx = randi(n, n, 1);
        boot_means(b) = mean(data(boot_idx));
    end
    ci_low = prctile(boot_means, 2.5);
    ci_high = prctile(boot_means, 97.5);
    fprintf('  - %-25s: Mean=%.6f, 95%% CI=[%.6f, %.6f]\n', enc, mean(data), ci_low, ci_high);
end

fprintf('=================================================================\n');
