%% 08_generate_tables.m
% =========================================================================
% Phase 9 — Script 08: Independent Table Generation and Formatting
%
% Physical Review Applied Manuscript:
% "Noise Resilient Quantum Circuits for Financial Indicator Encoding
%  and Hardware Aware Benchmarking"
% =========================================================================

clear; clc;
fprintf('=================================================================\n');
fprintf('MATLAB VALIDATION PIPELINE — 08: GENERATE TABLES\n');
fprintf('=================================================================\n');

current_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(current_dir);
hw_csv = fullfile(root_dir, 'results', 'hardware_calibrated_results.csv');
hw_tab = readtable(hw_csv);

encs = {'angle_encoding', 'angle_encoding_entangled', 'iqp_feature_map'};
methods = {'Angle Encoding (AE)', 'AE + Entanglement (AEE)', 'IQP Feature Map'};

mean_fid = zeros(3, 1);
std_fid = zeros(3, 1);
mean_mse = zeros(3, 1);
std_mse = zeros(3, 1);

for i = 1:3
    sub = hw_tab(strcmp(hw_tab.encoding, encs{i}), :);
    mean_fid(i) = mean(sub.fidelity);
    std_fid(i) = std(sub.fidelity);
    mean_mse(i) = mean(sub.reconstruction_error);
    std_mse(i) = std(sub.reconstruction_error);
end

T_matlab = table(methods', mean_fid, std_fid, mean_mse, std_mse, ...
    'VariableNames', {'Method', 'Mean_Fidelity', 'Std_Fidelity', 'Mean_ReconMSE', 'Std_ReconMSE'});

out_csv = fullfile(current_dir, 'matlab_table_results.csv');
writetable(T_matlab, out_csv);
fprintf('  [OK] Saved MATLAB summary table to: %s\n', out_csv);
disp(T_matlab);
fprintf('=================================================================\n');
