# Security Policy

## Supported Versions

This repository contains reproducible research code and artifacts for the Physical Review Applied publication:
*"Noise-Resilient Quantum Circuits for Financial Indicator Encoding Under Realistic Device Noise"*.

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |

## Reporting a Vulnerability

If you discover a security vulnerability or security-related issue in this codebase, please report it privately by contacting the corresponding author via email:

- **Email:** `saptarshi.banerjee@techuniv.ac.in`

Please do not open a public issue on GitHub for undisclosed security vulnerabilities. We will review and respond to reports within 48 hours.
