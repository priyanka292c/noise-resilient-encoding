# Physical Review Applied — Article Types

**Source:** https://journals.aps.org/prapplied/authors#article-types-and-length-limits  
**Accessed:** 2026-10-03  
**Status:** VERIFIED from official APS author instructions

---

## Article Types Available in PRApplied

### Regular Articles (NO length limit)
- Original research articles meeting editorial criteria and scope
- Appropriate length depends on information contained
- **SELECTED for this manuscript**

### Letters (length limit: 4500 words)
- Brief accounts of highly important original research
- Complete and accessible for general reader
- Priority editorial processing

### Review Articles (length limit: 30,000 words)
- Research of topical interest
- In-depth treatment, survey of recent work
- Introduction accessible to non-specialists
- Must include significant outlook section

### Perspectives (no length limit, INVITED)
- Forward-looking papers
- Overview of state of the art + future directions
- Authors may send 1-page proposals to prapplied@aps.org

### Comments and Replies (length limit: 3500 words)
- Critique or correction of previously published papers

### Erratum
- Notifies readers of errors in published papers

---

## Length Guide Reference

Full length guide: https://journals.aps.org/authors/length-guide

---

## Additional Materials Required for Regular Articles

**A 100-word compelling justification** for why the paper is suitable for
Physical Review Applied is required.

Source: https://journals.aps.org/prapplied/authors#additional-materials

---

## Cover Letter Requirements

Must include:
- Context of the results
- Summary of key findings
- Relevant submission history at Physical Review (if any)
- Any recommended or excluded referees

---

## Source URLs

- Article types: https://journals.aps.org/prapplied/authors#article-types-and-length-limits
- Length guide: https://journals.aps.org/authors/length-guide
