# Physical Review Applied — AI Use Policy

**Source:** https://journals.aps.org/authors/appropriate-use-ai-tools  
**Accessed:** 2026-10-03  
**Status:** VERIFIED from official APS website

---

## Official APS Policy Summary

AI tools may be used to assist with aspects of research and manuscript preparation, **but**:
- AI tools **cannot replace** authors' expertise, judgment, or accountability
- **An AI program cannot be held accountable and cannot be listed as an author**
- Authors are **fully responsible** for accuracy and must review and refine all AI-generated content

---

## What Requires Disclosure

Substantive AI use includes, but is not limited to:
- Scientific reasoning or interpretation
- Drafting or revising scientific claims, conclusions, or explanations
- Literature synthesis beyond routine organization
- **Figure generation or image analysis**
- Derivations or calculations
- **Code generation or debugging that materially affects results**
- **Simulations or numerical analysis**
- **Data analysis or statistical analysis**

**Any substantive use must be disclosed in the paper itself.**

---

## Where to Disclose (Official Guidance)

- AI use for **figure generation** → mention in figure caption
- AI use in **conducting research** → describe in methods section
- **All other substantive uses** → in the Acknowledgment statement

---

## Light Editing Exception

Authors are NOT required to disclose AI used to:
- Polish, condense, or otherwise lightly edit the text

---

## Disclosure Statement Required Elements

Authors must state:
1. AI tool name and version
2. How the AI assisted
3. How the authors directed and verified the AI output

---

## Applicable Disclosure for This Project

Because AI tools (Antigravity/Claude) were used for:
- Code generation (Python/Qiskit simulation pipeline)
- Code generation (MATLAB analysis pipeline)
- Literature organization and research gap analysis
- Manuscript language drafting and editing
- Figure generation assistance

**A substantive AI disclosure is REQUIRED and has been prepared in:**
`manuscript/ai_use_statement.tex`

The disclosure must clearly state that:
- The authors independently verified all scientific content
- All computational results were validated
- All references were independently verified
- Authors remain fully responsible for accuracy, integrity, and interpretation

---

## Source URLs

- Official policy: https://journals.aps.org/authors/appropriate-use-ai-tools
- Editorial policies (authorship): https://journals.aps.org/authors/editorial-policies-authorship
