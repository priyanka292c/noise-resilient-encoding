# Physical Review Applied — Formatting Requirements

**Source:** https://journals.aps.org/prapplied/authors  
**Accessed:** 2026-10-03  
**Status:** VERIFIED from official APS author instructions page

---

## Preferred Submission Format

- **LaTeX (preferred):** Use REVTeX 4.2 with `\documentclass[prapplied]{revtex4-2}` option
- **Microsoft Word:** Official template available at:
  https://res.cloudinary.com/apsphysics/raw/upload/v1722521536/PhysRev-template_zysvy0.docx
- PDF is sufficient for peer review; source files needed for acceptance

---

## REVTeX Version

- **Current version:** REVTeX 4.2f (released May 30, 2023)
- **Source:** https://journals.aps.org/revtex
- Download: https://cdn.journals.aps.org/test/345f0cd4-cab7-4271-9a46-7331fb57618a/revtex-tds-2023-05-30.zip
- Also available on CTAN: http://www.ctan.org/tex-archive/macros/latex/contrib/revtex

### PRApplied-specific LaTeX option:
```latex
\documentclass[prapplied,reprint,amsmath,amssymb]{revtex4-2}
```

### Required Packages:
- natbib ≥ 8.31a
- url.sty
- textcase.sty
- bm.sty
- AMS-LaTeX ≥ 2.0

---

## Style Guide

- **Full guide:** APS Journals Style Guide (PDF)
  https://res.cloudinary.com/apsphysics/image/upload/APS_Journals_Style_Guide_Authors022326_guzwhx.pdf
- Style basics: https://journals.aps.org/authors/style-basics

---

## Language

- All articles published in **American English**
- Language editing services available via Editage: https://authorservices.aps.org/

---

## Titles in References (PRApplied Specific)

- **PRApplied REQUIRES titles in all references** — this is a journal-specific requirement
- Source: https://journals.aps.org/prapplied/authors#style-and-formatting

---

## Overstated Claims Policy

Manuscripts must NOT include:
- Dramatic language
- Overstated claims of novelty or priority
- Phrases such as "new", "novel", "the first"
- Formal style is required

---

## Accessibility Requirements

- Clear and easy-to-read figures in accessible color palettes
- Use of words or symbols (instead of color alone) to provide meaning
- Descriptive links

---

## Supplemental Material Policy

- At PRApplied, **Appendices in the main manuscript are PREFERRED** over standalone Supplemental Material
- SM is for information not essential to understanding main results
- All SM references must appear in the main bibliography

---

## Source URLs

- Author instructions: https://journals.aps.org/prapplied/authors
- REVTeX home: https://journals.aps.org/revtex
- APS Style Guide: https://res.cloudinary.com/apsphysics/image/upload/APS_Journals_Style_Guide_Authors022326_guzwhx.pdf
- Style basics: https://journals.aps.org/authors/style-basics
- Word template: https://res.cloudinary.com/apsphysics/raw/upload/v1722521536/PhysRev-template_zysvy0.docx
