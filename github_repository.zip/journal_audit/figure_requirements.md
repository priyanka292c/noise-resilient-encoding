# Physical Review Applied — Figure Requirements

**Source:** https://journals.aps.org/authors/style-basics#tables  
**Source:** https://journals.aps.org/prapplied/authors  
**Accessed:** 2026-10-03  
**Status:** VERIFIED from official APS author instructions

---

## Figure Requirements (Official APS)

### Accessibility (Required)
- Clear and easy-to-read figures in **accessible color palettes**
- Use of words or symbols (instead of color alone) to provide meaning
- Must meet WCAG 2.2 guidelines

### Formats Accepted
- EPS (vector, preferred for line art)
- PDF (vector)
- PNG (raster, 300+ dpi recommended)
- JPEG (raster, acceptable for photographs)
- TIFF

### Resolution Guidance (from APS Style Guide)
- Raster images for publication: minimum 300 dpi at publication size
- Line art: 600 dpi preferred
- Color images: 300 dpi minimum

### Numbering
- Figures numbered sequentially: FIG. 1, FIG. 2, ...
- In-text citation: "Fig. 1" (abbreviated) or "Figure 1" at start of sentence

### Captions
- Each figure must have a numbered caption
- Captions should be self-contained
- Define all symbols and abbreviations in caption
- State units

### Video
- PRApplied supports inclusion of videos in the manuscript
- Video linked from static figure with snapshot frames

---

## Figure Requirements for This Project

Each generated figure must include:
- [ ] Sequential figure number
- [ ] Descriptive caption
- [ ] Panel labels (a), (b), ... where applicable
- [ ] Axis labels with units
- [ ] Legend
- [ ] Error bars or uncertainty indicators where applicable
- [ ] Accessible color palette (colorblind-safe recommended)
- [ ] Grayscale distinguishability

Exported formats per figure:
- PNG (300 dpi minimum)
- JPEG (300 dpi minimum)
- PDF (vector where possible)
- EPS (vector where possible)

---

## Source URLs

- Style basics (tables/figures): https://journals.aps.org/authors/style-basics#tables
- Accessibility: https://journals.aps.org/prapplied/authors#accessibility
- APS Style Guide: https://res.cloudinary.com/apsphysics/image/upload/APS_Journals_Style_Guide_Authors022326_guzwhx.pdf
