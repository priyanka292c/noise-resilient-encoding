# Physical Review Applied — Table Requirements

**Source:** https://journals.aps.org/authors/style-basics#tables  
**Accessed:** 2026-10-03  
**Status:** VERIFIED from official APS style basics

---

## Table Requirements (APS Standard)

### Numbering
- Tables numbered with Roman numerals: TABLE I, TABLE II, TABLE III, ...
- In-text: "Table I", "Table II", etc.
- Sequential order of first citation in text

### Structure
- Each table must have a caption (table title/description)
- Column headers must be clear
- Units must be specified for all numerical columns
- Footnotes permitted below table body

### Citation in Text
- Every table must be cited in the text
- Every table must be discussed in the text
- Do not insert a table without explaining its content

### LaTeX (REVTeX)
- Use `table` environment for single-column tables
- Use `table*` environment for double-column (full-width) tables
- Use `\begin{ruledtabular} ... \end{ruledtabular}` for APS-style ruled tables

---

## Tables Required for This Project

| Table | Content | Status |
|-------|---------|--------|
| TABLE I | Dataset and financial indicators | Planned |
| TABLE II | Quantum encoding methods | Planned |
| TABLE III | Circuit architectures | Planned |
| TABLE IV | Noise models and parameters | Planned |
| TABLE V | Hardware/calibration parameters | Planned |
| TABLE VI | Noise-mitigation methods | Planned |
| TABLE VII | Benchmark metrics | Planned |
| TABLE VIII | Main numerical results | Pending simulation |
| TABLE IX | Computational overhead | Pending simulation |
| TABLE X | Reproducibility/configuration summary | Planned |
| TABLE XI | Comparison with prior literature | Pending reference audit |
| TABLE XII | Verified reference audit summary | Pending reference audit |

---

## Source URLs

- Table style basics: https://journals.aps.org/authors/style-basics#tables
- APS Style Guide: https://res.cloudinary.com/apsphysics/image/upload/APS_Journals_Style_Guide_Authors022326_guzwhx.pdf
