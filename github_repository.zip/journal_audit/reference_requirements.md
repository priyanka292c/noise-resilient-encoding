# Physical Review Applied — Reference Requirements

**Source:** https://journals.aps.org/prapplied/authors (Style and Formatting section)  
**Source:** https://journals.aps.org/authors/editorial-policies#references  
**Accessed:** 2026-10-03  
**Status:** VERIFIED from official APS sources

---

## PRApplied-Specific Reference Requirements

### Titles REQUIRED in References

Physical Review Applied **requires authors to include titles in ALL references**
of the published paper. This is a journal-specific requirement to aid readers
and improve accuracy of online searches.

Source: https://journals.aps.org/prapplied/authors#style-and-formatting

---

## General APS Reference Guidelines

From editorial policies:
- Include proper references to pertinent earlier work
- Credit significant contributions by other researchers
- Ensure references are comprehensive and up to date at submission
- Add new references to relevant work published during review
- May cite: e-print archives, books, published conference proceedings,
  internal reports, oral reports at meetings
- Reference list must represent the field — avoid favoring specific groups,
  regions, or institutions
- Avoid excessive self-referencing
- Avoid excessive references to the journal reviewing the paper

---

## Citation Format

APS uses **numbered sequential citations** in order of first appearance:
- [1], [2], [3], ...
- First citation in text = [1]
- BibTeX with REVTeX generates proper formatting automatically

---

## BibTeX for PRApplied

REVTeX 4.2 Physical Review BibTeX style:
- Article titles shown in bibliography (default for all APS journals in REVTeX 4.2)
- Article titles in roman font
- DOI URLs use `https://doi.org/` as base
- arXiv URLs use `https://arxiv.org/abs/` as base

---

## Verification Requirements for This Project

Every reference must pass:
1. DOI resolves (HTTP 200 from doi.org)
2. Title matches verified source
3. Authors match verified source
4. Journal name matches verified source
5. Year is consistent
6. Not arXiv-only (must have publisher record)
7. Not a duplicate

---

## Source URLs

- Reference policy: https://journals.aps.org/authors/editorial-policies#references
- PRApplied style: https://journals.aps.org/prapplied/authors#style-and-formatting
- REVTeX home: https://journals.aps.org/revtex
