# Physical Review Applied — Submission Checklist

**Source:** Official APS sources (see individual audit files for URLs)  
**Assembled:** 2026-10-03

---

## Pre-Submission Checklist

### Scientific Content
- [ ] Manuscript presents fresh insight into applications-based physical phenomena
- [ ] High-quality, significant contribution to a specific research area
- [ ] Authoritative and substantive addition to the literature
- [ ] No overstated claims of novelty ("new", "novel", "the first")
- [ ] No unsupported quantum-advantage claims
- [ ] No fabricated references, data, or results

### Formatting
- [ ] LaTeX source uses REVTeX 4.2 with `prapplied` option
- [ ] Language is American English
- [ ] Titles included in ALL references (PRApplied requirement)
- [ ] References numbered sequentially in order of first citation
- [ ] Equations properly labeled and defined
- [ ] Figures numbered sequentially (FIG. 1, FIG. 2, ...)
- [ ] Tables numbered sequentially in Roman numerals (TABLE I, TABLE II, ...)

### Figures
- [ ] All figures cited in text
- [ ] All figures have descriptive captions
- [ ] All figures have axis labels with units
- [ ] All figures use accessible color palettes
- [ ] Figure files at 300+ dpi

### References
- [ ] Every reference has been DOI-verified
- [ ] No arXiv-only references
- [ ] No fabricated DOIs
- [ ] No duplicate references
- [ ] No retracted papers (unless relevant)
- [ ] Every bibliography entry is cited in text
- [ ] Every citation has a bibliography entry

### Required Sections
- [ ] Title
- [ ] Author list (with affiliations, emails, ORCID if available)
- [ ] Abstract
- [ ] Keywords
- [ ] Main text sections
- [ ] Acknowledgments
- [ ] Data Availability Statement (DAS) — MANDATORY
- [ ] AI Use Disclosure (if substantive AI use occurred)
- [ ] References

### Additional Materials Required
- [ ] 100-word justification for Physical Review Applied suitability
- [ ] Cover letter (with context, key findings, submission history)

### Files Required
- [ ] main.tex (LaTeX source)
- [ ] references.bib (BibTeX file)
- [ ] All figure files (EPS/PDF preferred + PNG/JPEG)
- [ ] Supplemental Material file (if applicable)

### After Acceptance
- [ ] ORCID iDs authenticated via APS verification link
- [ ] Author names in correct order, spelled correctly
- [ ] Post-publication contact author email in byline footnote
- [ ] Grant numbers verified for accuracy

---

## Source URLs

- Author instructions: https://journals.aps.org/prapplied/authors
- Editorial policies: https://journals.aps.org/authors/editorial-policies
- Data availability: https://journals.aps.org/authors/editorial-policies#data-availability
- AI policy: https://journals.aps.org/authors/appropriate-use-ai-tools
- REVTeX: https://journals.aps.org/revtex
- Submission server: https://authors.aps.org/Submissions/
