# Table III: Circuit Architectures

| Method | Qubits | Logical Depth | 1Q Gates | CX Gates | Total Gates | Connectivity |
| --- | --- | --- | --- | --- | --- | --- |
| Angle Encoding (AE) | 4 | 1 | 4 | 0 | 4 | Independent qubits |
| AE + Entanglement (AEE) | 4 | 5 | 8 | 3 | 11 | Linear nearest-neighbor |
| IQP Feature Map | 4 | 13 | 19 | 6 | 25 | All-to-all logical (linearly routed) |
