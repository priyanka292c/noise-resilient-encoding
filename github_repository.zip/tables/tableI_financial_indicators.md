# Table I: Financial Indicators

| Indicator | Type | Window | Look-ahead | Range |
| --- | --- | --- | --- | --- |
| Close (norm.) | Price level | 252-day rolling min-max | No | [0, 1] |
| Log return | Momentum | 1-day log difference | No | [0, 1] |
| Historical vol. | Volatility | 20-day annualized std | No | [0, 1] |
| RSI-14 | Momentum | 14-day Wilder EMA | No | [0, 1] |
| MACD signal | Trend | 12/26/9 EMA cascade | No | [0, 1] |
| Momentum-10 | Momentum | 10-day price ratio | No | [0, 1] |
| MA ratio 10/50 | Trend | 10-, 50-day SMA ratio | No | [0, 1] |
| Bollinger %B | Volatility | 20-day, 2 sigma bands | No | [0, 1] |
