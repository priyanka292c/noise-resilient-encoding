# Table XII: Reference Audit Summary

| Category | Audited Count | Verified DOIs | Verification Status |
| --- | --- | --- | --- |
| Foundational Quantum Information | 8 | 8 | Confirmed active (CrossRef REST API) |
| Quantum Machine Learning | 11 | 11 | Confirmed active (CrossRef REST API) |
| Quantum Data Encoding & Feature Maps | 10 | 10 | Confirmed active (CrossRef REST API) |
| Quantum Finance & Portfolio Optimization | 12 | 12 | Confirmed active (CrossRef REST API) |
| Superconducting Hardware & Noise Models | 14 | 14 | Confirmed active (CrossRef REST API) |
| Quantum Error Mitigation & Extrapolation | 14 | 14 | Confirmed active (CrossRef REST API) |
| Quantum Device Benchmarking & Verification | 13 | 13 | Confirmed active (CrossRef REST API) |
| Open-Source Scientific Software | 3 | 3 Software | Verified repositories (Qiskit, Aer, yfinance) |
