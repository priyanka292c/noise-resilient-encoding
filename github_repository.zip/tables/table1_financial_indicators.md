# Table I: Financial Indicators (SPY 2015-2023)

| Indicator | Type | Window | Look-ahead | Range |
| --- | --- | --- | --- | --- |
| Close (norm.) | Price level | 252-day rolling | No | [0, 1] |
| Log return | Momentum | 1-day | No | [0, 1] |
| Historical vol. | Volatility | 20-day rolling | No | [0, 1] |
| RSI-14 | Momentum | 14-day EMA | No | [0, 1] |
| MACD signal | Trend | 12/26/9 EMA | No | [0, 1] |
| Momentum-10 | Momentum | 10-day | No | [0, 1] |
| MA ratio 10/50 | Trend | 10-, 50-day | No | [0, 1] |
| Bollinger %B | Volatility | 20-day, 2 sigma | No | [0, 1] |
