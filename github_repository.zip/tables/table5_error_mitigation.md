# Table V: Error Mitigation Performance Comparison

| Condition | AE Fidelity | AEE Fidelity |
| --- | --- | --- |
| Ideal (no noise) | 0.999985 | 0.840976 |
| Noisy (unmitigated, p1q=0.01, p2q=0.03) | 0.99997 | 0.845879 |
| ZNE-Linear (scale factors [1,3,5]) | 0.999976 | 0.841601 |
| ZNE-Richardson (scale factors [1,3]) | 0.999957 | 0.8412 |
| MEM (measurement confusion inversion) | 0.999972 | 0.846211 |

