# Table IV: Hardware-Calibrated Simulation Results (GenericBackendV2)

| Method | Mean Fidelity | Reconstruction MSE |
| --- | --- | --- |
| Angle Encoding (AE) | 0.999973 � 0.000018 | (1.08 � 1.70) x 10^-4 |
| AE + Entanglement (AEE) | 0.865318 � 0.103814 | 0.093245 � 0.083551 |
| IQP Feature Map | 0.935239 � 0.035598 | 0.039907 � 0.028697 |

