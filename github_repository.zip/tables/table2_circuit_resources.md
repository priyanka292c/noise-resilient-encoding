# Table II: Quantum Encoding Circuit Resource Analysis

| Method | Qubits | Depth | 1Q Gates | CX Gates | Nonlinear |
| --- | --- | --- | --- | --- | --- |
| Angle Encoding (AE) | 4 | 1 | 4 | 0 | No |
| AE + Entanglement (AEE) | 4 | 5 | 8 | 3 | No |
| IQP Feature Map | 4 | 13 | 19 | 6 | Yes |

