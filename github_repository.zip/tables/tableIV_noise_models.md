# Table IV: Noise Models

| Channel | Kraus / Generator | Swept Parameter | Range |
| --- | --- | --- | --- |
| Depolarizing (1Q) | (1-p)I + p(X rho X + Y rho Y + Z rho Z)/3 | Error probability p_1Q | [0, 0.05] |
| Depolarizing (2Q) | (1-p_2Q)I + p_2Q/15 sum (P_i tensor P_j) | Two-qubit rate p_2Q | [0, 0.15] |
| Bit-flip | (1-p)I rho I + p X rho X | Bit-flip probability p | [0, 0.10] |
| Phase-flip | (1-p)I rho I + p Z rho Z | Phase-flip probability p | [0, 0.10] |
| Amplitude damping | K0=diag(1, sqrt(1-gamma)), K1=[[0,sqrt(gamma)],[0,0]] | Decay parameter gamma | [0, 0.10] |
| Phase damping | K0=diag(1, sqrt(1-lambda)), K1=[[0,0],[0,sqrt(lambda)]] | Dephasing parameter lambda | [0, 0.10] |
| Thermal relaxation | T1, T2 Lindbladian master equation | Relaxation T1, T2 (T2 <= 2T1) | [20, 200] microsec |
| Readout error | Classical assignment confusion matrix A_jk | Bit inversion P(0|1) | [0, 0.10] |
