# Table X: Reproducibility Config

| Component | Specification | Configuration Value |
| --- | --- | --- |
| Operating System | Windows 11 / x86_64 | PowerShell 5.1 / UTF-8 |
| Python Environment | CPython 3.11.14 | Virtual environment (.venv) |
| Quantum SDK | Qiskit v1.0+ / Qiskit Aer v0.14+ | qiskit-aer 0.17.4 |
| Random Seed | Global pseudo-random seed | seed = 42 |
| Dataset Source | SPDR S&P 500 ETF (SPY daily) | Yahoo Finance (2015-01-01 to 2023-12-31) |
| Partitioning | Development / Evaluation split | 2,013 valid days (1,610 dev / 403 eval) |
| Shot Budget | Measurement shot allocations | 8,192 shots per circuit |
| Hardware Model | GenericBackendV2 (5-qubit) | Hardware-informed synthetic transmon profile (no QPU) |
