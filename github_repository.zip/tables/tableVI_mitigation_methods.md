# Table VI: Mitigation Methods

| Method | Protocol | Scale Factors | Sampling Cost |
| --- | --- | --- | --- |
| Unmitigated | Direct shot-based Pauli-Z sampling | [1] | 1x shots |
| ZNE - Linear | Digital gate folding with first-order polynomial fit | [1, 3, 5] | 3x shots + classical polyfit |
| ZNE - Richardson | Two-point Richardson extrapolation: f_0 = 1.5*f(1) - 0.5*f(3) | [1, 3] | 2x shots + exact linear combo |
| MEM (Matrix Inversion) | Calibration matrix inversion: p_mit = A^-1 * p_meas | N/A | N_meas + 2^n N_cal (17x total) |
