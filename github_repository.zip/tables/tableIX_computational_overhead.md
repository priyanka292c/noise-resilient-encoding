# Table IX: Computational Overhead

| Condition | Circuits per Sample | Shots per Circuit | Total Shots | AE F_Q | AEE F_Q | AE S_Z | AEE S_Z |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Ideal (no noise) | 1 | 8192 | 8192 | 1.0 | 1.0 | nan | nan |
| Noisy (unmitigated) | 1 | 8192 | 8192 | 0.9989 | 0.9609 | nan | nan |
| ZNE-Linear (scales [1,3,5]) | 3 | 8192 | 24576 | nan | nan | 0.999976 | 0.841601 |
| ZNE-Richardson (scales [1,3]) | 2 | 8192 | 16384 | nan | nan | 0.999957 | 0.8412 |
| MEM (confusion inversion) | 1 + 16 cal | 8192 | 139264 total | nan | nan | 0.999972 | 0.846211 |
