# Table VII: Benchmark Metrics

| Figure of Merit | Formula | Domain | Optimal | Scope |
| --- | --- | --- | --- | --- |
| True Quantum State Fidelity F_Q | (Tr sqrt(sqrt(rho_id) rho_no sqrt(rho_id)))^2 = <psi_id|rho_no|psi_id> | [0, 1] | 1.0 | Simulator density matrix |
| Z-Observable Agreement S_Z | 1 - (1/4n) sum (Z_id - Z_no)^2 | [0, 1] | 1.0 | Marginal expectation agreement |
| Observable Distortion Delta Z | (1/n) sum |Z_id - Z_no| | [0, 2] | 0.0 | Single-qubit Pauli-Z drift |
| Feature Reconstruction MSE | (1/n) sum (x_i - arccos(Z_i)/pi)^2 | [0, 1] | 0.0 | Separable AE only (non-invertible for AEE/IQP) |
| Hellinger Distance | sqrt(0.5 * sum (sqrt(p_k) - sqrt(q_k))^2) | [0, 1] | 0.0 | Measurement probability distribution |
| Shot Uncertainty | 1 / sqrt(N_shots) | (0, 1) | 0.011 | 8,192 shots finite sampling budget |
