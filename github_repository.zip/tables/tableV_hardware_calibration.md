# Table V: Hardware Calibration

| Parameter | Nominal Value | Physical Meaning |
| --- | --- | --- |
| Qubit count | 5 | Simulated superconducting transmon register |
| T1 relaxation time | 100 - 150 microsec | Energy relaxation lifetime (sampled default range) |
| T2 dephasing time | 80 - 120 microsec | Ramsey dephasing time (sampled default range) |
| Single-qubit gate error | 0.0003 - 0.0010 | Average Clifford randomized benchmarking infidelity |
| Two-qubit CX gate error | 0.0080 - 0.0250 | Interleaved randomized benchmarking error |
| Readout assignment error | 0.015 - 0.045 | State measurement discrimination confusion |
| Gate duration (1Q / 2Q) | 35 ns / 300 ns | Microwave pulse control duration |
| Physical Hardware Execution | None | Generic local simulator backend; no physical QPU used |
