# Table VIII: Main Numerical Results

| Encoding Paradigm | True State Fidelity F_Q | Observable Agreement S_Z | Distortion Delta Z | Recon MSE eps_rec |
| --- | --- | --- | --- | --- |
| Angle Encoding (AE, 0 CX) | 0.9989 ± 0.0002 | 0.99998 ± 0.00002 | 0.0069 ± 0.0028 | (1.52 ± 1.25) x 10^-5 |
| AE + Entanglement (AEE, 3 CX) | 0.9609 ± 0.0014 | 0.99996 ± 0.00002 | 0.0097 ± 0.0035 | Non-invertible without tomography |
| IQP Feature Map (6 CX) | 0.9257 ± 0.0028 | 0.99982 ± 0.00010 | 0.0195 ± 0.0053 | Non-invertible without tomography |
