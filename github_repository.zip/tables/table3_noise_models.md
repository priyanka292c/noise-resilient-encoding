# Table III: Noise Channels and Simulation Parameters

| Channel | Kraus / Generator | Parameter | Range |
| --- | --- | --- | --- |
| Depolarizing (1Q) | (1-p)I + p(X rho X + Y rho Y + Z rho Z)/3 | p (error rate) | [0, 0.05] |
| Bit-flip | (1-p)I rho I + p X rho X | p | [0, 0.10] |
| Phase-flip | (1-p)I rho I + p Z rho Z | p | [0, 0.10] |
| Amplitude damping | K0=[[1,0],[0,sqrt(1-gamma)]], K1=[[0,sqrt(gamma)],[0,0]] | gamma | [0, 0.10] |
| Phase damping | K0=[[1,0],[0,sqrt(1-lambda)]], K1=[[0,0],[0,sqrt(lambda)]] | lambda | [0, 0.10] |
| Thermal relaxation | T1, T2 master equation | T1 [microsec] | [50, 500] |
| Readout error | A_jk confusion matrix | P(0|1) | [0, 0.10] |

