# Tables Directory

This directory contains standalone tabular representations of all datasets, circuit specifications, simulation summaries, and error-mitigation benchmarks reported in the manuscript:

**"Noise Resilient Quantum Circuits for Financial Indicator Encoding and Hardware Aware Benchmarking"**  
*Physical Review Applied (APS)*

Each table is provided in three formats:
- `.tex`: REVTeX 4.2 table snippet ready for inclusion or independent compilation
- `.csv`: Machine-readable comma-separated values for archival analysis
- `.md`: Markdown table for direct viewing on GitHub / documentation

## Manifest

| Table ID | Topic | Source Script | Description |
|---|---|---|---|
| **Table I** | Financial Indicators | `02_download_prepare_data.py` | S&P 500 ETF (SPY) daily indicators (2015�2023) |
| **Table II** | Circuit Resources | `04_quantum_encoding.py` | Gate counts, depth, and 2Q entanglement resources |
| **Table III** | Noise Channels | `06_noise_models.py` | Kraus representation & swept parameter ranges |
| **Table IV** | HW-Calibrated Sim | `08_hardware_calibrated_simulation.py` | Performance on 5-qubit `GenericBackendV2` |
| **Table V** | Error Mitigation | `07_noise_mitigation.py` | ZNE vs MEM vs Unmitigated on depolarizing channel |
