# Table XI: Literature Comparison

| Study | Target Domain | Noise Channels Studied | Multi-Qubit Entanglement | Error Mitigation | Hardware Realism |
| --- | --- | --- | --- | --- | --- |
| LaRose & Coyle (2020) | Synthetic classification | Depolarizing only | Yes | None | Uncalibrated simulator |
| Weigold et al. (2021) | Software taxonomy | None (theoretical) | Taxonomy | None | Conceptual |
| Woerner & Egger (2019) | Risk analysis (QAE) | Device noise run | Yes | None | Single device run |
| Martin et al. (2021) | Derivative pricing | Device noise run | Yes | None | Hardware demo |
| This Work (2026) | Empirical SPY indicators | 7 microscopic channels | AE vs AEE vs IQP | ZNE (L/R) + MEM | Hardware-informed transmon model |
