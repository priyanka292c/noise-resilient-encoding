# Texmaker Setup and Build Guide

This project is fully compatible with **Texmaker**, the cross-platform LaTeX IDE.

## 1. Quick Build Configuration
In Texmaker (`Options -> Configure Texmaker -> Quick Build`):
Select the compilation sequence:
```
PdfLaTeX + BibTeX + PdfLaTeX (x2) + View PDF
```

## 2. Command Settings
Verify that the following executables point to your TeX distribution (e.g., MiKTeX or TeX Live):
- **PdfLaTeX:** `pdflatex -synctex=1 -interaction=nonstopmode %.tex`
- **BibTeX:** `bibtex %.aux`
- **PDF Viewer:** Built-in viewer or external system viewer

## 3. Working Directory
Open `manuscript/main.tex` in Texmaker.
Set `main.tex` as the **Master Document** (`Options -> Define Current Document as 'Master Document'`).
Press **F1** (Quick Build) to compile the complete 20-section Physical Review Applied manuscript.
