#!/usr/bin/env python3
"""
run_all.py
==========
Master pipeline runner.

Executes all pipeline scripts in order, stopping on any failure.
Random seed is fixed for full reproducibility.

Physical Review Applied manuscript:
"Noise Resilient Quantum Circuits for Financial Indicator Encoding
 and Hardware Aware Benchmarking"

Usage:
    python run_all.py              # Run all 17 stages
    python run_all.py --from 5     # Resume from script 05
    python run_all.py --only 12    # Run only figure generation
"""

import os
import sys
import subprocess
import argparse
import datetime

ROOT = os.path.dirname(os.path.abspath(__file__))
PYTHON = os.path.join(ROOT, ".venv", "Scripts", "python.exe")
PYTHON_DIR = os.path.join(ROOT, "python")

PIPELINE = [
    ("01", "01_environment_check.py",               "Environment check & dependencies"),
    ("02", "02_download_prepare_data.py",            "Data ingestion & cache check"),
    ("03", "03_feature_engineering.py",              "Causal feature engineering"),
    ("04", "04_quantum_encoding.py",                 "Quantum encoding circuits & QASM"),
    ("05", "05_ideal_simulation.py",                 "Ideal statevector simulation"),
    ("06", "06_noise_models.py",                     "Microscopic noise model sweeps"),
    ("07", "07_noise_mitigation.py",                 "Quantum error mitigation (ZNE & MEM)"),
    ("08", "08_hardware_calibrated_simulation.py",   "Hardware-calibrated simulation (GenericBackendV2)"),
    ("09", "09_hardware_execution.py",               "Hardware execution & observable extraction"),
    ("10", "10_metrics.py",                          "Benchmark metrics computation"),
    ("11", "11_statistics.py",                       "Bootstrap & statistical inference"),
    ("12", "12_generate_figures.py",                 "Publication figure generation (Figs 1-16)"),
    ("13", "13_generate_tables.py",                  "Publication table generation (Tables I-XII)"),
    ("14", "14_export_results.py",                   "Export comprehensive numerical summaries"),
    ("15", "15_reproducibility_report.py",           "Reproducibility report & SHA-256 hashes"),
    ("16", "16_generate_docx.py",                    "Word DOCX manuscript generation"),
    ("17", "17_build_submission_package.py",          "15-folder submission package & ZIP archive"),
]


def run_script(script_name: str, description: str) -> bool:
    script_path = os.path.join(PYTHON_DIR, script_name)
    print(f"\n{'='*70}")
    print(f"STAGE:   {description}")
    print(f"SCRIPT:  {script_name}")
    print(f"TIME:    {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*70}")

    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"

    result = subprocess.run(
        [PYTHON, script_path],
        cwd=ROOT,
        env=env,
        capture_output=False,
    )

    if result.returncode == 0:
        print(f"\n[OK] {description} completed successfully.")
        return True
    else:
        print(f"\n[FAIL] {description} failed with exit code {result.returncode}.")
        return False


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run the full Physical Review Applied research pipeline")
    parser.add_argument("--from", dest="from_script", type=int, default=1,
                        help="Start from script number (e.g. 5 to start from script 05)")
    parser.add_argument("--only", type=int, default=None,
                        help="Run only this script number (e.g. 12)")
    args = parser.parse_args()

    print("=" * 70)
    print("PHYSICAL REVIEW APPLIED RESEARCH PIPELINE — MASTER ORCHESTRATION")
    print(f"Started: {datetime.datetime.now().isoformat()}")
    print(f"Python:  {PYTHON}")
    print("=" * 70)

    summary = []
    overall_ok = True

    for num_str, script, description in PIPELINE:
        num = int(num_str)
        if args.only is not None and num != args.only:
            continue
        if args.only is None and num < args.from_script:
            print(f"\n[SKIP] {description} (--from {args.from_script})")
            continue

        ok = run_script(script, description)
        summary.append((num_str, description, "OK" if ok else "FAIL"))
        if not ok:
            overall_ok = False
            print(f"\n[ABORT] Pipeline stopped due to failure in stage {num_str}: {description}")
            break

    print("\n" + "=" * 70)
    print("PIPELINE EXECUTION SUMMARY")
    print("=" * 70)
    for num_str, desc, status in summary:
        print(f"  [{status:4s}] Stage {num_str}: {desc}")
    print("=" * 70)

    if overall_ok:
        print("\nALL SELECTED STAGES COMPLETED SUCCESSFULLY.")
        sys.exit(0)
    else:
        print("\nPIPELINE FAILED.")
        sys.exit(1)
