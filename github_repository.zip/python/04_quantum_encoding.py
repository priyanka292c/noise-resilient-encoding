#!/usr/bin/env python3
"""
04_quantum_encoding.py
======================
Phase 10 — Script 4: Quantum encoding circuit definitions.

Implements and documents the following encoding strategies:
  1. Angle encoding (single-layer Rx gates)
  2. Angle encoding with entanglement (Rx + CNOT chain)
  3. IQP feature map (depth-2 ZZ interactions)
  4. Amplitude encoding (via Qiskit StatePreparation)

Each encoder returns:
  - QuantumCircuit
  - metadata dict (qubits, depth, gate counts, parameter count)

Physical Review Applied manuscript:
"Noise Resilient Quantum Circuits for Financial Indicator Encoding
and Hardware Aware Benchmarking"
"""

import os
import sys
import json
import numpy as np

# Fix Windows console encoding for Unicode circuit diagrams
if sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import yaml
with open(os.path.join(ROOT, "config.yaml"), "r") as f:
    CONFIG = yaml.safe_load(f)

# Qiskit imports
from qiskit import QuantumCircuit
from qiskit.circuit import ParameterVector

# ============================================================
# Helper: count gate types
# ============================================================

def count_gates(qc: QuantumCircuit) -> dict:
    """Count single-qubit and two-qubit gates in a circuit."""
    single_qubit = 0
    two_qubit = 0
    total = 0
    for instruction in qc.data:
        n = len(instruction.qubits)
        total += 1
        if n == 1:
            single_qubit += 1
        elif n == 2:
            two_qubit += 1
    return {
        "total_gates": total,
        "single_qubit_gates": single_qubit,
        "two_qubit_gates": two_qubit,
        "circuit_depth": qc.depth(),
        "num_qubits": qc.num_qubits,
        "num_parameters": qc.num_parameters,
    }


# ============================================================
# Encoding 1: Angle encoding (no entanglement)
#
# Encoding: |x⟩ = Rx(π·x₁) ⊗ Rx(π·x₂) ⊗ Rx(π·x₃) ⊗ Rx(π·x₄)|0⟩
# Each feature x_i ∈ [0, 1] is mapped to angle θᵢ = π·xᵢ ∈ [0, π].
# Simple, hardware-efficient. Depth = 1 (excluding barriers).
# ============================================================

def angle_encoding(n_qubits: int = 4) -> tuple:
    """
    Build angle encoding circuit.

    Args:
        n_qubits: Number of qubits (= number of features)

    Returns:
        (QuantumCircuit, ParameterVector, metadata_dict)
    """
    params = ParameterVector("x", n_qubits)
    qc = QuantumCircuit(n_qubits, name="angle_encoding")

    for i in range(n_qubits):
        qc.rx(np.pi * params[i], i)

    meta = count_gates(qc)
    meta.update({
        "name": "angle_encoding",
        "description": "Rx(pi*x_i) on each qubit, no entanglement",
        "connectivity": "none (all single-qubit)",
        "transpilation_notes": "Hardware native on most backends (Rx decomposed to RZ-SX)",
    })
    return qc, params, meta


# ============================================================
# Encoding 2: Angle encoding with linear entanglement
#
# Layer 1: Rx(π·xᵢ) on each qubit
# Layer 2: CNOT chain: CX(0,1), CX(1,2), CX(2,3)
# Layer 3: Rx(π·xᵢ) again (optional second rotation after entanglement)
#
# This creates qubit correlations between encoded features.
# ============================================================

def angle_encoding_entangled(n_qubits: int = 4) -> tuple:
    """
    Build angle encoding circuit with linear CNOT entanglement.

    Args:
        n_qubits: Number of qubits

    Returns:
        (QuantumCircuit, ParameterVector, metadata_dict)
    """
    params = ParameterVector("x", n_qubits)
    qc = QuantumCircuit(n_qubits, name="angle_encoding_entangled")

    # First rotation layer
    for i in range(n_qubits):
        qc.rx(np.pi * params[i], i)

    # Entanglement layer (linear chain)
    for i in range(n_qubits - 1):
        qc.cx(i, i + 1)

    # Second rotation layer
    for i in range(n_qubits):
        qc.rx(np.pi * params[i], i)

    meta = count_gates(qc)
    meta.update({
        "name": "angle_encoding_entangled",
        "description": "Two Rx layers with linear CNOT entanglement between them",
        "connectivity": "linear: CX(0,1), CX(1,2), CX(2,3)",
        "transpilation_notes": "Requires linear or higher connectivity",
    })
    return qc, params, meta


# ============================================================
# Encoding 3: IQP feature map (Instantaneous Quantum Polynomial)
#
# Based on Havlíček et al. (2019), but simplified for NISQ:
#
# Layer 1: H on all qubits (superposition)
# Layer 2: Rz(2·x_i) on each qubit (diagonal unitaries)
# Layer 3: Rzz(2·x_i·x_j) for adjacent pairs (ZZ interactions)
#          Rzz(phi) = CX · Rz(phi) · CX
# Layer 4: H on all qubits
# Layer 5: Rz(2·x_i) again
#
# The ZZ term encodes pairwise feature products,
# which can reveal nonlinear feature interactions.
# ============================================================

def iqp_feature_map(n_qubits: int = 4) -> tuple:
    """
    Build depth-2 IQP-style feature map circuit.

    Args:
        n_qubits: Number of qubits

    Returns:
        (QuantumCircuit, ParameterVector, metadata_dict)
    """
    params = ParameterVector("x", n_qubits)
    qc = QuantumCircuit(n_qubits, name="iqp_feature_map")

    def rzz(qc, theta, q0, q1):
        """RZZ gate: exp(-i*theta/2 * Z⊗Z)."""
        qc.cx(q0, q1)
        qc.rz(2 * theta, q1)
        qc.cx(q0, q1)

    # Depth 1: Hadamard layer
    qc.h(range(n_qubits))

    # Depth 2: Rz rotations
    for i in range(n_qubits):
        qc.rz(2 * params[i], i)

    # Depth 3: ZZ interactions (linear pairs)
    for i in range(n_qubits - 1):
        rzz(qc, params[i] * params[i + 1], i, i + 1)

    # Depth 4: Second Hadamard layer
    qc.h(range(n_qubits))

    # Depth 5: Second Rz layer
    for i in range(n_qubits):
        qc.rz(2 * params[i], i)

    meta = count_gates(qc)
    meta.update({
        "name": "iqp_feature_map",
        "description": "IQP-inspired feature map with H, Rz, RZZ layers",
        "connectivity": "linear pairs: (0,1),(1,2),(2,3)",
        "transpilation_notes": "Each RZZ requires 2 CX gates; linear connectivity sufficient",
        "nonlinear": True,
        "pairwise_products": [(i, i+1) for i in range(n_qubits - 1)],
    })
    return qc, params, meta


# ============================================================
# Encoding 4: Amplitude encoding
#
# For n qubits, encode a 2^n-dimensional normalized vector
# directly into the quantum state amplitudes.
# For n=4: encodes a 16-dimensional data vector.
#
# Uses Qiskit's Initialize instruction.
# WARNING: depth grows exponentially — for n=4, depth ~O(2^n)
# This encoding is included for comparison but is not
# hardware-efficient for large n.
# ============================================================

def amplitude_encoding(state_vector: np.ndarray) -> tuple:
    """
    Build amplitude encoding circuit for given state vector.

    Args:
        state_vector: 1D numpy array of length 2^n, will be normalized.

    Returns:
        (QuantumCircuit, None, metadata_dict)
        (No ParameterVector — state-specific circuit)
    """
    n = len(state_vector)
    n_qubits = int(np.log2(n))
    assert 2 ** n_qubits == n, f"State vector length {n} must be a power of 2"

    # Normalize
    norm = np.linalg.norm(state_vector)
    if norm < 1e-12:
        raise ValueError("State vector has near-zero norm")
    state_vector_normalized = state_vector / norm

    qc = QuantumCircuit(n_qubits, name="amplitude_encoding")
    qc.initialize(state_vector_normalized)

    meta = count_gates(qc)
    meta.update({
        "name": "amplitude_encoding",
        "description": f"Encode {n}-dimensional vector into amplitudes of {n_qubits} qubits",
        "depth_note": "Depth grows as O(2^n); not hardware-efficient for large n",
        "normalization": "State vector normalized to unit norm before encoding",
        "connectivity": "all-to-all (hardware transpilation may add SWAP gates)",
    })
    return qc, None, meta


# ============================================================
# Main: print circuit summaries and save metadata
# ============================================================

if __name__ == "__main__":
    print("=" * 60)
    print("QUANTUM ENCODING CIRCUITS")
    print("=" * 60)

    RESULTS_DIR = os.path.join(ROOT, "results")
    os.makedirs(RESULTS_DIR, exist_ok=True)
    TABLES_DIR = os.path.join(ROOT, "tables")
    os.makedirs(TABLES_DIR, exist_ok=True)

    all_meta = {}

    # 1. Angle encoding
    qc1, p1, m1 = angle_encoding(n_qubits=4)
    all_meta["angle_encoding"] = m1
    print("\n[1] Angle Encoding")
    print(f"    Qubits: {m1['num_qubits']}, Depth: {m1['circuit_depth']}, "
          f"1Q gates: {m1['single_qubit_gates']}, 2Q gates: {m1['two_qubit_gates']}")
    print(qc1.draw(output='text', fold=-1))

    # 2. Angle encoding with entanglement
    qc2, p2, m2 = angle_encoding_entangled(n_qubits=4)
    all_meta["angle_encoding_entangled"] = m2
    print("\n[2] Angle Encoding with Entanglement")
    print(f"    Qubits: {m2['num_qubits']}, Depth: {m2['circuit_depth']}, "
          f"1Q gates: {m2['single_qubit_gates']}, 2Q gates: {m2['two_qubit_gates']}")
    print(qc2.draw(output='text', fold=-1))

    # 3. IQP feature map
    qc3, p3, m3 = iqp_feature_map(n_qubits=4)
    all_meta["iqp_feature_map"] = m3
    print("\n[3] IQP Feature Map")
    print(f"    Qubits: {m3['num_qubits']}, Depth: {m3['circuit_depth']}, "
          f"1Q gates: {m3['single_qubit_gates']}, 2Q gates: {m3['two_qubit_gates']}")
    print(qc3.draw(output='text', fold=-1))

    # 4. Amplitude encoding (example: random 16-dim vector)
    rng = np.random.default_rng(CONFIG["random_seed"])
    sv = rng.random(16)
    qc4, _, m4 = amplitude_encoding(sv)
    all_meta["amplitude_encoding"] = m4
    print("\n[4] Amplitude Encoding (random 16-dim example)")
    print(f"    Qubits: {m4['num_qubits']}, Depth: {m4['circuit_depth']}, "
          f"1Q gates: {m4['single_qubit_gates']}, 2Q gates: {m4['two_qubit_gates']}")
    # Don't draw — can be very long

    # Save metadata
    meta_path = os.path.join(RESULTS_DIR, "encoding_circuit_metadata.json")
    with open(meta_path, "w") as f:
        json.dump(all_meta, f, indent=2, default=str)
    print(f"\nEncoding metadata saved: {meta_path}")

    # Save circuits as QASM (for reproducibility)
    qasm_dir = os.path.join(RESULTS_DIR, "circuits")
    os.makedirs(qasm_dir, exist_ok=True)
    for name, qc in [("angle_encoding", qc1),
                     ("angle_encoding_entangled", qc2),
                     ("iqp_feature_map", qc3)]:
        try:
            from qiskit.qasm2 import dumps
            qasm_str = dumps(qc)
            qasm_path = os.path.join(qasm_dir, f"{name}.qasm")
            with open(qasm_path, "w") as f:
                f.write(qasm_str)
            print(f"QASM saved: {qasm_path}")
        except Exception as e:
            print(f"  [WARN] QASM export failed for {name}: {e}")

    print("\n" + "=" * 60)
    print("Quantum encoding circuits COMPLETE.")
    print("=" * 60)
