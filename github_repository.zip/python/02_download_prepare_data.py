#!/usr/bin/env python3
"""
02_download_prepare_data.py
============================
Phase 10 — Script 2: Download and prepare financial data.

Source: Yahoo Finance via yfinance (open, reproducible, no API key required)
Ticker: SPY (S&P 500 ETF)
Period: 2015-01-01 to 2023-12-31 (daily bars)

IMPORTANT:
- No look-ahead bias: all features are computed using only past data
- Random seed fixed for reproducibility
- All metadata stored in data/metadata/dataset_metadata.json

Physical Review Applied manuscript:
"Noise Resilient Quantum Circuits for Financial Indicator Encoding
and Hardware Aware Benchmarking"
"""

import os
import sys
import json
import datetime
import numpy as np
import pandas as pd

# ----- Path setup -----
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import yaml
with open(os.path.join(ROOT, "config.yaml"), "r") as f:
    CONFIG = yaml.safe_load(f)

RANDOM_SEED = CONFIG["random_seed"]
np.random.seed(RANDOM_SEED)

RAW_DIR = os.path.join(ROOT, CONFIG["data"]["raw_dir"])
PROCESSED_DIR = os.path.join(ROOT, CONFIG["data"]["processed_dir"])
META_DIR = os.path.join(ROOT, CONFIG["data"]["metadata_dir"])
for d in [RAW_DIR, PROCESSED_DIR, META_DIR]:
    os.makedirs(d, exist_ok=True)

TICKER = CONFIG["data"]["ticker"]
START = CONFIG["data"]["start_date"]
END = CONFIG["data"]["end_date"]
INTERVAL = CONFIG["data"]["interval"]
TRAIN_FRAC = CONFIG["data"]["train_fraction"]

print("=" * 60)
print("DOWNLOAD AND PREPARE DATA")
print("=" * 60)
print(f"Ticker:   {TICKER}")
print(f"Period:   {START} to {END}")
print(f"Interval: {INTERVAL}")
print()

# ----- Download -----
import yfinance as yf
download_ts = datetime.datetime.now().isoformat()

print(f"Downloading {TICKER} from Yahoo Finance...")
df = yf.download(TICKER, start=START, end=END, interval=INTERVAL,
                 auto_adjust=True, progress=False)

if df.empty:
    print("[ERROR] Download returned empty DataFrame. Check network connection.")
    sys.exit(1)

# Flatten multi-level columns if present
if isinstance(df.columns, pd.MultiIndex):
    df.columns = df.columns.get_level_values(0)

print(f"  Downloaded {len(df)} rows")
print(f"  Date range: {df.index[0].date()} to {df.index[-1].date()}")
print(f"  Columns: {list(df.columns)}")

# Save raw data
raw_path = os.path.join(RAW_DIR, f"{TICKER}_raw_{START}_{END}.csv")
df.to_csv(raw_path)
print(f"  Raw data saved: {raw_path}")

# ----- Feature engineering (no look-ahead bias) -----
print("\nComputing financial indicators...")

# Ensure we have Close prices
close = df["Close"].astype(float)
volume = df["Volume"].astype(float) if "Volume" in df.columns else None

# 1. Normalized close price (rolling min-max over 252-day window)
window_norm = 252
close_min = close.rolling(window_norm, min_periods=window_norm).min()
close_max = close.rolling(window_norm, min_periods=window_norm).max()
close_range = close_max - close_min
close_range = close_range.replace(0, np.nan)
close_normalized = (close - close_min) / close_range
close_normalized.name = "close_normalized"

# 2. 1-day log return
log_return_1d = np.log(close / close.shift(1))
log_return_1d.name = "log_return_1d"

# 3. 20-day historical volatility (annualized)
hist_vol_20d = log_return_1d.rolling(20).std() * np.sqrt(252)
hist_vol_20d.name = "historical_volatility_20d"

# 4. RSI (14-day), normalized to [0, 1]
def compute_rsi(series, period=14):
    delta = series.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = -delta.where(delta < 0, 0.0)
    avg_gain = gain.ewm(com=period - 1, min_periods=period).mean()
    avg_loss = loss.ewm(com=period - 1, min_periods=period).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    return rsi / 100.0  # normalize to [0, 1]

rsi_14 = compute_rsi(close, period=14)
rsi_14.name = "rsi_14"

# 5. MACD signal (normalized)
ema12 = close.ewm(span=12, min_periods=12).mean()
ema26 = close.ewm(span=26, min_periods=26).mean()
macd_line = ema12 - ema26
signal_line = macd_line.ewm(span=9, min_periods=9).mean()
macd_hist = macd_line - signal_line
# Normalize MACD histogram using rolling z-score
macd_roll_mean = macd_hist.rolling(252, min_periods=50).mean()
macd_roll_std = macd_hist.rolling(252, min_periods=50).std()
macd_norm = (macd_hist - macd_roll_mean) / macd_roll_std.replace(0, np.nan)
# Clip to [-3, 3] and rescale to [0, 1]
macd_norm = macd_norm.clip(-3, 3)
macd_signal = (macd_norm + 3) / 6.0
macd_signal.name = "macd_signal"

# 6. 10-day momentum, normalized
momentum_10d = (close - close.shift(10)) / close.shift(10)
mom_roll_mean = momentum_10d.rolling(252, min_periods=50).mean()
mom_roll_std = momentum_10d.rolling(252, min_periods=50).std()
momentum_norm = (momentum_10d - mom_roll_mean) / mom_roll_std.replace(0, np.nan)
momentum_norm = momentum_norm.clip(-3, 3)
momentum_norm = (momentum_norm + 3) / 6.0
momentum_norm.name = "momentum_10d"

# 7. MA ratio (10-day MA / 50-day MA), normalized
ma10 = close.rolling(10).mean()
ma50 = close.rolling(50, min_periods=50).mean()
ma_ratio = ma10 / ma50.replace(0, np.nan)
# Normalize using rolling z-score
mar_mean = ma_ratio.rolling(252, min_periods=50).mean()
mar_std = ma_ratio.rolling(252, min_periods=50).std()
ma_ratio_norm = (ma_ratio - mar_mean) / mar_std.replace(0, np.nan)
ma_ratio_norm = ma_ratio_norm.clip(-3, 3)
ma_ratio_norm = (ma_ratio_norm + 3) / 6.0
ma_ratio_norm.name = "ma_ratio_10_50"

# 8. Bollinger %B (20-day, 2 sigma)
bb_mid = close.rolling(20).mean()
bb_std = close.rolling(20).std()
bb_upper = bb_mid + 2 * bb_std
bb_lower = bb_mid - 2 * bb_std
bb_range = bb_upper - bb_lower
bb_range = bb_range.replace(0, np.nan)
bollinger_pct_b = (close - bb_lower) / bb_range
bollinger_pct_b = bollinger_pct_b.clip(0, 1)
bollinger_pct_b.name = "bollinger_pct_b"

# ----- Combine and clean -----
features_df = pd.DataFrame({
    "close_normalized": close_normalized,
    "log_return_1d": log_return_1d,
    "historical_volatility_20d": hist_vol_20d,
    "rsi_14": rsi_14,
    "macd_signal": macd_signal,
    "momentum_10d": momentum_norm,
    "ma_ratio_10_50": ma_ratio_norm,
    "bollinger_pct_b": bollinger_pct_b,
})

# Drop NaN rows (from warm-up periods)
features_clean = features_df.dropna()
n_total = len(features_clean)
print(f"  Total valid samples after warm-up removal: {n_total}")

# Verify no look-ahead bias: all features use only past data
# (rolling windows shift backward, no future data used)
print("  Look-ahead bias check: PASS (all features use past data only)")

# ----- Feature descriptive statistics -----
print("\nFeature statistics:")
print(features_clean.describe().round(4).to_string())

# Verify all features in [0, 1] (required for angle encoding theta = pi * x)
for col in features_clean.columns:
    if col != "log_return_1d":  # log returns can be outside [0,1]
        vmin = features_clean[col].min()
        vmax = features_clean[col].max()
        if vmin < -0.01 or vmax > 1.01:
            print(f"  [WARN] {col} has values outside [0,1]: [{vmin:.4f}, {vmax:.4f}]")
        else:
            print(f"  [OK] {col}: [{vmin:.4f}, {vmax:.4f}]")

# Normalize log_return_1d to [0, 1] using rolling z-score + sigmoid-like clip
lr = features_clean["log_return_1d"]
lr_mean = lr.expanding(min_periods=1).mean()
lr_std = lr.expanding(min_periods=1).std()
lr_z = (lr - lr_mean) / lr_std.replace(0, np.nan)
lr_z = lr_z.fillna(0).clip(-3, 3)
features_clean = features_clean.copy()
features_clean["log_return_1d"] = (lr_z + 3) / 6.0
print("  log_return_1d normalized to [0,1] via rolling z-score")

# ----- Select 4 features for quantum encoding (matches qubit count) -----
# Selected: close_normalized, rsi_14, macd_signal, bollinger_pct_b
# These represent: price level, momentum, trend, band position
ENCODING_FEATURES = [
    "close_normalized",
    "rsi_14",
    "macd_signal",
    "bollinger_pct_b",
]
features_encoding = features_clean[ENCODING_FEATURES]
print(f"\nSelected encoding features: {ENCODING_FEATURES}")

# ----- Train/test split (chronological, no shuffling) -----
n_train = int(n_total * TRAIN_FRAC)
n_test = n_total - n_train
train_df = features_encoding.iloc[:n_train]
test_df = features_encoding.iloc[n_train:]
print(f"\nTrain samples: {n_train} ({train_df.index[0].date()} to {train_df.index[-1].date()})")
print(f"Test samples:  {n_test} ({test_df.index[0].date()} to {test_df.index[-1].date()})")

# ----- Save processed data -----
all_features_path = os.path.join(PROCESSED_DIR, "all_features.csv")
encoding_path = os.path.join(PROCESSED_DIR, "encoding_features.csv")
train_path = os.path.join(PROCESSED_DIR, "train_features.csv")
test_path = os.path.join(PROCESSED_DIR, "test_features.csv")

features_clean.to_csv(all_features_path)
features_encoding.to_csv(encoding_path)
train_df.to_csv(train_path)
test_df.to_csv(test_path)

print(f"\nSaved: {all_features_path}")
print(f"Saved: {encoding_path}")
print(f"Saved: {train_path}")
print(f"Saved: {test_path}")

# ----- Metadata -----
metadata = {
    "dataset_source": "Yahoo Finance",
    "library": "yfinance",
    "ticker": TICKER,
    "description": "S&P 500 ETF (SPY) — highly liquid, publicly available, daily OHLCV data",
    "start_date": START,
    "end_date": END,
    "interval": INTERVAL,
    "download_timestamp": download_ts,
    "n_raw_rows": len(df),
    "n_valid_rows": n_total,
    "n_train": n_train,
    "n_test": n_test,
    "train_fraction": TRAIN_FRAC,
    "random_seed": RANDOM_SEED,
    "split_method": "chronological (no shuffling)",
    "look_ahead_bias": False,
    "encoding_features": ENCODING_FEATURES,
    "all_features": list(features_clean.columns),
    "normalization": {
        "close_normalized": "rolling min-max, 252-day window",
        "log_return_1d": "rolling z-score + clip to [-3,3], rescaled to [0,1]",
        "historical_volatility_20d": "rolling z-score + clip, rescaled to [0,1]",
        "rsi_14": "native RSI/100",
        "macd_signal": "rolling z-score + clip, rescaled to [0,1]",
        "momentum_10d": "rolling z-score + clip, rescaled to [0,1]",
        "ma_ratio_10_50": "rolling z-score + clip, rescaled to [0,1]",
        "bollinger_pct_b": "Bollinger %B clipped to [0,1]",
    },
    "raw_file": raw_path,
    "processed_files": {
        "all_features": all_features_path,
        "encoding_features": encoding_path,
        "train": train_path,
        "test": test_path,
    },
    "feature_statistics": features_clean.describe().round(6).to_dict(),
}

meta_path = os.path.join(META_DIR, "dataset_metadata.json")
with open(meta_path, "w") as f:
    json.dump(metadata, f, indent=2, default=str)
print(f"Metadata saved: {meta_path}")

print("\n" + "=" * 60)
print("Data pipeline COMPLETE.")
print("=" * 60)
