#!/usr/bin/env python3
"""
08_hardware_calibrated_simulation.py
=====================================
Phase 10 — Script 8: Hardware-calibrated noise simulation.

Uses Qiskit's fake backend (GenericBackendV2) to simulate realistic 
device noise based on publicly available calibration data.

IMPORTANT LABEL:
All results in this script are from "hardware-calibrated simulation."
NO physical quantum hardware measurements were performed.
This is clearly labeled in all outputs.

Physical Review Applied manuscript:
"Noise Resilient Quantum Circuits for Financial Indicator Encoding
and Hardware Aware Benchmarking"
"""

import os
import sys
import json
import numpy as np
import pandas as pd
from tqdm import tqdm

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

import yaml
with open(os.path.join(ROOT, "config.yaml"), "r") as f:
    CONFIG = yaml.safe_load(f)

RANDOM_SEED = CONFIG["random_seed"]
np.random.seed(RANDOM_SEED)

RESULTS_DIR = os.path.join(ROOT, "results")
HW_CAL_DIR = os.path.join(ROOT, "data", "hardware_calibration")
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(HW_CAL_DIR, exist_ok=True)

from qiskit import transpile
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel

sys.path.insert(0, os.path.join(ROOT, "python"))
from encoding_utils import (
    angle_encoding, angle_encoding_entangled, iqp_feature_map,
    bind_parameters, z_expectation_from_counts,
    ideal_z_expectation, compute_fidelity, feature_reconstruction_error,
)

SHOTS = CONFIG["shots"]["noisy"]
N_QUBITS = 4
HW_LABEL = "hardware-calibrated simulation"

print("=" * 60)
print("HARDWARE-CALIBRATED SIMULATION")
print(f"Label: {HW_LABEL}")
print("=" * 60)
print()
print("NOTICE: No physical quantum hardware measurements were performed.")
print("Results use a fake backend noise model (GenericBackendV2)")
print("with publicly available typical NISQ-era calibration parameters.")
print()

# ============================================================
# Build hardware-calibrated noise model
# ============================================================

# Use GenericBackendV2 — available in Qiskit without IBM credentials
# This provides a realistic noise model based on typical 5-qubit backend parameters
try:
    from qiskit.providers.fake_provider import GenericBackendV2
    fake_backend = GenericBackendV2(num_qubits=5)
    hw_noise_model = NoiseModel.from_backend(fake_backend)
    backend_name = "GenericBackendV2 (5-qubit)"
    coupling_map = list(fake_backend.coupling_map)
    print(f"Fake backend: {backend_name}")
    print(f"Coupling map: {coupling_map}")

    # Extract calibration parameters
    # GenericBackendV2 generates synthetic but realistic parameters
    cal_data = {
        "backend_name": backend_name,
        "num_qubits": 5,
        "simulation_label": HW_LABEL,
        "real_hardware_used": False,
        "note": (
            "GenericBackendV2 generates synthetic but NISQ-realistic "
            "gate error rates, T1/T2 times, and readout errors. "
            "These are representative of typical 5-qubit superconducting devices "
            "but are NOT from a specific calibration snapshot."
        ),
        "coupling_map": str(coupling_map),
    }

    # Try to extract typical parameters from the backend properties
    try:
        props = fake_backend.target
        gate_errors = {}
        for gate_name in ["cx", "x", "rz", "reset"]:
            if gate_name in [op.name for op in props.operations]:
                gate_errors[gate_name] = "available in target"
        cal_data["gate_errors_extracted"] = gate_errors
    except Exception as e:
        cal_data["gate_errors_extracted"] = f"extraction error: {e}"

    # Add typical NISQ parameters as documentation
    cal_data["typical_nisq_parameters"] = {
        "T1_us": "50-200",
        "T2_us": "30-150",
        "single_qubit_gate_error": "1e-4 to 1e-3",
        "two_qubit_gate_error": "1e-3 to 1e-2",
        "readout_error": "1e-3 to 1e-2",
        "gate_time_single_qubit_ns": "20-50",
        "gate_time_cx_ns": "100-400",
    }

    # Save calibration metadata
    cal_path = os.path.join(HW_CAL_DIR, "fake_backend_parameters.json")
    with open(cal_path, "w") as f:
        json.dump(cal_data, f, indent=2, default=str)
    print(f"Calibration metadata saved: {cal_path}")

except Exception as e:
    print(f"[WARN] GenericBackendV2 failed: {e}")
    print("Falling back to hand-crafted NISQ noise model...")
    from qiskit_aer.noise import (NoiseModel, depolarizing_error,
                                   thermal_relaxation_error, ReadoutError)
    # Typical IBM-like 5-qubit parameters
    hw_noise_model = NoiseModel()
    # Single-qubit: ~0.1% depolarizing
    err_1q = depolarizing_error(0.001, 1)
    hw_noise_model.add_all_qubit_quantum_error(err_1q, ["rx", "ry", "rz", "h"])
    # Two-qubit CX: ~1% depolarizing
    err_2q = depolarizing_error(0.01, 2)
    hw_noise_model.add_all_qubit_quantum_error(err_2q, ["cx"])
    # Readout: ~1% error
    from qiskit_aer.noise import ReadoutError
    ro_err = ReadoutError([[0.99, 0.01], [0.01, 0.99]])
    for q in range(N_QUBITS):
        hw_noise_model.add_readout_error(ro_err, [q])
    backend_name = "hand-crafted NISQ model (fallback)"
    cal_data = {
        "backend_name": backend_name,
        "simulation_label": HW_LABEL,
        "real_hardware_used": False,
        "parameters": {
            "single_qubit_depolarizing": 0.001,
            "two_qubit_depolarizing": 0.01,
            "readout_error_symmetric": 0.01,
        }
    }
    cal_path = os.path.join(HW_CAL_DIR, "fallback_noise_model.json")
    with open(cal_path, "w") as f:
        json.dump(cal_data, f, indent=2)
    print(f"Fallback noise model saved: {cal_path}")

# ============================================================
# Load test data
# ============================================================

test_path = os.path.join(ROOT, CONFIG["data"]["processed_dir"], "test_features.csv")
test_df = pd.read_csv(test_path, index_col=0)
ENCODING_FEATURES = ["close_normalized", "rsi_14", "macd_signal", "bollinger_pct_b"]
available_cols = [c for c in ENCODING_FEATURES if c in test_df.columns]
X_test = test_df[available_cols].values

rng = np.random.default_rng(RANDOM_SEED)
idx = rng.choice(len(X_test), size=min(50, len(X_test)), replace=False)
X_subset = X_test[idx]
print(f"\nEvaluating on {len(X_subset)} samples from test set...")

# ============================================================
# Run hardware-calibrated simulation
# ============================================================

sim = AerSimulator(noise_model=hw_noise_model)

encoders = [
    (angle_encoding, "angle_encoding"),
    (angle_encoding_entangled, "angle_encoding_entangled"),
    (iqp_feature_map, "iqp_feature_map"),
]

all_records = []

for enc_fn, enc_name in encoders:
    print(f"\n[{HW_LABEL}] {enc_name}")
    qc, params, meta = enc_fn(N_QUBITS)
    qc_meas = qc.copy()
    qc_meas.measure_all()

    fidelities = []
    recon_errors = []

    for i, x in enumerate(tqdm(X_subset, desc=enc_name)):
        try:
            qc_bound = bind_parameters(qc_meas, params, x)
            qc_t = transpile(qc_bound, backend=sim, optimization_level=1)
            counts = sim.run(qc_t, shots=SHOTS).result().get_counts()
            z_noisy = z_expectation_from_counts(counts, N_QUBITS)
            z_ideal = ideal_z_expectation(x)
            fid = compute_fidelity(z_ideal, z_noisy)
            rec_err = feature_reconstruction_error(x, z_noisy)
            fidelities.append(fid)
            recon_errors.append(rec_err)

            all_records.append({
                "encoding": enc_name,
                "sample_idx": int(idx[i]),
                "x_values": x.tolist(),
                "z_ideal": z_ideal.tolist(),
                "z_hw_calibrated": z_noisy.tolist(),
                "fidelity": fid,
                "reconstruction_error": rec_err,
                "backend": backend_name,
                "simulation_label": HW_LABEL,
            })
        except Exception as e:
            print(f"  [WARN] Sample {i} failed: {e}")

    if fidelities:
        print(f"  Mean fidelity: {np.mean(fidelities):.6f} ± {np.std(fidelities):.6f}")
        print(f"  Mean reconstruction error: {np.mean(recon_errors):.8f}")

# Save results
results_df = pd.DataFrame(all_records)
out_path = os.path.join(RESULTS_DIR, "hardware_calibrated_results.csv")
results_df.to_csv(out_path, index=False)
print(f"\nHardware-calibrated results saved: {out_path}")

# Summary
summary = results_df.groupby("encoding")[["fidelity", "reconstruction_error"]].agg(
    ["mean", "std", "min", "max"]).round(8)
summary_path = os.path.join(RESULTS_DIR, "hardware_calibrated_summary.csv")
summary.to_csv(summary_path)
print(f"Summary saved: {summary_path}")
print("\nHardware-calibrated summary:")
print(summary.to_string())

print("\n" + "=" * 60)
print(f"Hardware-calibrated simulation COMPLETE.")
print(f"All results are from '{HW_LABEL}'.")
print(f"No physical hardware was used.")
print("=" * 60)
