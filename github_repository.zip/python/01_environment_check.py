#!/usr/bin/env python3
"""
01_environment_check.py
=======================
Phase 10 — Script 1: Environment verification.

Physical Review Applied manuscript:
"Noise Resilient Quantum Circuits for Financial Indicator Encoding
and Hardware Aware Benchmarking"

Checks all required packages are present and prints version information.
Records output to results/environment_report.json.
"""

import sys
import json
import datetime
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS_DIR = os.path.join(ROOT, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

REQUIRED = [
    "qiskit",
    "qiskit_aer",
    "numpy",
    "scipy",
    "pandas",
    "matplotlib",
    "sklearn",
    "yfinance",
    "ta",
    "yaml",
    "tqdm",
    "seaborn",
    "statsmodels",
    "docx",
    "requests",
]

OPTIONAL = [
    "qiskit_ibm_runtime",
]

report = {
    "timestamp": datetime.datetime.now().isoformat(),
    "python_version": sys.version,
    "python_executable": sys.executable,
    "required_packages": {},
    "optional_packages": {},
    "missing_required": [],
    "missing_optional": [],
    "status": "UNKNOWN",
}

print("=" * 60)
print("ENVIRONMENT CHECK")
print("=" * 60)
print(f"Python:     {sys.version}")
print(f"Executable: {sys.executable}")
print()

all_ok = True

for pkg in REQUIRED:
    import_name = pkg.replace("-", "_")
    try:
        mod = __import__(import_name)
        version = getattr(mod, "__version__", "UNKNOWN")
        report["required_packages"][pkg] = version
        print(f"  [OK] {pkg:30s} {version}")
    except ImportError as e:
        report["required_packages"][pkg] = "MISSING"
        report["missing_required"].append(pkg)
        print(f"  [MISSING] {pkg:30s} — {e}")
        all_ok = False

print()
for pkg in OPTIONAL:
    import_name = pkg.replace("-", "_")
    try:
        mod = __import__(import_name)
        version = getattr(mod, "__version__", "UNKNOWN")
        report["optional_packages"][pkg] = version
        print(f"  [OK-OPT]  {pkg:30s} {version}")
    except ImportError:
        report["optional_packages"][pkg] = "NOT INSTALLED"
        report["missing_optional"].append(pkg)
        print(f"  [WARN]    {pkg:30s} not installed (optional)")

# Qiskit AER backends
print()
try:
    from qiskit_aer import AerSimulator
    from qiskit_aer.noise import NoiseModel
    sim = AerSimulator()
    print(f"  [OK] AerSimulator backend available: {sim.name}")

    # Check FakeManila (hardware-calibrated noise model)
    try:
        from qiskit_aer.primitives import Sampler
        print("  [OK] qiskit_aer.primitives.Sampler available")
    except ImportError:
        print("  [WARN] qiskit_aer.primitives.Sampler not available")

    # Check fake backends
    try:
        from qiskit_ibm_runtime.fake_provider import FakeManilaV2
        fb = FakeManilaV2()
        print(f"  [OK] FakeManilaV2 available (hardware-calibrated noise model)")
        report["fake_backend"] = "FakeManilaV2"
    except Exception as e:
        try:
            from qiskit.providers.fake_provider import GenericBackendV2
            print(f"  [OK] GenericBackendV2 available as fallback")
            report["fake_backend"] = "GenericBackendV2"
        except Exception as e2:
            print(f"  [WARN] No fake backend found: {e} / {e2}")
            report["fake_backend"] = "NONE"
except Exception as e:
    print(f"  [FAIL] AerSimulator not available: {e}")
    all_ok = False

report["status"] = "OK" if all_ok else "FAILED"

out_path = os.path.join(RESULTS_DIR, "environment_report.json")
with open(out_path, "w") as f:
    json.dump(report, f, indent=2)

print()
print("=" * 60)
print(f"Status: {report['status']}")
print(f"Report saved: {out_path}")
print("=" * 60)

if not all_ok:
    print("\nMissing required packages:")
    for p in report["missing_required"]:
        print(f"  - {p}")
    print("\nInstall with:")
    print("  uv pip install qiskit qiskit-aer yfinance pandas scipy "
          "scikit-learn ta python-docx pyyaml requests tqdm seaborn statsmodels")
    sys.exit(1)

print("\nEnvironment check PASSED.")
