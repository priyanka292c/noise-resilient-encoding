#!/usr/bin/env python3
"""
07_noise_mitigation.py
======================
Phase 10 — Script 7: Noise mitigation experiments.

Implements and benchmarks three mitigation strategies:
  1. No mitigation (baseline)
  2. Zero-Noise Extrapolation (ZNE) via gate-folding
     - Linear extrapolation with scale factors [1, 2, 3]
     - Richardson extrapolation with scale factors [1, 3]
  3. Measurement error mitigation (matrix inversion)

All experiments use Qiskit Aer with depolarizing noise.
Results are compared to ideal (noise-free) expectations.

Physical Review Applied manuscript:
"Noise Resilient Quantum Circuits for Financial Indicator Encoding
and Hardware Aware Benchmarking"
"""

import os
import sys
import json
import numpy as np
import pandas as pd
from tqdm import tqdm

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import yaml
with open(os.path.join(ROOT, "config.yaml"), "r") as f:
    CONFIG = yaml.safe_load(f)

RANDOM_SEED = CONFIG["random_seed"]
np.random.seed(RANDOM_SEED)

RESULTS_DIR = os.path.join(ROOT, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error

sys.path.insert(0, os.path.join(ROOT, "python"))
from encoding_utils import (
    angle_encoding, angle_encoding_entangled,
    bind_parameters, z_expectation_from_counts,
    ideal_z_expectation, compute_fidelity,
)

SHOTS = CONFIG["shots"]["mitigation"]
N_QUBITS = 4

# Noise level for mitigation experiments (moderate depolarizing)
P1Q = 0.01   # 1% single-qubit depolarizing
P2Q = 0.03   # 3% two-qubit depolarizing


def build_noise_model(p1q=P1Q, p2q=P2Q) -> NoiseModel:
    nm = NoiseModel()
    nm.add_all_qubit_quantum_error(depolarizing_error(p1q, 1),
                                    ["rx", "ry", "rz", "h", "x"])
    nm.add_all_qubit_quantum_error(depolarizing_error(p2q, 2), ["cx"])
    return nm


def run_circuit(qc_bound, noise_model=None, shots=SHOTS) -> dict:
    sim = AerSimulator(noise_model=noise_model)
    qc_t = transpile(qc_bound, backend=sim, optimization_level=0)
    counts = sim.run(qc_t, shots=shots).result().get_counts()
    return counts


def fold_gates(qc: QuantumCircuit, scale_factor: int) -> QuantumCircuit:
    """
    Gate-folding ZNE: replace each gate G with G*G^dag*G to
    achieve effective noise scale factor (must be odd integer >= 1).
    """
    if scale_factor == 1:
        return qc
    assert scale_factor % 2 == 1 and scale_factor >= 1

    n_folds = (scale_factor - 1) // 2
    qc_folded = QuantumCircuit(qc.num_qubits, qc.num_clbits)

    for instruction in qc.data:
        op = instruction.operation
        qargs = instruction.qubits
        cargs = instruction.clbits

        if op.name in ["measure", "barrier", "reset"]:
            qc_folded.append(instruction)
            continue

        qc_folded.append(op, qargs, cargs)
        for _ in range(n_folds):
            qc_folded.append(op.inverse(), qargs, cargs)
            qc_folded.append(op, qargs, cargs)

    return qc_folded


def zne_linear_extrapolate(z_values: list, scale_factors: list) -> np.ndarray:
    """Linear ZNE extrapolation to zero noise."""
    z_arr = np.array(z_values)
    c_arr = np.array(scale_factors, dtype=float)
    n_qubits = z_arr.shape[1]
    z_extrap = np.zeros(n_qubits)
    for q in range(n_qubits):
        coeffs = np.polyfit(c_arr, z_arr[:, q], deg=1)
        z_extrap[q] = coeffs[-1]
    return z_extrap


def zne_richardson_extrapolate(z_values: list, scale_factors: list) -> np.ndarray:
    """Richardson extrapolation to zero noise."""
    z_arr = np.array(z_values)
    c_arr = np.array(scale_factors, dtype=float)
    n_qubits = z_arr.shape[1]
    degree = len(scale_factors) - 1
    z_extrap = np.zeros(n_qubits)
    for q in range(n_qubits):
        coeffs = np.polyfit(c_arr, z_arr[:, q], deg=degree)
        z_extrap[q] = np.polyval(coeffs, 0.0)
    return z_extrap


def build_calibration_matrix(n_qubits: int, noise_model: NoiseModel,
                               shots: int = 2048) -> np.ndarray:
    """Build calibration matrix for measurement error mitigation."""
    n_states = 2 ** n_qubits
    cal_matrix = np.zeros((n_states, n_states))
    sim = AerSimulator(noise_model=noise_model)

    for state_idx in range(n_states):
        qc_cal = QuantumCircuit(n_qubits, n_qubits)
        bin_str = format(state_idx, f'0{n_qubits}b')
        for q, bit in enumerate(reversed(bin_str)):
            if bit == '1':
                qc_cal.x(q)
        qc_cal.measure(range(n_qubits), range(n_qubits))
        qc_t = transpile(qc_cal, backend=sim, optimization_level=0)
        counts = sim.run(qc_t, shots=shots).result().get_counts()
        for outcome, count in counts.items():
            outcome_idx = int(outcome, 2)
            cal_matrix[outcome_idx, state_idx] += count / shots

    return cal_matrix


def apply_measurement_mitigation(counts: dict, cal_matrix: np.ndarray,
                                   n_qubits: int) -> np.ndarray:
    """Apply measurement error mitigation via pseudo-inverse."""
    n_states = 2 ** n_qubits
    total = sum(counts.values())
    prob_vec = np.zeros(n_states)
    for outcome, count in counts.items():
        idx = int(outcome, 2)
        prob_vec[idx] = count / total
    cal_inv = np.linalg.pinv(cal_matrix)
    mitigated_probs = cal_inv @ prob_vec
    mitigated_probs = np.clip(mitigated_probs, 0, None)
    norm = mitigated_probs.sum()
    if norm > 0:
        mitigated_probs /= norm
    return mitigated_probs


def mitigated_z_expectation(mitigated_probs: np.ndarray, n_qubits: int) -> np.ndarray:
    """Compute <Z_i> from mitigated probability vector."""
    z_exp = np.zeros(n_qubits)
    for state_idx in range(2 ** n_qubits):
        bits = [int(b) for b in reversed(format(state_idx, f'0{n_qubits}b'))]
        for q in range(n_qubits):
            z_exp[q] += mitigated_probs[state_idx] * (1 - 2 * bits[q])
    return z_exp


if __name__ == "__main__":
    print("=" * 60)
    print("NOISE MITIGATION EXPERIMENTS")
    print("=" * 60)
    print(f"Noise: p1q={P1Q}, p2q={P2Q} (depolarizing)")

    noise_model = build_noise_model()
    ZNE_SCALES = [1, 3, 5]

    test_path = os.path.join(ROOT, CONFIG["data"]["processed_dir"], "test_features.csv")
    test_df = pd.read_csv(test_path, index_col=0)
    ENCODING_FEATURES = ["close_normalized", "rsi_14", "macd_signal", "bollinger_pct_b"]
    available_cols = [c for c in ENCODING_FEATURES if c in test_df.columns]
    X_test = test_df[available_cols].values
    rng = np.random.default_rng(RANDOM_SEED)
    idx = rng.choice(len(X_test), size=min(30, len(X_test)), replace=False)
    X_subset = X_test[idx]

    print(f"Test samples: {len(X_subset)}")
    print("\nBuilding calibration matrix...")
    cal_matrix = build_calibration_matrix(N_QUBITS, noise_model)
    print(f"  Calibration matrix: {cal_matrix.shape}")

    encoders = [
        (angle_encoding, "angle_encoding"),
        (angle_encoding_entangled, "angle_encoding_entangled"),
    ]

    all_records = []
    sim_noisy = AerSimulator(noise_model=noise_model)
    sim_ideal = AerSimulator()

    for enc_fn, enc_name in encoders:
        print(f"\nEncoding: {enc_name}")
        qc, params, _ = enc_fn(N_QUBITS)
        qc_meas = qc.copy()
        qc_meas.measure_all()

        for i, x in enumerate(tqdm(X_subset, desc=enc_name)):
            z_ideal_arr = ideal_z_expectation(x)
            # Build the BASE circuit (no measurements) and bind
            qc_base = bind_parameters(qc, params, x)
            # Build the measurement circuit separately
            qc_bound = qc_base.copy()
            qc_bound.measure_all()
            record = {
                "encoding": enc_name,
                "sample_idx": int(idx[i]),
                "x_values": x.tolist(),
            }

            # Ideal (no noise)
            qc_t = transpile(qc_bound, backend=sim_ideal, optimization_level=0)
            z_no_noise = z_expectation_from_counts(
                sim_ideal.run(qc_t, shots=SHOTS).result().get_counts(), N_QUBITS)
            record["fidelity_ideal"] = compute_fidelity(z_ideal_arr, z_no_noise)

            # Noisy, no mitigation
            qc_t = transpile(qc_bound, backend=sim_noisy, optimization_level=0)
            counts_noisy = sim_noisy.run(qc_t, shots=SHOTS).result().get_counts()
            z_noisy = z_expectation_from_counts(counts_noisy, N_QUBITS)
            record["fidelity_noisy"] = compute_fidelity(z_ideal_arr, z_noisy)

            # ZNE — fold the BASE circuit, then add measurements
            z_at_scales = []
            for sf in ZNE_SCALES:
                qc_folded_base = fold_gates(qc_base, sf)
                qc_folded_meas = qc_folded_base.copy()
                qc_folded_meas.measure_all()
                qc_t = transpile(qc_folded_meas, backend=sim_noisy, optimization_level=0)
                z_sf = z_expectation_from_counts(
                    sim_noisy.run(qc_t, shots=SHOTS).result().get_counts(), N_QUBITS)
                z_at_scales.append(z_sf)
            z_zne_linear = zne_linear_extrapolate(z_at_scales, ZNE_SCALES)
            record["fidelity_zne_linear"] = compute_fidelity(z_ideal_arr, z_zne_linear)

            # ZNE — Richardson
            z_zne_rich = zne_richardson_extrapolate(
                [z_at_scales[0], z_at_scales[1]], [1, 3])
            record["fidelity_zne_richardson"] = compute_fidelity(z_ideal_arr, z_zne_rich)

            # Measurement mitigation
            mit_probs = apply_measurement_mitigation(counts_noisy, cal_matrix, N_QUBITS)
            z_mit = mitigated_z_expectation(mit_probs, N_QUBITS)
            record["fidelity_meas_mitigated"] = compute_fidelity(z_ideal_arr, z_mit)

            all_records.append(record)

    results_df = pd.DataFrame(all_records)
    out_path = os.path.join(RESULTS_DIR, "mitigation_results.csv")
    results_df.to_csv(out_path, index=False)

    fid_cols = ["fidelity_ideal", "fidelity_noisy",
                "fidelity_zne_linear", "fidelity_zne_richardson",
                "fidelity_meas_mitigated"]
    summary = results_df.groupby("encoding")[fid_cols].mean().round(6)
    print("\nMean fidelity by mitigation method:")
    print(summary.to_string())

    summary.to_csv(os.path.join(RESULTS_DIR, "mitigation_summary.csv"))
    print(f"\nResults saved: {out_path}")
    print("\n" + "=" * 60)
    print("Noise mitigation COMPLETE.")
    print("=" * 60)
