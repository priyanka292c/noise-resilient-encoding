#!/usr/bin/env python3
"""
14_export_tables.py
===================
Exports all publication tables from simulations and datasets to:
- Standalone LaTeX (.tex) for inclusion or review
- Tabular CSV (.csv) for data archiving
- Markdown (.md) for web/GitHub display

Physical Review Applied manuscript:
"Noise-Resilient Quantum Circuits for Financial Indicator Encoding
 Under Realistic Device Noise"
"""

import os
import sys
import importlib.util

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
tables_script = os.path.join(ROOT, "python", "13_generate_tables.py")

spec = importlib.util.spec_from_file_location("generate_tables_mod", tables_script)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

if __name__ == "__main__":
    mod.generate_all_12_tables()
