#!/usr/bin/env python3
"""
14_export_results.py
====================
Phase 10 — Script 14: Comprehensive Results Aggregation and Export.

Consolidates all numerical records across ideal, noise sweep, mitigation,
and hardware-calibrated simulation phases into master JSON and CSV bundles.

Physical Review Applied manuscript:
"Noise Resilient Quantum Circuits for Financial Indicator Encoding
 and Hardware Aware Benchmarking"
"""

import os
import sys
import json
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS_DIR = os.path.join(ROOT, "results")

def export_master_results():
    print("=" * 65)
    print("MASTER RESULTS AGGREGATION AND EXPORT")
    print("=" * 65)

    files_to_bundle = {
        "ideal_simulation": "ideal_simulation_summary.csv",
        "noise_sweep": "noise_sweep_summary.csv",
        "noise_mitigation": "mitigation_summary.csv",
        "hardware_calibrated": "hardware_calibrated_summary.csv",
        "metrics_summary": "comprehensive_metrics_summary.csv",
        "circuit_resources": "circuit_resource_metrics.csv",
        "statistical_report": "statistical_inference_report.csv"
    }

    bundle = {}
    for key, fname in files_to_bundle.items():
        fpath = os.path.join(RESULTS_DIR, fname)
        if os.path.exists(fpath):
            df = pd.read_csv(fpath)
            bundle[key] = df.to_dict(orient="records")
            print(f"  [BUNDLED] {key} ({len(df)} records)")
        else:
            print(f"  [MISSING] {key} ({fpath})")

    out_json = os.path.join(RESULTS_DIR, "master_simulation_bundle.json")
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(bundle, f, indent=2)

    print(f"\n[OK] Master results bundle saved: {out_json}")
    print("=" * 65)

if __name__ == "__main__":
    export_master_results()
