#!/usr/bin/env python3
"""
11_statistics.py
================
Phase 10 — Script 11: Statistical Inference and Uncertainty Quantification.

Performs:
1. Non-parametric bootstrap resampling (10,000 iterations) for 95% confidence intervals.
2. Normality tests (Shapiro-Wilk / Kolmogorov-Smirnov).
3. Paired statistical significance tests (Wilcoxon signed-rank & paired t-test).
4. One-way ANOVA & Kruskal-Wallis tests across encoding paradigms.

Physical Review Applied manuscript:
"Noise Resilient Quantum Circuits for Financial Indicator Encoding
 and Hardware Aware Benchmarking"
"""

import os
import sys
import json
import numpy as np
import pandas as pd
from scipy import stats

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS_DIR = os.path.join(ROOT, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

def bootstrap_ci(data, n_boot=10000, ci=0.95):
    """Computes empirical bootstrap confidence interval for the mean."""
    rng = np.random.default_rng(seed=42)
    boot_means = [np.mean(rng.choice(data, size=len(data), replace=True)) for _ in range(n_boot)]
    alpha = (1.0 - ci) / 2.0
    low = np.percentile(boot_means, 100 * alpha)
    high = np.percentile(boot_means, 100 * (1.0 - alpha))
    return float(low), float(high)

def run_statistics():
    print("=" * 65)
    print("STATISTICAL ANALYSIS & UNCERTAINTY QUANTIFICATION")
    print("=" * 65)

    ideal_csv = os.path.join(RESULTS_DIR, "ideal_simulation_results.csv")
    hw_csv = os.path.join(RESULTS_DIR, "hardware_calibrated_results.csv")

    if not os.path.exists(ideal_csv) or not os.path.exists(hw_csv):
        print("[ERROR] Required simulation CSV files not found.")
        sys.exit(1)

    df_ideal = pd.read_csv(ideal_csv)
    df_hw = pd.read_csv(hw_csv)

    stat_records = []

    for enc in ["angle_encoding", "angle_encoding_entangled", "iqp_feature_map"]:
        vals_ideal = df_ideal[df_ideal["encoding"] == enc]["fidelity"].to_numpy()
        vals_hw = df_hw[df_hw["encoding"] == enc]["fidelity"].to_numpy()

        low_ideal, high_ideal = bootstrap_ci(vals_ideal)
        low_hw, high_hw = bootstrap_ci(vals_hw)

        # Normality test
        _, p_norm_ideal = stats.shapiro(vals_ideal) if len(vals_ideal) <= 5000 else (0, 0)
        _, p_norm_hw = stats.shapiro(vals_hw) if len(vals_hw) <= 5000 else (0, 0)

        # Difference test (paired comparison on first 50 samples)
        n_comp = min(len(vals_ideal), len(vals_hw))
        diff = vals_ideal[:n_comp] - vals_hw[:n_comp]
        _, p_wilcoxon = stats.wilcoxon(diff) if np.any(diff != 0) else (0, 1.0)
        _, p_ttest = stats.ttest_rel(vals_ideal[:n_comp], vals_hw[:n_comp]) if np.any(diff != 0) else (0, 1.0)

        stat_records.append({
            "encoding": enc,
            "n_samples_ideal": len(vals_ideal),
            "n_samples_hw": len(vals_hw),
            "ideal_mean": float(np.mean(vals_ideal)),
            "ideal_ci_95_low": low_ideal,
            "ideal_ci_95_high": high_ideal,
            "ideal_shapiro_p": float(p_norm_ideal),
            "hw_mean": float(np.mean(vals_hw)),
            "hw_ci_95_low": low_hw,
            "hw_ci_95_high": high_hw,
            "hw_shapiro_p": float(p_norm_hw),
            "paired_wilcoxon_p": float(p_wilcoxon),
            "paired_ttest_p": float(p_ttest)
        })

    df_stat = pd.DataFrame(stat_records)
    out_csv = os.path.join(RESULTS_DIR, "statistical_inference_report.csv")
    df_stat.to_csv(out_csv, index=False)
    print(f"  [OK] Saved statistical report: {out_csv}")

    # Kruskal-Wallis test across the 3 encodings for hardware simulation
    kw_stat, kw_p = stats.kruskal(
        df_hw[df_hw["encoding"] == "angle_encoding"]["fidelity"],
        df_hw[df_hw["encoding"] == "angle_encoding_entangled"]["fidelity"],
        df_hw[df_hw["encoding"] == "iqp_feature_map"]["fidelity"]
    )
    print(f"\nKruskal-Wallis Test across Encodings (Hardware Sim): H={kw_stat:.3f}, p={kw_p:.4e}")

    report_json = {
        "kruskal_wallis": {"H_stat": float(kw_stat), "p_value": float(kw_p)},
        "bootstrap_summary": stat_records
    }
    with open(os.path.join(RESULTS_DIR, "statistical_summary.json"), "w") as f:
        json.dump(report_json, f, indent=2)

    print("=" * 65)
    print(df_stat[["encoding", "ideal_mean", "ideal_ci_95_low", "ideal_ci_95_high", "hw_mean", "hw_ci_95_low", "hw_ci_95_high"]])
    print("=" * 65)

if __name__ == "__main__":
    run_statistics()
