"""
encoding_utils.py
=================
Shared utilities for quantum encoding circuits.
Used by: 04_quantum_encoding.py, 05_ideal_simulation.py,
         06_noise_models.py, 07_noise_mitigation.py,
         08_hardware_calibrated_simulation.py, 10_metrics.py

Physical Review Applied manuscript:
"Noise Resilient Quantum Circuits for Financial Indicator Encoding
and Hardware Aware Benchmarking"
"""

import numpy as np
from qiskit import QuantumCircuit
from qiskit.circuit import ParameterVector


def count_gates(qc: QuantumCircuit) -> dict:
    """Count single-qubit, two-qubit, and total gates in a circuit."""
    single_qubit = 0
    two_qubit = 0
    total = 0
    for instruction in qc.data:
        n = len(instruction.qubits)
        total += 1
        if n == 1:
            single_qubit += 1
        elif n == 2:
            two_qubit += 1
    return {
        "total_gates": total,
        "single_qubit_gates": single_qubit,
        "two_qubit_gates": two_qubit,
        "circuit_depth": qc.depth(),
        "num_qubits": qc.num_qubits,
        "num_parameters": qc.num_parameters,
    }


def angle_encoding(n_qubits: int = 4) -> tuple:
    """
    Angle encoding: Rx(pi*x_i) on each qubit.

    Physical motivation:
        For x_i in [0, 1], the rotation angle theta_i = pi * x_i in [0, pi]
        maps the Bloch sphere z-component as <Z_i> = cos(pi * x_i).
        This provides a differentiable, invertible mapping from features to
        quantum state parameters, making it suitable for benchmarking
        information preservation under noise.

    Returns:
        (QuantumCircuit, ParameterVector, metadata_dict)
    """
    params = ParameterVector("x", n_qubits)
    qc = QuantumCircuit(n_qubits, name="angle_encoding")
    for i in range(n_qubits):
        qc.rx(np.pi * params[i], i)
    meta = count_gates(qc)
    meta.update({
        "name": "angle_encoding",
        "description": "Rx(pi*x_i) on each qubit — no entanglement",
        "connectivity": "none (single-qubit only)",
    })
    return qc, params, meta


def angle_encoding_entangled(n_qubits: int = 4) -> tuple:
    """
    Angle encoding with linear CNOT entanglement.

    Layer 1: Rx(pi*x_i) on each qubit
    Layer 2: Linear CNOT chain CX(0,1), CX(1,2), ..., CX(n-2, n-1)
    Layer 3: Rx(pi*x_i) on each qubit (re-encoding after entanglement)

    Returns:
        (QuantumCircuit, ParameterVector, metadata_dict)
    """
    params = ParameterVector("x", n_qubits)
    qc = QuantumCircuit(n_qubits, name="angle_encoding_entangled")
    for i in range(n_qubits):
        qc.rx(np.pi * params[i], i)
    for i in range(n_qubits - 1):
        qc.cx(i, i + 1)
    for i in range(n_qubits):
        qc.rx(np.pi * params[i], i)
    meta = count_gates(qc)
    meta.update({
        "name": "angle_encoding_entangled",
        "description": "Two Rx layers with linear CNOT chain",
        "connectivity": "linear: CX(0,1), CX(1,2), CX(2,3)",
    })
    return qc, params, meta


def iqp_feature_map(n_qubits: int = 4) -> tuple:
    """
    IQP-style feature map with Hadamard, Rz, and RZZ layers.

    Structure:
        H^n → Rz(2x_i) → RZZ(2x_i x_j) for pairs → H^n → Rz(2x_i)

    The RZZ term: exp(-i x_i x_j Z⊗Z)
        = CX · Rz(2 x_i x_j) · CX

    This introduces nonlinear feature correlations.

    Returns:
        (QuantumCircuit, ParameterVector, metadata_dict)
    """
    params = ParameterVector("x", n_qubits)
    qc = QuantumCircuit(n_qubits, name="iqp_feature_map")

    def rzz_gate(qc, theta, q0, q1):
        qc.cx(q0, q1)
        qc.rz(2 * theta, q1)
        qc.cx(q0, q1)

    qc.h(range(n_qubits))
    for i in range(n_qubits):
        qc.rz(2 * params[i], i)
    for i in range(n_qubits - 1):
        rzz_gate(qc, params[i] * params[i + 1], i, i + 1)
    qc.h(range(n_qubits))
    for i in range(n_qubits):
        qc.rz(2 * params[i], i)

    meta = count_gates(qc)
    meta.update({
        "name": "iqp_feature_map",
        "description": "IQP-style: H + Rz + RZZ (ZZ interactions) + H + Rz",
        "connectivity": "linear pairs only",
        "nonlinear": True,
    })
    return qc, params, meta


def build_measurement_circuit(qc: QuantumCircuit) -> QuantumCircuit:
    """Add measurements to a circuit."""
    qc_m = qc.copy()
    qc_m.measure_all()
    return qc_m


def bind_parameters(qc: QuantumCircuit,
                    params: ParameterVector,
                    x_values: np.ndarray) -> QuantumCircuit:
    """Bind a ParameterVector to numeric values."""
    param_dict = {params[i]: float(x_values[i]) for i in range(len(x_values))}
    return qc.assign_parameters(param_dict)


def z_expectation_from_counts(counts: dict, n_qubits: int) -> np.ndarray:
    """
    Compute <Z_i> = P(0_i) - P(1_i) for each qubit from measurement counts.

    Qiskit bit order: rightmost character in bitstring = qubit 0.

    Returns:
        numpy array of shape (n_qubits,)
    """
    z_exp = np.zeros(n_qubits)
    total = sum(counts.values())
    for bitstring, count in counts.items():
        # Reverse: bitstring[-1] is qubit 0
        bits = [int(b) for b in reversed(bitstring)]
        for i, b in enumerate(bits[:n_qubits]):
            z_exp[i] += count * (1 - 2 * b)  # +1 → |0>, -1 → |1>
    return z_exp / total


def ideal_z_expectation(x_values: np.ndarray) -> np.ndarray:
    """
    Compute ideal <Z_i> = cos(pi * x_i) for angle encoding.

    This is the analytical result for Rx(pi * x)|0> state:
        <Z> = <0|Rx†(theta) Z Rx(theta)|0> = cos(theta) = cos(pi * x)

    Args:
        x_values: Feature vector, x_i in [0, 1]

    Returns:
        numpy array of shape (len(x_values),)
    """
    return np.cos(np.pi * np.array(x_values))


def circuit_z_expectations(qc_no_meas: QuantumCircuit, n_qubits: int = 4) -> np.ndarray:
    """
    Compute exact statevector Z-basis expectation values <Z_i> for an arbitrary circuit:
    <Z_i> = <psi | Z_i | psi>

    Handles Qiskit's right-to-left Pauli indexing convention correctly:
    qubit i corresponds to character index (n_qubits - 1 - i).

    Args:
        qc_no_meas: Parameter-bound QuantumCircuit without measurement gates.
        n_qubits: Number of qubits.

    Returns:
        numpy array of shape (n_qubits,) with values in [-1, +1].
    """
    from qiskit.quantum_info import Statevector, Pauli
    psi = Statevector(qc_no_meas)
    z_exp = np.zeros(n_qubits)
    for i in range(n_qubits):
        p_chars = ['I'] * n_qubits
        p_chars[n_qubits - 1 - i] = 'Z'
        z_exp[i] = psi.expectation_value(Pauli(''.join(p_chars))).real
    return z_exp



def compute_observable_agreement(z_ideal: np.ndarray, z_noisy: np.ndarray) -> float:
    """
    Compute normalized single-qubit Z-expectation agreement score:
    S_Z = 1 - (1 / 4n) * sum_i (<Z_i>_ideal - <Z_i>_noisy)^2

    NOTE: This metric quantifies marginal single-qubit Z-basis expectation agreement.
    It is NOT the Uhlmann quantum state fidelity F_Q.
    """
    mse = float(np.mean((np.array(z_ideal) - np.array(z_noisy)) ** 2))
    return float(np.clip(1.0 - mse / 4.0, 0.0, 1.0))


def compute_observable_distortion(z_ideal: np.ndarray, z_noisy: np.ndarray) -> float:
    """
    Compute mean absolute observable distortion:
    Delta_Z = (1 / n) * sum_i |<Z_i>_ideal - <Z_i>_noisy|
    """
    return float(np.mean(np.abs(np.array(z_ideal) - np.array(z_noisy))))


def compute_fidelity(z_ideal: np.ndarray, z_noisy: np.ndarray) -> float:
    """Legacy alias for compute_observable_agreement (S_Z)."""
    return compute_observable_agreement(z_ideal, z_noisy)


def compute_true_state_fidelity(qc_bound: QuantumCircuit, noise_model=None) -> float:
    """
    Compute genuine Uhlmann quantum state fidelity:
    F_Q(rho_ideal, rho_noisy) = <psi_ideal| rho_noisy |psi_ideal>

    For pure ideal states and open-system mixed states generated under CPTP
    Lindblad/Kraus noise channels via Qiskit-Aer density_matrix simulation.

    Args:
        qc_bound: Parameter-bound QuantumCircuit without measurement gates.
        noise_model: Qiskit-Aer NoiseModel instance (or None for ideal).

    Returns:
        F_Q in [0, 1]
    """
    from qiskit.quantum_info import Statevector, state_fidelity
    from qiskit_aer import AerSimulator

    # Remove any measurement operations to obtain pre-measurement state
    qc_no_meas = qc_bound.copy()
    qc_no_meas.remove_final_measurements(inplace=True)

    psi_ideal = Statevector(qc_no_meas)

    if noise_model is None:
        return 1.0

    # Simulate mixed state under noise using density matrix method
    sim_dm = AerSimulator(method='density_matrix', noise_model=noise_model)
    qc_dm = qc_no_meas.copy()
    qc_dm.save_density_matrix()

    result = sim_dm.run(qc_dm).result()
    rho_noisy = result.data(0)['density_matrix']

    f_true = float(state_fidelity(psi_ideal, rho_noisy))
    return float(np.clip(f_true, 0.0, 1.0))


def feature_reconstruction_error(x_true: np.ndarray,
                                 z_measured: np.ndarray,
                                 encoding_name: str = "angle_encoding") -> float:
    """
    Feature reconstruction error: how well can we recover x_i from <Z_i>?

    For separable Angle Encoding:
        x_hat_i = arccos(<Z_i>) / pi
        Error = MSE(x_true, x_hat)

    For non-separable entangling encodings (AEE, IQP):
        Single-qubit marginals <Z_i> do not uniquely invert the multi-qubit
        entangled quantum state. Inversion requires full quantum state
        tomography or a trained nonlinear decoder.

    Args:
        x_true: True input features, shape (n,)
        z_measured: Measured Z-expectations, shape (n,)
        encoding_name: Name of encoding strategy

    Returns:
        MSE of reconstruction if invertible; NaN if non-invertible from single-qubit marginals.
    """
    if encoding_name != "angle_encoding":
        return float(np.nan)

    z_clipped = np.clip(z_measured, -1.0 + 1e-7, 1.0 - 1e-7)
    x_hat = np.arccos(z_clipped) / np.pi
    return float(np.mean((np.array(x_true) - x_hat) ** 2))

