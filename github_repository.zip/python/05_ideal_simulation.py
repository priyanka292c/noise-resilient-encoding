#!/usr/bin/env python3
"""
05_ideal_simulation.py
=======================
Phase 10 — Script 5: Ideal (noise-free) simulation.

Simulates all encoding circuits under ideal conditions:
- No noise
- Statevector simulator (exact)
- Computes Z-expectation values and compares to analytical values

Also performs systematic comparison across the test dataset.

Physical Review Applied manuscript:
"Noise Resilient Quantum Circuits for Financial Indicator Encoding
and Hardware Aware Benchmarking"
"""

import os
import sys
import json
import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

import yaml
with open(os.path.join(ROOT, "config.yaml"), "r") as f:
    CONFIG = yaml.safe_load(f)

RANDOM_SEED = CONFIG["random_seed"]
np.random.seed(RANDOM_SEED)

RESULTS_DIR = os.path.join(ROOT, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

# Qiskit imports
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit_aer.library import SaveStatevector

# Local utilities
sys.path.insert(0, os.path.join(ROOT, "python"))
from encoding_utils import (
    angle_encoding, angle_encoding_entangled, iqp_feature_map,
    bind_parameters, z_expectation_from_counts,
    ideal_z_expectation, compute_fidelity, feature_reconstruction_error,
)

SHOTS = CONFIG["shots"]["ideal"]
N_QUBITS = 4

print("=" * 60)
print("IDEAL SIMULATION")
print("=" * 60)

# Load test data
test_path = os.path.join(ROOT, CONFIG["data"]["processed_dir"], "test_features.csv")
test_df = pd.read_csv(test_path, index_col=0)
ENCODING_FEATURES = CONFIG["data"]["encoding_features"] if "encoding_features" in CONFIG.get("data", {}) else [
    "close_normalized", "rsi_14", "macd_signal", "bollinger_pct_b"
]
# Use the 4 encoding features
available_cols = [c for c in ENCODING_FEATURES if c in test_df.columns]
if len(available_cols) < 4:
    available_cols = test_df.columns[:4].tolist()
X_test = test_df[available_cols].values
print(f"Test samples: {len(X_test)}, Features: {available_cols}")

# Simulator (statevector for ideal)
sim_statevector = AerSimulator(method='statevector')
sim_shots = AerSimulator(method='automatic')

# ============================================================
# Ideal verification: compare simulator vs analytical
# ============================================================

print("\n--- Analytical vs Simulator Verification (Angle Encoding) ---")
x_sample = X_test[0]
print(f"Sample features: {x_sample.round(4)}")

# Analytical result
z_analytical = ideal_z_expectation(x_sample)
print(f"Analytical <Z>:  {z_analytical.round(6)}")

# Simulator result (shot-based)
qc, params, _ = angle_encoding(N_QUBITS)
qc_meas = qc.copy()
qc_meas.measure_all()
qc_bound = bind_parameters(qc_meas, params, x_sample)
qc_t = transpile(qc_bound, backend=sim_shots, optimization_level=0)
counts = sim_shots.run(qc_t, shots=SHOTS).result().get_counts()
z_simulated = z_expectation_from_counts(counts, N_QUBITS)
print(f"Simulator <Z>:   {z_simulated.round(6)}")
print(f"Max deviation:   {np.max(np.abs(z_analytical - z_simulated)):.6f}")
print(f"(Expected ~ 1/sqrt(shots) = {1/np.sqrt(SHOTS):.5f})")

# ============================================================
# Systematic evaluation over test set
# ============================================================

encoders = [
    (angle_encoding, "angle_encoding"),
    (angle_encoding_entangled, "angle_encoding_entangled"),
    (iqp_feature_map, "iqp_feature_map"),
]

all_records = []
# Use a subset for speed (100 random samples from test set)
rng = np.random.default_rng(RANDOM_SEED)
idx = rng.choice(len(X_test), size=min(100, len(X_test)), replace=False)
X_subset = X_test[idx]

for enc_fn, enc_name in encoders:
    print(f"\nEvaluating: {enc_name} on {len(X_subset)} samples...")
    qc, params, meta = enc_fn(N_QUBITS)
    qc_meas = qc.copy()
    qc_meas.measure_all()

    fidelities = []
    recon_errors = []

    for x in X_subset:
        qc_bound = bind_parameters(qc_meas, params, x)
        qc_t = transpile(qc_bound, backend=sim_shots, optimization_level=0)
        counts = sim_shots.run(qc_t, shots=SHOTS).result().get_counts()
        z_sim = z_expectation_from_counts(counts, N_QUBITS)

        # For angle encoding: analytical baseline
        z_ideal = ideal_z_expectation(x)
        fid = compute_fidelity(z_ideal, z_sim)
        fidelities.append(fid)

        # Feature reconstruction error (angle encoding inverse)
        rec_err = feature_reconstruction_error(x, z_sim)
        recon_errors.append(rec_err)

        all_records.append({
            "encoding": enc_name,
            "sample_idx": int(idx[len(fidelities) - 1]),
            "x_values": x.tolist(),
            "z_ideal": z_ideal.tolist(),
            "z_simulated": z_sim.tolist(),
            "fidelity": fid,
            "reconstruction_error": rec_err,
            "noise_type": "none",
            "noise_parameter": 0.0,
        })

    mean_fid = np.mean(fidelities)
    std_fid = np.std(fidelities)
    mean_rec = np.mean(recon_errors)
    print(f"  Mean fidelity: {mean_fid:.6f} ± {std_fid:.6f}")
    print(f"  Mean reconstruction error: {mean_rec:.8f}")
    print(f"  (Shot noise baseline ~ {1/SHOTS:.8f})")

# Save results
results_df = pd.DataFrame(all_records)
results_path = os.path.join(RESULTS_DIR, "ideal_simulation_results.csv")
results_df.to_csv(results_path, index=False)
print(f"\nIdeal simulation results saved: {results_path}")
print(f"Total records: {len(results_df)}")

# Save summary
summary = results_df.groupby("encoding")[["fidelity", "reconstruction_error"]].agg(["mean", "std", "min", "max"]).round(8)
summary_path = os.path.join(RESULTS_DIR, "ideal_simulation_summary.csv")
summary.to_csv(summary_path)
print(f"Summary saved: {summary_path}")

print("\nIdeal simulation summary:")
print(summary.to_string())

print("\n" + "=" * 60)
print("Ideal simulation COMPLETE.")
print("=" * 60)
