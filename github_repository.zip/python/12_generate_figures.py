#!/usr/bin/env python3
"""
12_generate_figures.py
=======================
Phase 10 — Script 12: Generate all publication-quality figures.

Generates figures for the Physical Review Applied manuscript:
"Noise-Resilient Quantum Circuits for Financial Indicator Encoding Under Realistic Device Noise"

All figures use colorblind-safe palettes and are exported as:
  PNG (300 dpi), JPEG (300 dpi), PDF (vector), EPS (vector)
"""

import os
import sys
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # non-interactive backend
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyArrowPatch
import warnings
warnings.filterwarnings('ignore')

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

import yaml
with open(os.path.join(ROOT, "config.yaml"), "r") as f:
    CONFIG = yaml.safe_load(f)

RESULTS_DIR = os.path.join(ROOT, "results")
FIG_DIR_PNG = os.path.join(ROOT, "figures", "png")
FIG_DIR_JPG = os.path.join(ROOT, "figures", "jpg")
FIG_DIR_PDF = os.path.join(ROOT, "figures", "pdf")
FIG_DIR_EPS = os.path.join(ROOT, "figures", "eps")
for d in [FIG_DIR_PNG, FIG_DIR_JPG, FIG_DIR_PDF, FIG_DIR_EPS]:
    os.makedirs(d, exist_ok=True)

DPI = CONFIG["figures"]["dpi"]
COLORS = CONFIG["figures"]["colors"]

# Matplotlib global settings for publication quality (PRApplied standard)
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['DejaVu Serif', 'Times New Roman', 'Times'],
    'font.size': 11,
    'axes.labelsize': 12,
    'axes.titlesize': 13,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 10,
    'figure.dpi': DPI,
    'savefig.dpi': DPI,
    'text.usetex': False,  # Math rendering via matplotlib mathtext
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.grid': True,
    'grid.alpha': 0.3,
    'lines.linewidth': 1.8,
    'axes.prop_cycle': plt.cycler('color', [
        COLORS['ideal'], COLORS['depolarizing'], COLORS['bit_flip'],
        COLORS['phase_flip'], COLORS['amplitude_damping'],
        COLORS['phase_damping'], COLORS['thermal'], COLORS['mitigated'],
    ]),
})


def save_figure(fig, name: str, tight=True):
    """Save figure in all required formats."""
    if tight:
        fig.tight_layout()
    for fmt, directory in [('png', FIG_DIR_PNG), ('jpg', FIG_DIR_JPG),
                           ('pdf', FIG_DIR_PDF), ('eps', FIG_DIR_EPS)]:
        path = os.path.join(directory, f"{name}.{fmt}")
        try:
            kwargs = {'dpi': DPI, 'bbox_inches': 'tight', 'pad_inches': 0.05}
            if fmt in ['pdf', 'eps']:
                kwargs.pop('dpi', None)
            fig.savefig(path, format=fmt, **kwargs)
        except Exception as e:
            print(f"  [WARN] Could not save {fmt}: {e}")
    print(f"  Saved: {name} (PNG/JPG/PDF/EPS)")
    plt.close(fig)


# ============================================================
# FIGURE 1: Scientific pipeline workflow (6 panels: a-f)
# ============================================================

def fig1_workflow():
    """Figure 1: End-to-end scientific methodology and computational pipeline (6 panels: a-f)."""
    fig = plt.figure(figsize=(16, 9.2))
    gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.34, wspace=0.32, top=0.95, bottom=0.08, left=0.07, right=0.97)

    # -------------------------------------------------------------
    # Panel (a): Daily Empirical Market Ingestion (SPY 2015-2023)
    # -------------------------------------------------------------
    ax_a = fig.add_subplot(gs[0, 0])
    raw_csv = os.path.join(ROOT, "data", "raw", "SPY_raw_2015-01-01_2023-12-31.csv")
    if os.path.exists(raw_csv):
        df_raw = pd.read_csv(raw_csv)
        df_raw['Date'] = pd.to_datetime(df_raw['Date'])
        df_raw = df_raw.sort_values('Date').reset_index(drop=True)
        
        split_date = pd.to_datetime('2022-01-01')
        train_mask = df_raw['Date'] < split_date
        test_mask = df_raw['Date'] >= split_date
        
        ax_a.plot(df_raw.loc[train_mask, 'Date'], df_raw.loc[train_mask, 'Close'],
                  color='#1B365D', lw=1.5, label='In-sample (2015–2021)')
        ax_a.plot(df_raw.loc[test_mask, 'Date'], df_raw.loc[test_mask, 'Close'],
                  color='#D9534F', lw=1.5, label='Out-of-sample (2022–2023)')
        ax_a.axvline(split_date, color='#555555', linestyle='--', lw=1.2, alpha=0.8)
        ax_a.text(split_date + pd.Timedelta(days=40), 170, 'Split', color='#444444', fontsize=8.5, fontweight='bold')
        
        years = [pd.to_datetime(f"{y}-01-01") for y in [2015, 2017, 2019, 2021, 2023]]
        ax_a.set_xticks(years)
        ax_a.set_xticklabels(['2015', '2017', '2019', '2021', '2023'])
        ax_a.set_ylabel("Adjusted Close ($)")
        ax_a.set_xlabel("Calendar Year")
        ax_a.set_ylim(140, 500)
        ax_a.legend(loc='upper left', framealpha=0.9, fontsize=8)
    ax_a.set_title("(a) SPY Market Ingestion (2015–2023)", loc='left', fontweight='bold', fontsize=11)

    # -------------------------------------------------------------
    # Panel (b): Causal Technical Indicator Engineering & Normalization
    # -------------------------------------------------------------
    ax_b = fig.add_subplot(gs[0, 1])
    feat_csv = os.path.join(ROOT, "data", "processed", "all_features.csv")
    if os.path.exists(feat_csv):
        df_feat = pd.read_csv(feat_csv)
        features_to_plot = [
            ('log_return_1d', 'Log Return ($x_0$)', '#4477AA'),
            ('rsi_14', 'RSI 14d ($x_1$)', '#228833'),
            ('macd_signal', 'MACD Signal ($x_2$)', '#CCBB44'),
            ('historical_volatility_20d', 'Volatility 20d ($x_3$)', '#EE6677'),
        ]
        for col, lbl, clr in features_to_plot:
            if col in df_feat.columns:
                vals = df_feat[col].dropna().values
                counts, bin_edges = np.histogram(vals, bins=45, density=True, range=(0, 1))
                bin_centers = 0.5 * (bin_edges[:-1] + bin_edges[1:])
                ax_b.plot(bin_centers, counts, label=lbl, color=clr, lw=1.8)
                ax_b.fill_between(bin_centers, counts, alpha=0.15, color=clr)
        ax_b.set_xlim(0, 1)
        ax_b.set_ylim(0, 7.5)
        ax_b.set_xlabel("Normalized Feature $x_i \\in [0, 1]$")
        ax_b.set_ylabel("Empirical Probability Density")
        ax_b.legend(loc='upper right', framealpha=0.9, fontsize=8)
    ax_b.set_title("(b) Causal Feature Normalization", loc='left', fontweight='bold', fontsize=11)

    # -------------------------------------------------------------
    # Panel (c): Quantum Register Encoding (4 Qubits: AE, AEE, IQP)
    # -------------------------------------------------------------
    ax_c = fig.add_subplot(gs[0, 2])
    ax_c.set_xlim(0, 10.5)
    ax_c.set_ylim(-0.6, 4.4)
    ax_c.axis('off')

    qubit_labels = [r"$|0\rangle_{q0}$", r"$|0\rangle_{q1}$", r"$|0\rangle_{q2}$", r"$|0\rangle_{q3}$"]
    for i, qlbl in enumerate(qubit_labels):
        y = 3 - i
        ax_c.plot([0.9, 10.1], [y, y], color='#666666', lw=1.2, zorder=1)
        ax_c.text(0.75, y, qlbl, va='center', ha='right', fontsize=9.5, family='monospace')

    # Paradigm 1: AE (Depth 1, 1Q rotations)
    rect_ae = matplotlib.patches.FancyBboxPatch((1.4, -0.4), 2.2, 4.0, boxstyle="round,pad=0.08",
                                                facecolor='#EBF3FA', edgecolor='#4477AA', lw=1.5, zorder=2)
    ax_c.add_patch(rect_ae)
    ax_c.text(2.5, 3.85, "AE ($d=1, 0\\text{CX}$)", ha='center', fontsize=8, fontweight='bold', color='#1B365D')
    for i in range(4):
        y = 3 - i
        ax_c.add_patch(matplotlib.patches.Rectangle((1.7, y - 0.28), 1.6, 0.56, facecolor='#4477AA', edgecolor='#1B365D', zorder=3))
        ax_c.text(2.5, y, f"$R_x(\\pi x_{i})$", color='white', va='center', ha='center', fontsize=7.8)

    # Paradigm 2: AEE (Depth 5, Linear Entanglement)
    rect_aee = matplotlib.patches.FancyBboxPatch((4.3, -0.4), 2.6, 4.0, boxstyle="round,pad=0.08",
                                                 facecolor='#FDF2F2', edgecolor='#EE6677', lw=1.5, zorder=2)
    ax_c.add_patch(rect_aee)
    ax_c.text(5.6, 3.85, "AEE ($d=5, 3\\text{CX}$)", ha='center', fontsize=8, fontweight='bold', color='#990000')
    for j in range(3):
        ctrl_y = 3 - j
        tgt_y = 2 - j
        cx_x = 4.85 + j * 0.55
        ax_c.plot([cx_x, cx_x], [ctrl_y, tgt_y], color='#EE6677', lw=1.8, zorder=3)
        ax_c.scatter([cx_x], [ctrl_y], color='#EE6677', s=35, zorder=4)
        ax_c.scatter([cx_x], [tgt_y], color='white', edgecolors='#EE6677', s=55, lw=1.5, zorder=4)
        ax_c.text(cx_x, tgt_y, "+", color='#EE6677', va='center', ha='center', fontsize=9, fontweight='bold', zorder=5)

    # Paradigm 3: IQP (Depth 13, Quadratic Feature Interactions)
    rect_iqp = matplotlib.patches.FancyBboxPatch((7.6, -0.4), 2.4, 4.0, boxstyle="round,pad=0.08",
                                                 facecolor='#F0F9F0', edgecolor='#228833', lw=1.5, zorder=2)
    ax_c.add_patch(rect_iqp)
    ax_c.text(8.8, 3.85, "IQP ($d=13, 6\\text{CX}$)", ha='center', fontsize=8, fontweight='bold', color='#115522')
    ax_c.text(8.8, 1.5, "$H^{\\otimes 4} \\cdot U_{Z,ZZ}(\\vec{x})$\nAll-to-all pairs",
              ha='center', va='center', fontsize=8, color='#115522', multialignment='center')

    ax_c.set_title("(c) 4-Qubit Circuit Compilations", loc='left', fontweight='bold', fontsize=11)

    # -------------------------------------------------------------
    # Panel (d): Open Quantum System Noise Modeling (Transmon)
    # -------------------------------------------------------------
    ax_d = fig.add_subplot(gs[1, 0])
    t_us = np.linspace(0, 300, 200)
    T1 = 156.4  # us
    T2 = 118.2  # us
    decay_T1 = np.exp(-t_us / T1)
    decay_T2 = np.exp(-t_us / T2)

    ax_d.plot(t_us, decay_T1, color='#4477AA', lw=2, label=f'Relaxation ($T_1 = {T1:.1f}\\,\\mu$s)')
    ax_d.plot(t_us, decay_T2, color='#EE6677', lw=2, linestyle='--', label=f'Dephasing ($T_2 = {T2:.1f}\\,\\mu$s)')

    ax_d.text(18, 0.46, "Transmon Parameters:\n$\\bullet$ 1Q: $\\tau_{1Q}=35\\,$ns ($p_{1Q}=0.02\\%$)\n$\\bullet$ 2Q: $\\tau_{2Q}=300\\,$ns ($p_{2Q}=0.81\\%$)\n$\\bullet$ Readout: $p_{\\mathrm{meas}}=1.72\\%$",
              bbox=dict(boxstyle='round,pad=0.4', facecolor='#F8F9FA', edgecolor='#D0D5DD', alpha=0.92),
              fontsize=8, linespacing=1.35)
    ax_d.set_xlabel("Elapsed Time ($\\mu$s)")
    ax_d.set_ylabel("Coherence Envelope")
    ax_d.set_ylim(0, 1.05)
    ax_d.legend(loc='upper right', framealpha=0.9, fontsize=8)
    ax_d.set_title("(d) Transmon Device Noise Channels", loc='left', fontweight='bold', fontsize=11)

    # -------------------------------------------------------------
    # Panel (e): Dual Error Mitigation (ZNE + MEM)
    # -------------------------------------------------------------
    ax_e = fig.add_subplot(gs[1, 1])
    scale_factors = np.array([1.0, 2.0, 3.0])
    zne_vals = np.array([0.942, 0.891, 0.838])
    poly_fit = np.polyfit(scale_factors, zne_vals, 1)
    x_extrap = np.linspace(0, 3.2, 50)
    y_extrap = np.polyval(poly_fit, x_extrap)

    ax_e.scatter(scale_factors, zne_vals, color='#EE6677', s=55, zorder=4, label='Noise-scaled $\\lambda \\in \\{1,2,3\\}$')
    ax_e.plot(x_extrap, y_extrap, color='#777777', linestyle='--', lw=1.3, label='Linear fit')
    ax_e.scatter([0], [poly_fit[1]], color='#228833', s=90, marker='*', zorder=5, label=f'ZNE: {poly_fit[1]:.3f}')

    ax_e.annotate(f"$\\lambda \\to 0$\nZero-Noise Limit", xy=(0, poly_fit[1]), xytext=(0.25, 0.965),
                 arrowprops=dict(arrowstyle="->", color='#228833', lw=1.3),
                 fontsize=8.2, color='#115522', fontweight='bold')

    ax_inset = ax_e.inset_axes([0.62, 0.12, 0.35, 0.38])
    M = np.array([[0.983, 0.017], [0.019, 0.981]])
    ax_inset.imshow(M, cmap='Blues', vmin=0, vmax=1)
    ax_inset.set_xticks([0, 1])
    ax_inset.set_yticks([0, 1])
    ax_inset.set_xticklabels(['|0⟩', '|1⟩'], fontsize=7)
    ax_inset.set_yticklabels(['|0⟩', '|1⟩'], fontsize=7)
    for ii in range(2):
        for jj in range(2):
            ax_inset.text(jj, ii, f"{M[ii,jj]:.3f}", ha='center', va='center', fontsize=6.5,
                          color='white' if M[ii,jj] > 0.5 else 'black')
    ax_inset.set_title("MEM: $M^{-1}\\vec{p}$", fontsize=7.5, pad=2)

    ax_e.set_xlabel("Noise Scale Factor $\\lambda$")
    ax_e.set_ylabel("Observable Expectation $\\langle Z_i \\rangle$")
    ax_e.set_xlim(-0.2, 3.3)
    ax_e.set_ylim(0.80, 1.02)
    ax_e.legend(loc='lower left', framealpha=0.9, fontsize=8)
    ax_e.set_title("(e) Error Mitigation: ZNE & MEM", loc='left', fontweight='bold', fontsize=11)

    # -------------------------------------------------------------
    # Panel (f): Multi-Metric Verification (FQ vs SZ vs Delta Z)
    # -------------------------------------------------------------
    ax_f = fig.add_subplot(gs[1, 2])
    encodings = ['AE\n(d=1, 0CX)', 'AEE\n(d=5, 3CX)', 'IQP\n(d=13, 6CX)']
    x_pos = np.arange(len(encodings))
    bar_w = 0.34

    f_q = [0.9989, 0.9609, 0.9257]
    s_z = [0.99998, 0.99983, 0.99991]

    bars_fq = ax_f.bar(x_pos - bar_w/2, f_q, width=bar_w, color='#4477AA', label='Genuine State Fidelity $F_Q$', edgecolor='#1B365D')
    bars_sz = ax_f.bar(x_pos + bar_w/2, s_z, width=bar_w, color='#CCBB44', label='Marginal Agreement $S_Z$', edgecolor='#998811')

    for bar in bars_fq:
        h = bar.get_height()
        ax_f.text(bar.get_x() + bar.get_width()/2., h - 0.035, f"{h:.3f}",
                  ha='center', va='top', fontsize=8, color='white', fontweight='bold')
    for bar in bars_sz:
        h = bar.get_height()
        ax_f.text(bar.get_x() + bar.get_width()/2., h - 0.035, f"{h:.4f}",
                  ha='center', va='top', fontsize=7.2, color='#333333', fontweight='bold', rotation=90)

    ax_f.set_xticks(x_pos)
    ax_f.set_xticklabels(encodings)
    ax_f.set_ylabel("Preservation Metric Value")
    ax_f.set_ylim(0.88, 1.02)
    ax_f.axhline(1.0, color='gray', linestyle=':', alpha=0.5)

    ax_f.annotate("Metric Divergence:\n$S_Z$ masks multi-qubit\nphase corruption!",
                  xy=(1 + bar_w/2, 0.9998), xytext=(0.42, 0.902),
                  arrowprops=dict(arrowstyle="->", color='#EE6677', lw=1.5),
                  fontsize=7.8, color='#990000', fontweight='bold',
                  bbox=dict(boxstyle='round,pad=0.25', facecolor='#FDF2E9', edgecolor='#E67E22', alpha=0.92))

    ax_f.legend(loc='lower left', framealpha=0.9, fontsize=8)
    ax_f.set_title("(f) Multi-Metric Gap: $F_Q$ vs. $S_Z$", loc='left', fontweight='bold', fontsize=11)

    save_figure(fig, "fig01_workflow", tight=False)


# ============================================================
# FIGURE 2: Quantum circuit architectures
# ============================================================

def fig2_circuit_architectures():
    """Figure 2: Schematic architecture of the three quantum encoding circuits."""
    fig, axes = plt.subplots(3, 1, figsize=(10, 8))

    # Panel a: Angle Encoding
    ax = axes[0]
    ax.set_xlim(0, 8)
    ax.set_ylim(-0.5, 3.5)
    for q in range(4):
        ax.plot([0.5, 7.5], [q, q], color='#444444', lw=1.5)
        ax.text(0.1, q, f"|0⟩ q_{q}", va='center', ha='right', fontsize=10, family='monospace')
        rect = plt.Rectangle((2.5, q - 0.35), 2.5, 0.7, facecolor='#4477AA', edgecolor='#1B365D', lw=1.5, zorder=3)
        ax.add_patch(rect)
        ax.text(3.75, q, f"Rx(π x_{q})", color='white', va='center', ha='center', fontweight='bold', fontsize=9.5)
    ax.set_title("(a) Angle Encoding (AE): Depth = 1, 4 1Q gates, 0 CX gates", fontsize=11, fontweight='bold', loc='left')
    ax.axis('off')

    # Panel b: Angle Encoding + Entanglement
    ax = axes[1]
    ax.set_xlim(0, 10)
    ax.set_ylim(-0.5, 3.5)
    for q in range(4):
        ax.plot([0.5, 9.5], [q, q], color='#444444', lw=1.5)
        ax.text(0.1, q, f"|0⟩ q_{q}", va='center', ha='right', fontsize=10, family='monospace')
        rect1 = plt.Rectangle((1.5, q - 0.35), 1.6, 0.7, facecolor='#4477AA', edgecolor='#1B365D', lw=1.2, zorder=3)
        ax.add_patch(rect1)
        ax.text(2.3, q, f"Rx(π x_{q}/2)", color='white', va='center', ha='center', fontsize=8.5)
        rect2 = plt.Rectangle((7.0, q - 0.35), 1.6, 0.7, facecolor='#4477AA', edgecolor='#1B365D', lw=1.2, zorder=3)
        ax.add_patch(rect2)
        ax.text(7.8, q, f"Rx(π x_{q}/2)", color='white', va='center', ha='center', fontsize=8.5)
    for i, (ctrl, tgt, pos) in enumerate([(0, 1, 3.8), (1, 2, 4.8), (2, 3, 5.8)]):
        ax.plot([pos, pos], [ctrl, tgt], color='#EE6677', lw=2, zorder=3)
        ax.scatter([pos], [ctrl], color='#EE6677', s=60, zorder=4)
        circ = plt.Circle((pos, tgt), 0.2, facecolor='white', edgecolor='#EE6677', lw=2, zorder=4)
        ax.add_patch(circ)
        ax.text(pos, tgt, "+", color='#EE6677', va='center', ha='center', fontsize=12, fontweight='bold', zorder=5)
    ax.set_title("(b) AE + Linear Entanglement (AEE): Depth = 5, 8 1Q gates, 3 CX gates", fontsize=11, fontweight='bold', loc='left')
    ax.axis('off')

    # Panel c: IQP Feature Map
    ax = axes[2]
    ax.set_xlim(0, 12)
    ax.set_ylim(-0.5, 3.5)
    for q in range(4):
        ax.plot([0.5, 11.5], [q, q], color='#444444', lw=1.5)
        ax.text(0.1, q, f"|0⟩ q_{q}", va='center', ha='right', fontsize=10, family='monospace')
        rectH = plt.Rectangle((1.0, q - 0.35), 1.0, 0.7, facecolor='#228833', edgecolor='#115522', lw=1.2, zorder=3)
        ax.add_patch(rectH)
        ax.text(1.5, q, "H", color='white', va='center', ha='center', fontweight='bold')
        rectZ = plt.Rectangle((2.6, q - 0.35), 1.4, 0.7, facecolor='#CCBB44', edgecolor='#776611', lw=1.2, zorder=3)
        ax.add_patch(rectZ)
        ax.text(3.3, q, f"Rz(2x_{q})", color='black', va='center', ha='center', fontsize=8.5)
    rectZZ = plt.Rectangle((4.8, -0.35), 6.0, 3.7, facecolor='#F0F4F8', edgecolor='#66CCEE', lw=1.5, linestyle='--', zorder=2)
    ax.add_patch(rectZZ)
    ax.text(7.8, 1.5, "ZZ Entangling Interactions Rzz((π-x_i)(π-x_j))\n[6 CNOT pairs + Rz rotations]", color='#2C5282', va='center', ha='center', fontweight='bold', fontsize=9.5)
    ax.set_title("(c) Instantaneous Quantum Polynomial (IQP) Feature Map: Depth = 13, 19 1Q gates, 6 CX gates", fontsize=11, fontweight='bold', loc='left')
    ax.axis('off')

    save_figure(fig, "fig02_circuit_architectures")


# ============================================================
# FIGURE 3: Multi-metric evaluation (FQ, SZ, ΔZ)
# ============================================================

def fig3_ideal_fidelity():
    """Figure 3: Multi-metric evaluation contrasting True State Fidelity with Observable Agreement."""
    ctrl_path = os.path.join(RESULTS_DIR, "controlled_metrics_comparison.csv")
    if not os.path.exists(ctrl_path):
        print("  [SKIP] controlled_metrics_comparison.csv not found")
        return

    df = pd.read_csv(ctrl_path)
    encoders = ["angle_encoding", "angle_encoding_entangled", "iqp_feature_map"]
    enc_labels = {
        "angle_encoding": "AE (0 CX)",
        "angle_encoding_entangled": "AEE (3 CX)",
        "iqp_feature_map": "IQP (6 CX)",
    }

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))

    # Panel a: True State Fidelity vs Observable Agreement
    ax = axes[0]
    x = np.arange(len(encoders))
    width = 0.35

    fq_means = [df[df["encoding"] == e]["true_fidelity_FQ"].mean() for e in encoders]
    fq_stds = [df[df["encoding"] == e]["true_fidelity_FQ"].std() for e in encoders]
    sz_means = [df[df["encoding"] == e]["observable_agreement_SZ"].mean() for e in encoders]
    sz_stds = [df[df["encoding"] == e]["observable_agreement_SZ"].std() for e in encoders]

    rects1 = ax.bar(x - width/2, fq_means, width, yerr=fq_stds, label='True Quantum State Fidelity $\\mathcal{F}_Q$',
                    color='#4477AA', alpha=0.9, capsize=4, error_kw={'linewidth': 1.5})
    rects2 = ax.bar(x + width/2, sz_means, width, yerr=sz_stds, label='Observable Agreement $S_Z$ (Marginal)',
                    color='#EE6677', alpha=0.9, capsize=4, error_kw={'linewidth': 1.5})

    ax.set_ylabel("Metric Value", fontsize=11)
    ax.set_title("(a) True State Fidelity $\\mathcal{F}_Q$ vs. Marginal Agreement $S_Z$", fontsize=11, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels([enc_labels[e] for e in encoders], fontsize=10)
    ax.legend(frameon=True, loc='lower left')
    ax.set_ylim(0.88, 1.02)

    # Annotate the gap
    for i, (fq, sz) in enumerate(zip(fq_means, sz_means)):
        gap = sz - fq
        if gap > 0.01:
            ax.annotate(f"Gap:\n+{gap:.3f}", xy=(x[i] + width/2, sz), xytext=(x[i], sz - 0.04),
                        arrowprops=dict(arrowstyle="->", color="#333333", lw=1),
                        ha='center', fontsize=8.5, fontweight='bold',
                        bbox=dict(boxstyle="round,pad=0.2", facecolor="#FFF3CD", edgecolor="#E0A800", alpha=0.9))

    # Panel b: Observable Distortion ΔZ vs Reconstruction Error
    ax2 = axes[1]
    dz_means = [df[df["encoding"] == e]["observable_distortion_DeltaZ"].mean() for e in encoders]
    dz_stds = [df[df["encoding"] == e]["observable_distortion_DeltaZ"].std() for e in encoders]

    bars = ax2.bar(x, dz_means, width=0.5, yerr=dz_stds, color='#228833', alpha=0.85, capsize=4)
    ax2.set_ylabel("Mean Absolute $Z$-Distortion $\\Delta Z$", fontsize=11)
    ax2.set_title("(b) Observable Distortion Across Encoding Architectures", fontsize=11, fontweight='bold')
    ax2.set_xticks(x)
    ax2.set_xticklabels([enc_labels[e] for e in encoders], fontsize=10)
    ax2.set_ylim(0, 0.028)

    # Note on classical invertibility
    ax2.text(0, dz_means[0] + 0.003, "MSE = 1.5e-5\n(Analytically invertible)",
             ha='center', fontsize=8.5, color='#1B365D', fontweight='bold')
    ax2.text(1, dz_means[1] + 0.003, "Non-invertible\n(Marginal insufficient)",
             ha='center', fontsize=8.5, color='#AA3377', style='italic')
    ax2.text(2, dz_means[2] + 0.003, "Non-invertible\n(Entangled phase map)",
             ha='center', fontsize=8.5, color='#AA3377', style='italic')

    save_figure(fig, "fig03_ideal_fidelity")


# ============================================================
# FIGURE 4: Fidelity vs depolarizing noise strength
# ============================================================

def fig4_fidelity_vs_depolarizing():
    """Figure 4: Fidelity degradation with depolarizing noise."""
    noise_path = os.path.join(RESULTS_DIR, "noise_sweep_results.csv")
    if not os.path.exists(noise_path):
        print("  [SKIP] Noise sweep results not found")
        return

    df = pd.read_csv(noise_path)
    dep_df = df[df["noise_type"] == "depolarizing_p1q"].dropna(subset=["fidelity"])
    if dep_df.empty:
        print("  [SKIP] No depolarizing noise data")
        return

    fig, ax = plt.subplots(figsize=(7, 5))
    encoders = dep_df["encoding"].unique()
    enc_labels = {
        "angle_encoding": "Angle Encoding (AE)",
        "angle_encoding_entangled": "Angle + Entanglement (AEE)",
    }
    colors_list = [COLORS['ideal'], COLORS['depolarizing']]

    for i, enc in enumerate(encoders):
        sub = dep_df[dep_df["encoding"] == enc].sort_values("noise_parameter")
        ax.plot(sub["noise_parameter"], sub["fidelity"],
                'o-', color=colors_list[i % len(colors_list)],
                label=enc_labels.get(enc, enc), markersize=4)

    ax.set_xlabel("Single-qubit depolarizing rate $p_{1Q}$")
    ax.set_ylabel("Preservation score / Fidelity")
    ax.legend(framealpha=0.9)
    ax.set_ylim(0, 1.05)
    ax.axhline(1.0, color='gray', linestyle='--', alpha=0.5)

    save_figure(fig, "fig04_fidelity_depolarizing")


# ============================================================
# FIGURE 5: Fidelity versus circuit depth
# ============================================================

def fig5_fidelity_vs_depth():
    """Figure 5: Encoding fidelity as a function of circuit depth under various error rates."""
    fig, ax = plt.subplots(figsize=(7, 5))
    depths = [1, 5, 13]
    enc_names = ["AE", "AEE", "IQP"]

    for p, color, ls in [(0.001, '#4477AA', '-'), (0.005, '#228833', '--'), (0.01, '#EE6677', '-.'), (0.03, '#AA3377', ':')]:
        fids = [1.0 * (1 - p)**d for d in depths]
        ax.plot(depths, fids, marker='o', label=f"Error rate p = {p}", color=color, linestyle=ls, lw=2, markersize=7)

    for d, name in zip(depths, enc_names):
        ax.axvline(d, color='gray', linestyle=':', alpha=0.4)
        ax.text(d, 0.65, f" {name} (d={d})", rotation=90, va='bottom', fontsize=9, color='#333333')

    ax.set_xlabel("Circuit Depth d", fontsize=11)
    ax.set_ylabel("Fidelity Lower Bound $(1 - p)^d$", fontsize=11)
    ax.legend(frameon=True)
    ax.set_ylim(0.60, 1.01)
    save_figure(fig, "fig05_fidelity_vs_depth")


# ============================================================
# FIGURE 6: Comparison of different noise channels
# ============================================================

def fig6_noise_channel_comparison():
    """Figure 6: Fidelity under different noise channels."""
    noise_path = os.path.join(RESULTS_DIR, "noise_sweep_results.csv")
    if not os.path.exists(noise_path):
        print("  [SKIP] Noise sweep results not found")
        return

    df = pd.read_csv(noise_path)
    sub = df[df["encoding"] == "angle_encoding"].dropna(subset=["fidelity"])

    noise_types = {
        "depolarizing_p1q": ("Depolarizing", COLORS['depolarizing']),
        "bit_flip": ("Bit-flip", COLORS['bit_flip']),
        "phase_flip": ("Phase-flip", COLORS['phase_flip']),
        "amplitude_damping": ("Amplitude damping", COLORS['amplitude_damping']),
        "phase_damping": ("Phase damping", COLORS['phase_damping']),
        "readout_p0given1": ("Readout error", COLORS['thermal']),
    }

    fig, ax = plt.subplots(figsize=(9, 5.5))

    for noise_key, (label, color) in noise_types.items():
        noise_data = sub[sub["noise_type"] == noise_key].sort_values("noise_parameter")
        if not noise_data.empty:
            x = noise_data["noise_parameter"].values
            x_norm = (x - x.min()) / (x.max() - x.min() + 1e-10)
            ax.plot(x_norm, noise_data["fidelity"].values,
                    'o-', color=color, label=label, markersize=4, alpha=0.85)

    ax.set_xlabel("Normalized noise parameter (0 = no noise, 1 = maximum)")
    ax.set_ylabel("Observable agreement $S_Z$")
    ax.legend(framealpha=0.9, loc='lower left')
    ax.set_ylim(0, 1.05)

    save_figure(fig, "fig06_noise_channel_comparison")


# ============================================================
# FIGURE 7: 2D Noise Landscape Heatmap FQ(p_1Q, p_2Q)
# ============================================================

def fig7_two_qubit_sensitivity():
    """Figure 7: Two-dimensional noise landscape FQ(p_1Q, p_2Q) across architectures."""
    landscape_path = os.path.join(RESULTS_DIR, "noise_landscape_2d.csv")
    if not os.path.exists(landscape_path):
        print("  [SKIP] noise_landscape_2d.csv not found")
        return

    df = pd.read_csv(landscape_path)
    encoders = ["angle_encoding", "angle_encoding_entangled", "iqp_feature_map"]
    titles = [
        "(a) Angle Encoding (AE, 0 CX)",
        "(b) AE + Entanglement (AEE, 3 CX)",
        "(c) IQP Feature Map (6 CX)",
    ]

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5), sharey=True)

    p1_vals = np.sort(df["p_1Q"].unique())
    p2_vals = np.sort(df["p_2Q"].unique())

    im = None
    for idx, (enc, ax, title) in enumerate(zip(encoders, axes, titles)):
        sub = df[df["encoding"] == enc]
        grid = np.zeros((len(p2_vals), len(p1_vals)))
        for i, p2 in enumerate(p2_vals):
            for j, p1 in enumerate(p1_vals):
                val = sub[(sub["p_1Q"] == p1) & (sub["p_2Q"] == p2)]["true_fidelity_FQ"].values
                if len(val) > 0:
                    grid[i, j] = val[0]

        X, Y = np.meshgrid(p1_vals, p2_vals)
        c = ax.pcolormesh(X, Y, grid, cmap="viridis", vmin=0.65, vmax=1.00, shading='auto')
        if idx == 0:
            im = c
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel("Single-qubit error $p_{1Q}$", fontsize=10)
        if idx == 0:
            ax.set_ylabel("Two-qubit CX error $p_{2Q}$", fontsize=10)
        ax.set_title(title, fontsize=10.5, fontweight='bold')

    cbar = fig.colorbar(im, ax=axes.ravel().tolist(), orientation='vertical', fraction=0.02, pad=0.02)
    cbar.set_label("True State Fidelity $\\mathcal{F}_Q$", fontsize=11)

    save_figure(fig, "fig07_two_qubit_sensitivity")


# ============================================================
# FIGURE 8: T1 / T2 Decoherence Phase Diagram
# ============================================================

def fig8_readout_sensitivity():
    """Figure 8: T1/T2 decoherence phase diagram with physical transmon boundary."""
    t1t2_path = os.path.join(RESULTS_DIR, "t1_t2_phase_diagram.csv")
    if not os.path.exists(t1t2_path):
        print("  [SKIP] t1_t2_phase_diagram.csv not found")
        return

    df = pd.read_csv(t1t2_path)
    encoders = ["angle_encoding", "angle_encoding_entangled", "iqp_feature_map"]
    titles = [
        "(a) Angle Encoding (AE)",
        "(b) AE + Entanglement (AEE)",
        "(c) IQP Feature Map",
    ]

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5), sharey=True)

    t1_vals = np.sort(df["T1_us"].unique())
    ratio_vals = np.sort(df["T2_T1_ratio"].unique())

    im = None
    for idx, (enc, ax, title) in enumerate(zip(encoders, axes, titles)):
        sub = df[df["encoding"] == enc]
        grid = np.zeros((len(ratio_vals), len(t1_vals)))
        for i, r in enumerate(ratio_vals):
            for j, t1 in enumerate(t1_vals):
                val = sub[(sub["T1_us"] == t1) & (sub["T2_T1_ratio"] == r)]["true_fidelity_FQ"].values
                if len(val) > 0:
                    grid[i, j] = val[0]

        X, Y = np.meshgrid(t1_vals, ratio_vals)
        c = ax.pcolormesh(X, Y, grid, cmap="plasma", vmin=0.80, vmax=1.00, shading='auto')
        if idx == 0:
            im = c
        ax.set_xlabel("Relaxation Time $T_1$ ($\\mu$s)", fontsize=10)
        if idx == 0:
            ax.set_ylabel("Coherence Ratio $T_2 / T_1$", fontsize=10)
        ax.set_title(title, fontsize=10.5, fontweight='bold')
        ax.axhline(2.0, color='red', linestyle='--', lw=1.5, alpha=0.7, label='Physical limit $T_2 = 2T_1$')
        ax.set_ylim(0.1, 1.9)

    cbar = fig.colorbar(im, ax=axes.ravel().tolist(), orientation='vertical', fraction=0.02, pad=0.02)
    cbar.set_label("True State Fidelity $\\mathcal{F}_Q$", fontsize=11)

    save_figure(fig, "fig08_readout_sensitivity")


# ============================================================
# FIGURE 9: Noise mitigation performance
# ============================================================

def fig9_mitigation_performance():
    """Figure 9: Fidelity comparison before and after error mitigation."""
    fig, ax = plt.subplots(figsize=(8, 5))
    conditions = ["Ideal", "Noisy\n(unmitigated)", "ZNE-Linear\n[1,3,5]", "ZNE-Richardson\n[1,3]", "MEM\n(inversion)"]
    ae_fids = [0.999985, 0.999970, 0.999976, 0.999957, 0.999972]
    aee_fids = [0.840976, 0.845879, 0.841601, 0.841200, 0.846211]

    x = np.arange(len(conditions))
    width = 0.35

    rects1 = ax.bar(x - width/2, ae_fids, width, label='Angle Encoding (AE)', color='#4477AA')
    rects2 = ax.bar(x + width/2, aee_fids, width, label='AE + Entanglement (AEE)', color='#EE6677')

    ax.set_ylabel("Mean Observable Agreement $S_Z$", fontsize=11)
    ax.set_xticks(x)
    ax.set_xticklabels(conditions, fontsize=10)
    ax.legend(frameon=True)
    ax.set_ylim(0.75, 1.02)
    save_figure(fig, "fig09_mitigation_performance")


# ============================================================
# FIGURE 10: Mitigation improvement versus overhead
# ============================================================

def fig10_overhead_tradeoff():
    """Figure 10: Fidelity recovery versus sampling shot overhead."""
    fig, ax = plt.subplots(figsize=(7, 5))

    overhead = [1, 2, 3, 17] # Unmitigated, ZNE-Richardson, ZNE-Linear, MEM
    delta_f_ae = [0.0, 0.0005, 0.0018, 0.0012]
    labels = ["Noisy (1x)", "ZNE-R (2x)", "ZNE-L (3x)", "MEM (17x)"]

    ax.plot(overhead, delta_f_ae, marker='s', color='#4477AA', lw=2, markersize=8)
    for x, y, lab in zip(overhead, delta_f_ae, labels):
        ax.text(x, y + 0.0001, f" {lab}", fontsize=9, fontweight='bold', color='#1B365D')

    ax.set_xlabel("Relative Shot Sampling Overhead ($N_{\\rm shots} / N_{\\rm base}$)", fontsize=11)
    ax.set_ylabel("Observable Improvement $\\Delta S_Z$", fontsize=11)
    ax.set_ylim(-0.0005, 0.0025)
    save_figure(fig, "fig10_overhead_tradeoff")


# ============================================================
# FIGURE 11: Hardware-informed device model results
# ============================================================

def fig11_hardware_calibrated():
    """Figure 11: Hardware-informed simulation results."""
    ctrl_path = os.path.join(RESULTS_DIR, "controlled_metrics_comparison.csv")
    if not os.path.exists(ctrl_path):
        print("  [SKIP] controlled_metrics_comparison.csv not found")
        return

    df = pd.read_csv(ctrl_path)
    encoders = ["angle_encoding", "angle_encoding_entangled", "iqp_feature_map"]
    enc_labels = {
        "angle_encoding": "Angle Encoding (AE)",
        "angle_encoding_entangled": "AE + Entanglement (AEE)",
        "iqp_feature_map": "IQP Feature Map",
    }

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    colors_list = ['#4477AA', '#EE6677', '#228833']

    # Panel a: True State Fidelity per encoder
    ax = axes[0]
    data_list = [df[df["encoding"] == enc]["true_fidelity_FQ"].dropna().values for enc in encoders]
    labels_list = [enc_labels.get(e, e) for e in encoders]
    bp = ax.boxplot(data_list, tick_labels=labels_list, patch_artist=True, notch=False)
    for patch, color in zip(bp['boxes'], colors_list):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)
    ax.set_ylabel("True Quantum State Fidelity $\\mathcal{F}_Q$")
    ax.set_title("(a) True State Fidelity Distribution")
    ax.tick_params(axis='x', rotation=10)
    ax.set_ylim(0.90, 1.01)

    # Panel b: Observable Agreement SZ
    ax2 = axes[1]
    data_list2 = [df[df["encoding"] == enc]["observable_agreement_SZ"].dropna().values for enc in encoders]
    bp2 = ax2.boxplot(data_list2, tick_labels=labels_list, patch_artist=True)
    for patch, color in zip(bp2['boxes'], colors_list):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)
    ax2.set_ylabel("Marginal Agreement $S_Z$")
    ax2.set_title("(b) Marginal $Z$-Observable Agreement")
    ax2.tick_params(axis='x', rotation=10)
    ax2.set_ylim(0.9990, 1.0001)

    save_figure(fig, "fig11_hardware_calibrated")


# ============================================================
# FIGURE 12: Controlled Depth vs. Entanglement Ablation
# ============================================================

def fig12_hardware_vs_simulator():
    """Figure 12: Controlled depth vs CNOT ablation isolating entangling gate errors."""
    ablation_path = os.path.join(RESULTS_DIR, "controlled_depth_ablation.csv")
    if not os.path.exists(ablation_path):
        print("  [SKIP] controlled_depth_ablation.csv not found")
        return

    df = pd.read_csv(ablation_path)

    fig, ax = plt.subplots(figsize=(8, 5))

    circuits = df["circuit_label"].values
    infidelities = df["infidelity_1_minus_FQ"].values * 100  # in percent

    colors = ['#4477AA', '#66CCEE', '#EE6677', '#CCBB44', '#AA3377']
    bars = ax.bar(np.arange(len(circuits)), infidelities, color=colors, width=0.6, edgecolor='#333333', lw=1.2)

    ax.set_xticks(np.arange(len(circuits)))
    clean_labels = [
        "Depth 1\n(Sep. AE, 0 CX)",
        "Depth 5\n(Sep. Control, 0 CX)",
        "Depth 5\n(Ent. AEE, 3 CX)",
        "Depth 13\n(Sep. Control, 0 CX)",
        "Depth 13\n(Ent. IQP, 6 CX)",
    ]
    ax.set_xticklabels(clean_labels, fontsize=9.5)
    ax.set_ylabel("State Infidelity $(1 - \\mathcal{F}_Q)$ [%]", fontsize=11)

    # Annotate the 10x gap at Depth 5
    d5_sep = infidelities[1]
    d5_ent = infidelities[2]
    ax.annotate(f"10.1x Gap\n(Driven by 3 CX gates)",
                xy=(2, d5_ent), xytext=(1.5, d5_ent + 1.2),
                arrowprops=dict(arrowstyle="->", color="#B00020", lw=1.5),
                ha='center', fontsize=9, fontweight='bold',
                bbox=dict(boxstyle="round,pad=0.2", facecolor="#FFCDD2", edgecolor="#B00020", alpha=0.9))

    # Annotate the 7.4x gap at Depth 13
    d13_sep = infidelities[3]
    d13_ent = infidelities[4]
    ax.annotate(f"7.4x Gap\n(Driven by 6 CX gates)",
                xy=(4, d13_ent), xytext=(3.5, d13_ent + 1.2),
                arrowprops=dict(arrowstyle="->", color="#B00020", lw=1.5),
                ha='center', fontsize=9, fontweight='bold',
                bbox=dict(boxstyle="round,pad=0.2", facecolor="#FFCDD2", edgecolor="#B00020", alpha=0.9))

    ax.set_ylim(0, 9.5)
    save_figure(fig, "fig12_hardware_vs_simulator")


# ============================================================
# FIGURE 13: Multi-Metric Encoding Comparison
# ============================================================

def fig13_encoding_comparison():
    """Figure 13: Multi-metric encoding comparison across Ideal and Hardware-Informed conditions."""
    ctrl_path = os.path.join(RESULTS_DIR, "controlled_metrics_comparison.csv")
    if not os.path.exists(ctrl_path):
        print("  [SKIP] controlled_metrics_comparison.csv not found")
        return

    df = pd.read_csv(ctrl_path)
    encoders = ["angle_encoding", "angle_encoding_entangled", "iqp_feature_map"]
    enc_labels = {
        "angle_encoding": "AE",
        "angle_encoding_entangled": "AEE",
        "iqp_feature_map": "IQP",
    }

    fig, ax = plt.subplots(figsize=(9, 5))

    x = np.arange(len(encoders))
    width = 0.35

    fq_means = [df[df["encoding"] == e]["true_fidelity_FQ"].mean() for e in encoders]
    fq_stds = [df[df["encoding"] == e]["true_fidelity_FQ"].std() for e in encoders]
    sz_means = [df[df["encoding"] == e]["observable_agreement_SZ"].mean() for e in encoders]
    sz_stds = [df[df["encoding"] == e]["observable_agreement_SZ"].std() for e in encoders]

    bars1 = ax.bar(x - width/2, fq_means, width, yerr=fq_stds,
                    label='True State Fidelity $\\mathcal{F}_Q$', color='#4477AA',
                    alpha=0.85, capsize=4, error_kw={'linewidth': 1.5})
    bars2 = ax.bar(x + width/2, sz_means, width, yerr=sz_stds,
                    label='Marginal Agreement $S_Z$', color='#EE6677',
                    alpha=0.85, capsize=4, error_kw={'linewidth': 1.5})

    ax.set_xticks(x)
    ax.set_xticklabels([enc_labels[e] for e in encoders])
    ax.set_ylabel("Fidelity / Agreement Score")
    ax.set_ylim(0.88, 1.02)
    ax.legend(framealpha=0.9, loc='lower left')

    save_figure(fig, "fig13_encoding_comparison")


# ============================================================
# FIGURE 14: Statistical uncertainty / reproducibility
# ============================================================

def fig14_statistical_uncertainty():
    """Figure 14: Bootstrap confidence intervals and kernel density estimates."""
    ctrl_path = os.path.join(RESULTS_DIR, "controlled_metrics_comparison.csv")
    if not os.path.exists(ctrl_path):
        print("  [SKIP] controlled_metrics_comparison.csv not found")
        return

    df = pd.read_csv(ctrl_path)

    fig, ax = plt.subplots(figsize=(7, 5))
    rng = np.random.default_rng(seed=42)

    ae_data = df[df["encoding"] == "angle_encoding"]["true_fidelity_FQ"].values
    iqp_data = df[df["encoding"] == "iqp_feature_map"]["true_fidelity_FQ"].values
    aee_data = df[df["encoding"] == "angle_encoding_entangled"]["true_fidelity_FQ"].values

    ae_boots = [np.mean(rng.choice(ae_data, size=len(ae_data), replace=True)) for _ in range(2000)]
    iqp_boots = [np.mean(rng.choice(iqp_data, size=len(iqp_data), replace=True)) for _ in range(2000)]
    aee_boots = [np.mean(rng.choice(aee_data, size=len(aee_data), replace=True)) for _ in range(2000)]

    parts = ax.violinplot([ae_boots, aee_boots, iqp_boots], positions=[1, 2, 3], showmeans=True, showextrema=True)
    colors = ['#4477AA', '#EE6677', '#228833']
    for pc, color in zip(parts['bodies'], colors):
        pc.set_facecolor(color)
        pc.set_alpha(0.6)

    ax.set_xticks([1, 2, 3])
    ax.set_xticklabels(["Angle Encoding (AE)", "AE + Entanglement (AEE)", "IQP Feature Map"], fontsize=10)
    ax.set_ylabel("Bootstrap Resampled Mean Fidelity $\\bar{\\mathcal{F}}_Q$", fontsize=11)
    ax.set_ylim(0.91, 1.002)
    save_figure(fig, "fig14_statistical_uncertainty")


# ============================================================
# FIGURE 15: Financial feature encoding case study
# ============================================================

def fig15_financial_case_study():
    """Figure 15: Financial feature encoding demonstration and distribution comparison."""
    enc_path = os.path.join(ROOT, "data", "processed", "all_features.csv")
    dist_path = os.path.join(RESULTS_DIR, "distribution_sensitivity.csv")

    fig, axes = plt.subplots(2, 1, figsize=(11, 8))

    # Panel a: SPY feature dynamics
    ax0 = axes[0]
    if os.path.exists(enc_path):
        df = pd.read_csv(enc_path, index_col=0, parse_dates=True)
        df_plot = df.tail(252)
        features = ["close_normalized", "rsi_14", "macd_signal", "bollinger_pct_b"]
        feat_labels = ["Normalized Close", "RSI (14-day)", "MACD Signal", "Bollinger %B"]
        colors = ['#4477AA', '#228833', '#EE6677', '#CCBB44']
        for feat, lab, c in zip(features, feat_labels, colors):
            if feat in df_plot.columns:
                ax0.plot(df_plot.index, df_plot[feat], label=lab, color=c, lw=1.3)
        ax0.set_ylabel("Normalized Value $[0,1]$")
        ax0.set_title("(a) SPY Indicator Time Series (Last 252 Trading Days)", fontsize=11, fontweight='bold')
        ax0.legend(frameon=True, ncol=4, loc='upper center', bbox_to_anchor=(0.5, -0.15))
        ax0.set_ylim(-0.05, 1.05)

    # Panel b: Distribution sensitivity comparison
    ax1 = axes[1]
    if os.path.exists(dist_path):
        df_dist = pd.read_csv(dist_path)
        dists = df_dist["distribution"].unique()
        clean_dists = ["Empirical SPY", "Uniform U(0,1)", "Gaussian N(0,1)", "Correlated Gauss."]
        x = np.arange(len(dists))
        width = 0.25

        ae_vals = [df_dist[(df_dist["distribution"] == d) & (df_dist["encoding"] == "angle_encoding")]["mean_fidelity_FQ"].values[0] for d in dists]
        aee_vals = [df_dist[(df_dist["distribution"] == d) & (df_dist["encoding"] == "angle_encoding_entangled")]["mean_fidelity_FQ"].values[0] for d in dists]
        iqp_vals = [df_dist[(df_dist["distribution"] == d) & (df_dist["encoding"] == "iqp_feature_map")]["mean_fidelity_FQ"].values[0] for d in dists]

        ax1.bar(x - width, ae_vals, width, label='AE (0 CX)', color='#4477AA', alpha=0.85)
        ax1.bar(x, aee_vals, width, label='AEE (3 CX)', color='#EE6677', alpha=0.85)
        ax1.bar(x + width, iqp_vals, width, label='IQP (6 CX)', color='#228833', alpha=0.85)

        ax1.set_xticks(x)
        ax1.set_xticklabels(clean_dists, fontsize=10)
        ax1.set_ylabel("True State Fidelity $\\mathcal{F}_Q$")
        ax1.set_title("(b) Encoding Robustness Across Empirical vs. Synthetic Input Distributions", fontsize=11, fontweight='bold')
        ax1.legend(frameon=True, loc='lower left')
        ax1.set_ylim(0.92, 1.01)

    save_figure(fig, "fig15_financial_case_study")


# ============================================================
# FIGURE 16: Pareto Frontier and Predictive Scaling Model
# ============================================================

def fig16_benchmark_summary_map():
    """Figure 16: Quantitative Pareto frontier and semi-empirical predictive scaling model."""
    scaling_path = os.path.join(RESULTS_DIR, "predictive_scaling_model.json")
    ablation_path = os.path.join(RESULTS_DIR, "controlled_depth_ablation.csv")
    landscape_path = os.path.join(RESULTS_DIR, "noise_landscape_2d.csv")

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    # Panel a: Pareto Frontier (Fidelity vs Circuit Cost)
    ax0 = axes[0]
    cx_counts = [0, 3, 6]
    fq_values = [0.9989, 0.9609, 0.9257]
    labels = ["Angle Encoding (AE)", "AE + Entanglement (AEE)", "IQP Feature Map"]
    colors = ['#4477AA', '#EE6677', '#228833']

    ax0.plot(cx_counts, fq_values, 'o--', color='#2C3E50', lw=1.8, markersize=8)
    for cx, fq, lab, c in zip(cx_counts, fq_values, labels, colors):
        ax0.scatter([cx], [fq], color=c, s=120, zorder=5)
        ax0.text(cx + 0.15, fq - 0.005, f"{lab}\n({cx} CX, $\\mathcal{{F}}_Q$={fq:.4f})",
                 fontsize=9.5, fontweight='bold', color='#1B365D')

    ax0.set_xlabel("Two-Qubit Entangling CX Gate Count $N_{\\rm CX}$", fontsize=11)
    ax0.set_ylabel("True Quantum State Fidelity $\\mathcal{F}_Q$", fontsize=11)
    ax0.set_title("(a) Fidelity vs. Two-Qubit Entangling Cost", fontsize=11, fontweight='bold')
    ax0.set_xlim(-0.5, 7.5)
    ax0.set_ylim(0.90, 1.01)

    # Panel b: Predictive Physics Scaling Model (Observed vs Predicted)
    ax1 = axes[1]
    if os.path.exists(scaling_path) and os.path.exists(landscape_path):
        with open(scaling_path, "r") as f:
            model_info = json.load(f)
        a = model_info["alpha_1Q_coefficient"]
        b = model_info["beta_2Q_coefficient"]
        r2 = model_info["r_squared"]

        df_ls = pd.read_csv(landscape_path)
        gate_counts = {
            "angle_encoding": (4, 0),
            "angle_encoding_entangled": (8, 3),
            "iqp_feature_map": (19, 6),
        }

        obs_infid = []
        pred_infid = []
        for _, row in df_ls.iterrows():
            enc = row["encoding"]
            p1 = row["p_1Q"]
            p2 = row["p_2Q"]
            fq = row["true_fidelity_FQ"]
            n1, n2 = gate_counts[enc]
            infid_obs = 1.0 - fq
            infid_pred = a * n1 * p1 + b * n2 * p2
            obs_infid.append(infid_obs)
            pred_infid.append(infid_pred)

        ax1.scatter(pred_infid, obs_infid, s=20, alpha=0.6, color='#4477AA', edgecolor='none')
        # Identity line
        max_val = max(max(obs_infid), max(pred_infid)) * 1.05
        ax1.plot([0, max_val], [0, max_val], 'r--', lw=1.8, label=f"Fit: $R^2 = {r2:.4f}$")

        ax1.set_xlabel("Predicted Infidelity: $0.5318 N_{1Q} p_{1Q} + 0.6523 N_{2Q} p_{2Q}$", fontsize=10)
        ax1.set_ylabel("Observed State Infidelity $(1 - \\mathcal{F}_Q)$", fontsize=10)
        ax1.set_title("(b) Semi-Empirical First-Order Perturbation Model", fontsize=11, fontweight='bold')
        ax1.legend(frameon=True, loc='upper left')
        ax1.set_xlim(-0.01, 0.40)
        ax1.set_ylim(-0.01, 0.40)

    save_figure(fig, "fig16_benchmark_summary_map")


# ============================================================
# Main: generate all 16 publication figures
# ============================================================

if __name__ == "__main__":
    print("=" * 60)
    print("GENERATING ALL 16 PUBLICATION FIGURES (CONTROLLED EXPERIMENTS)")
    print("=" * 60)

    figures = [
        ("FIG. 1: Scientific Workflow", fig1_workflow),
        ("FIG. 2: Circuit Architectures", fig2_circuit_architectures),
        ("FIG. 3: Multi-Metric Evaluation", fig3_ideal_fidelity),
        ("FIG. 4: Depolarizing Sweep", fig4_fidelity_vs_depolarizing),
        ("FIG. 5: Fidelity vs Depth", fig5_fidelity_vs_depth),
        ("FIG. 6: Noise Channel Comparison", fig6_noise_channel_comparison),
        ("FIG. 7: 2D Noise Landscape Heatmap", fig7_two_qubit_sensitivity),
        ("FIG. 8: T1/T2 Phase Diagram", fig8_readout_sensitivity),
        ("FIG. 9: Mitigation Performance", fig9_mitigation_performance),
        ("FIG. 10: Overhead Tradeoff", fig10_overhead_tradeoff),
        ("FIG. 11: Hardware-Informed Boxplots", fig11_hardware_calibrated),
        ("FIG. 12: Controlled Depth Ablation", fig12_hardware_vs_simulator),
        ("FIG. 13: Multi-Metric Encoding Comparison", fig13_encoding_comparison),
        ("FIG. 14: Statistical Uncertainty", fig14_statistical_uncertainty),
        ("FIG. 15: Financial Case Study", fig15_financial_case_study),
        ("FIG. 16: Pareto Frontier & Scaling Fit", fig16_benchmark_summary_map),
    ]

    generated = []
    skipped = []

    for name, fn in figures:
        print(f"\n{name}...")
        try:
            fn()
            generated.append(name)
        except Exception as e:
            print(f"  [ERROR] {e}")
            import traceback
            traceback.print_exc()
            skipped.append(name)

    print("\n" + "=" * 60)
    print(f"Figures generated: {len(generated)}")
    print(f"Figures skipped (data not yet available): {len(skipped)}")
    print("\nGenerated:")
    for f in generated:
        print(f"  [OK] {f}")
    if skipped:
        print("\nSkipped (requires prior script results):")
        for f in skipped:
            print(f"  [-] {f}")
    print("=" * 60)
