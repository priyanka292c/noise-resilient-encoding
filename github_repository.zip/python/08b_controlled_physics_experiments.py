#!/usr/bin/env python3
"""
08b_controlled_physics_experiments.py
======================================
Executes the five controlled physics experiments required for Physical Review Applied:
1. True State Fidelity F_Q vs Observable Agreement S_Z vs Observable Distortion Delta_Z
2. 2D Noise Landscape Heatmap F_Q(p_1Q, p_2Q)
3. T1 / T2 Decoherence Phase Diagram F_Q(T1, T2)
4. Controlled Depth vs Two-Qubit Gate (CNOT) Ablation
5. Financial vs Synthetic Feature Distribution Sensitivity
6. Analytical Physics Predictive Scaling Relation Fit

Physical Review Applied manuscript:
"Noise Resilient Quantum Circuits for Financial Indicator Encoding
Under Realistic Device Noise"
"""

import os
import sys
import json
import numpy as np
import pandas as pd
from tqdm import tqdm

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS_DIR = os.path.join(ROOT, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

import yaml
with open(os.path.join(ROOT, "config.yaml"), "r") as f:
    CONFIG = yaml.safe_load(f)

RANDOM_SEED = CONFIG["random_seed"]
np.random.seed(RANDOM_SEED)

from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Statevector, state_fidelity, Pauli
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error, thermal_relaxation_error

sys.path.insert(0, os.path.join(ROOT, "python"))
from encoding_utils import (
    angle_encoding, angle_encoding_entangled, iqp_feature_map,
    bind_parameters, compute_true_state_fidelity,
    compute_observable_agreement, compute_observable_distortion,
    circuit_z_expectations, z_expectation_from_counts,
    feature_reconstruction_error
)

N_QUBITS = 4

# Load test data
test_path = os.path.join(ROOT, CONFIG["data"]["processed_dir"], "test_features.csv")
test_df = pd.read_csv(test_path, index_col=0)
ENCODING_FEATURES = ["close_normalized", "rsi_14", "macd_signal", "bollinger_pct_b"]
available_cols = [c for c in ENCODING_FEATURES if c in test_df.columns]
X_test = test_df[available_cols].values

# Representative sample subset for physical scans
rng = np.random.default_rng(RANDOM_SEED)
idx = rng.choice(len(X_test), size=min(50, len(X_test)), replace=False)
X_subset = X_test[idx]


# ============================================================
# EXPERIMENT 1: Comprehensive Multi-Metric Comparison
# ============================================================
def run_experiment_1():
    print("\n--- EXPERIMENT 1: True State Fidelity vs Observable Metrics ---")
    # Base hardware-informed noise model
    nm = NoiseModel()
    t1 = 140e3  # ns
    t2 = 100e3  # ns
    th_1q = thermal_relaxation_error(t1, t2, 35)
    dep_1q = depolarizing_error(2.2e-4, 1)
    nm.add_all_qubit_quantum_error(th_1q.compose(dep_1q), ['rx', 'ry', 'rz', 'h', 'sx', 'x'])

    th_2q = thermal_relaxation_error(t1, t2, 300).expand(thermal_relaxation_error(t1, t2, 300))
    dep_2q = depolarizing_error(1.08e-2, 2)
    nm.add_all_qubit_quantum_error(th_2q.compose(dep_2q), ['cx'])

    sim_noisy = AerSimulator(noise_model=nm)

    records = []
    encoders = [
        ("angle_encoding", angle_encoding),
        ("angle_encoding_entangled", angle_encoding_entangled),
        ("iqp_feature_map", iqp_feature_map)
    ]

    for enc_name, enc_fn in encoders:
        qc, params, meta = enc_fn(N_QUBITS)
        for i, x in enumerate(tqdm(X_subset, desc=f"Exp 1: {enc_name}")):
            qc_no_m = bind_parameters(qc, params, x)
            z_ideal = circuit_z_expectations(qc_no_m, N_QUBITS)
            fq = compute_true_state_fidelity(qc_no_m, nm)

            # Measurement simulation
            qc_m = qc.copy()
            qc_m.measure_all()
            qc_b = bind_parameters(qc_m, params, x)
            counts = sim_noisy.run(transpile(qc_b, sim_noisy), shots=8192).result().get_counts()
            z_noisy = z_expectation_from_counts(counts, N_QUBITS)

            sz = compute_observable_agreement(z_ideal, z_noisy)
            dz = compute_observable_distortion(z_ideal, z_noisy)
            rec_err = feature_reconstruction_error(x, z_noisy, encoding_name=enc_name)

            records.append({
                "encoding": enc_name,
                "sample_idx": int(idx[i]),
                "true_fidelity_FQ": fq,
                "observable_agreement_SZ": sz,
                "observable_distortion_DeltaZ": dz,
                "reconstruction_error": rec_err,
                "depth": meta["circuit_depth"],
                "cx_count": meta["two_qubit_gates"]
            })

    df = pd.DataFrame(records)
    out_path = os.path.join(RESULTS_DIR, "controlled_metrics_comparison.csv")
    df.to_csv(out_path, index=False)
    print(f"  [OK] Saved: {out_path}")

    summary = df.groupby("encoding")[["true_fidelity_FQ", "observable_agreement_SZ", "observable_distortion_DeltaZ"]].agg(["mean", "std"])
    print(summary.to_string())


# ============================================================
# EXPERIMENT 2: 2D Noise Landscape Heatmap F_Q(p_1Q, p_2Q)
# ============================================================
def run_experiment_2():
    print("\n--- EXPERIMENT 2: 2D Noise Landscape F_Q(p_1Q, p_2Q) ---")
    p1q_grid = np.logspace(-4, -2, 7)  # 1e-4 to 1e-2
    p2q_grid = np.logspace(-3, -1, 7)  # 1e-3 to 1e-1

    records = []
    x_mean = np.mean(X_subset, axis=0)

    encoders = [
        ("angle_encoding", angle_encoding),
        ("angle_encoding_entangled", angle_encoding_entangled),
        ("iqp_feature_map", iqp_feature_map)
    ]

    for enc_name, enc_fn in encoders:
        qc, params, _ = enc_fn(N_QUBITS)
        qc_bound = bind_parameters(qc, params, x_mean)

        for p1 in p1q_grid:
            for p2 in p2q_grid:
                nm = NoiseModel()
                nm.add_all_qubit_quantum_error(depolarizing_error(p1, 1), ['rx', 'ry', 'rz', 'h', 'sx', 'x'])
                nm.add_all_qubit_quantum_error(depolarizing_error(p2, 2), ['cx'])

                fq = compute_true_state_fidelity(qc_bound, nm)
                records.append({
                    "encoding": enc_name,
                    "p_1Q": p1,
                    "p_2Q": p2,
                    "true_fidelity_FQ": fq
                })

    df = pd.DataFrame(records)
    out_path = os.path.join(RESULTS_DIR, "noise_landscape_2d.csv")
    df.to_csv(out_path, index=False)
    print(f"  [OK] Saved 2D Noise Landscape: {out_path} ({len(df)} grid points)")


# ============================================================
# EXPERIMENT 3: T1 / T2 Decoherence Phase Diagram
# ============================================================
def run_experiment_3():
    print("\n--- EXPERIMENT 3: T1 / T2 Decoherence Phase Diagram ---")
    t1_grid = np.linspace(20, 200, 6)   # us
    t2_ratios = np.linspace(0.2, 1.8, 6) # T2 / T1 ratio (physical: <= 2.0)

    records = []
    x_mean = np.mean(X_subset, axis=0)

    encoders = [
        ("angle_encoding", angle_encoding),
        ("angle_encoding_entangled", angle_encoding_entangled),
        ("iqp_feature_map", iqp_feature_map)
    ]

    for enc_name, enc_fn in encoders:
        qc, params, _ = enc_fn(N_QUBITS)
        qc_bound = bind_parameters(qc, params, x_mean)

        for t1_us in t1_grid:
            for ratio in t2_ratios:
                t2_us = min(t1_us * ratio, 2.0 * t1_us - 1.0) # adhere to T2 <= 2T1
                t1_ns = t1_us * 1e3
                t2_ns = t2_us * 1e3

                nm = NoiseModel()
                th_1q = thermal_relaxation_error(t1_ns, t2_ns, 35)
                nm.add_all_qubit_quantum_error(th_1q, ['rx', 'ry', 'rz', 'h', 'sx', 'x'])
                th_2q = thermal_relaxation_error(t1_ns, t2_ns, 300).expand(thermal_relaxation_error(t1_ns, t2_ns, 300))
                nm.add_all_qubit_quantum_error(th_2q, ['cx'])

                fq = compute_true_state_fidelity(qc_bound, nm)
                records.append({
                    "encoding": enc_name,
                    "T1_us": t1_us,
                    "T2_us": t2_us,
                    "T2_T1_ratio": ratio,
                    "true_fidelity_FQ": fq
                })

    df = pd.DataFrame(records)
    out_path = os.path.join(RESULTS_DIR, "t1_t2_phase_diagram.csv")
    df.to_csv(out_path, index=False)
    print(f"  [OK] Saved T1/T2 Phase Diagram: {out_path} ({len(df)} points)")


# ============================================================
# EXPERIMENT 4: Controlled Depth vs Entanglement Ablation
# ============================================================
def run_experiment_4():
    print("\n--- EXPERIMENT 4: Controlled Depth vs CNOT Ablation ---")
    x_mean = np.mean(X_subset, axis=0)

    # Standard hardware-informed noise model
    nm = NoiseModel()
    t1 = 140e3
    t2 = 100e3
    th_1q = thermal_relaxation_error(t1, t2, 35)
    dep_1q = depolarizing_error(2.2e-4, 1)
    nm.add_all_qubit_quantum_error(th_1q.compose(dep_1q), ['rx', 'ry', 'rz', 'h', 'sx', 'x'])
    th_2q = thermal_relaxation_error(t1, t2, 300).expand(thermal_relaxation_error(t1, t2, 300))
    dep_2q = depolarizing_error(1.08e-2, 2)
    nm.add_all_qubit_quantum_error(th_2q.compose(dep_2q), ['cx'])

    # Build depth-matched separable circuits
    # Circuit A: Depth 1, 0 CX (Standard AE)
    qc_d1 = QuantumCircuit(4)
    for i in range(4): qc_d1.rx(np.pi * x_mean[i], i)

    # Circuit B: Depth 5, 0 CX (Repeated single-qubit rotations, matching AEE depth)
    qc_d5_sep = QuantumCircuit(4)
    for rep in range(5):
        for i in range(4): qc_d5_sep.rx((np.pi * x_mean[i]) / 5.0, i)

    # Circuit C: Depth 5, 3 CX (Standard AEE)
    qc_aee, p_aee, _ = angle_encoding_entangled(4)
    qc_d5_ent = bind_parameters(qc_aee, p_aee, x_mean)

    # Circuit D: Depth 13, 0 CX (Repeated single-qubit rotations, matching IQP depth)
    qc_d13_sep = QuantumCircuit(4)
    for rep in range(13):
        for i in range(4): qc_d13_sep.rx((np.pi * x_mean[i]) / 13.0, i)

    # Circuit E: Depth 13, 6 CX (Standard IQP)
    qc_iqp, p_iqp, _ = iqp_feature_map(4)
    qc_d13_ent = bind_parameters(qc_iqp, p_iqp, x_mean)

    configs = [
        ("Depth 1 (Separable AE)", 1, 0, False, qc_d1),
        ("Depth 5 (Separable Control)", 5, 0, False, qc_d5_sep),
        ("Depth 5 (Entangled AEE)", 5, 3, True, qc_d5_ent),
        ("Depth 13 (Separable Control)", 13, 0, False, qc_d13_sep),
        ("Depth 13 (Entangled IQP)", 13, 6, True, qc_d13_ent)
    ]

    records = []
    for label, depth, cx, is_ent, qc in configs:
        fq = compute_true_state_fidelity(qc, nm)
        infidelity = 1.0 - fq
        records.append({
            "circuit_label": label,
            "depth": depth,
            "cx_count": cx,
            "entangled": is_ent,
            "true_fidelity_FQ": fq,
            "infidelity_1_minus_FQ": infidelity
        })
        print(f"  {label:30s} | Depth: {depth:2d} | CX: {cx:2d} | F_Q = {fq:.5f} | Infidelity = {infidelity:.5f}")

    df = pd.DataFrame(records)
    out_path = os.path.join(RESULTS_DIR, "controlled_depth_ablation.csv")
    df.to_csv(out_path, index=False)
    print(f"  [OK] Saved Depth Ablation: {out_path}")


# ============================================================
# EXPERIMENT 5: Financial vs Synthetic Feature Distributions
# ============================================================
def run_experiment_5():
    print("\n--- EXPERIMENT 5: Input Distribution Sensitivity ---")
    N_SAMPLES = 50
    nm = NoiseModel()
    nm.add_all_qubit_quantum_error(depolarizing_error(2.2e-4, 1), ['rx', 'ry', 'rz', 'h', 'sx', 'x'])
    nm.add_all_qubit_quantum_error(depolarizing_error(1.08e-2, 2), ['cx'])

    # 1. Empirical Financial Data
    X_financial = X_subset[:N_SAMPLES]

    # 2. Independent Uniform [0, 1]
    rng_synth = np.random.default_rng(RANDOM_SEED + 100)
    X_uniform = rng_synth.uniform(0.0, 1.0, size=(N_SAMPLES, 4))

    # 3. Independent Gaussian mapped to [0, 1] via CDF
    from scipy.stats import norm
    X_gaussian = norm.cdf(rng_synth.normal(0.0, 1.0, size=(N_SAMPLES, 4)))

    # 4. Correlated Gaussian (matching financial correlation matrix)
    corr_mat = np.corrcoef(X_test, rowvar=False)
    mean_vec = np.mean(X_test, axis=0)
    std_vec = np.std(X_test, axis=0)
    cov_mat = np.outer(std_vec, std_vec) * corr_mat
    X_corr_raw = rng_synth.multivariate_normal(mean_vec, cov_mat, size=N_SAMPLES)
    X_correlated = np.clip(X_corr_raw, 0.0, 1.0)

    dist_sets = [
        ("Empirical SPY (Financial)", X_financial),
        ("Synthetic Uniform U(0,1)", X_uniform),
        ("Synthetic Gaussian N(0,1)", X_gaussian),
        ("Correlated Gaussian (Matched)", X_correlated)
    ]

    records = []
    encoders = [
        ("angle_encoding", angle_encoding),
        ("angle_encoding_entangled", angle_encoding_entangled),
        ("iqp_feature_map", iqp_feature_map)
    ]

    for dist_name, X_data in dist_sets:
        for enc_name, enc_fn in encoders:
            qc, params, _ = enc_fn(N_QUBITS)
            fqs = []
            for x in X_data:
                qc_b = bind_parameters(qc, params, x)
                fqs.append(compute_true_state_fidelity(qc_b, nm))
            records.append({
                "distribution": dist_name,
                "encoding": enc_name,
                "mean_fidelity_FQ": float(np.mean(fqs)),
                "std_fidelity_FQ": float(np.std(fqs)),
                "min_fidelity_FQ": float(np.min(fqs)),
                "max_fidelity_FQ": float(np.max(fqs))
            })

    df = pd.DataFrame(records)
    out_path = os.path.join(RESULTS_DIR, "distribution_sensitivity.csv")
    df.to_csv(out_path, index=False)
    print(f"  [OK] Saved Distribution Sensitivity: {out_path}")
    print(df.to_string())


# ============================================================
# EXPERIMENT 6: Analytical Physics Predictive Scaling Relation
# ============================================================
def run_experiment_6():
    print("\n--- EXPERIMENT 6: Analytical Predictive Scaling Model ---")
    # Scaling model: 1 - F_Q ~ alpha * N_1Q * p_1Q + beta * N_2Q * p_2Q + gamma * (t_circuit / T1) + delta * (t_circuit / T_phi)
    # Using linear regression to fit parameters across our multi-channel dataset
    df_landscape = pd.read_csv(os.path.join(RESULTS_DIR, "noise_landscape_2d.csv"))

    # Assign gate counts:
    gate_counts = {
        "angle_encoding": {"N1": 4, "N2": 0},
        "angle_encoding_entangled": {"N1": 8, "N2": 3},
        "iqp_feature_map": {"N1": 19, "N2": 6}
    }

    X_reg = []
    y_reg = []

    for _, row in df_landscape.iterrows():
        enc = row["encoding"]
        n1 = gate_counts[enc]["N1"]
        n2 = gate_counts[enc]["N2"]
        p1 = row["p_1Q"]
        p2 = row["p_2Q"]
        infid = 1.0 - row["true_fidelity_FQ"]

        X_reg.append([n1 * p1, n2 * p2])
        y_reg.append(infid)

    X_mat = np.array(X_reg)
    y_vec = np.array(y_reg)

    # Least squares fit without intercept
    coef, residuals, rank, s = np.linalg.lstsq(X_mat, y_vec, rcond=None)
    alpha, beta = coef[0], coef[1]

    # Compute R^2
    y_pred = X_mat @ coef
    ss_tot = np.sum((y_vec - np.mean(y_vec)) ** 2)
    ss_res = np.sum((y_vec - y_pred) ** 2)
    r_squared = 1.0 - (ss_res / ss_tot)

    scaling_results = {
        "alpha_1Q_coefficient": float(alpha),
        "beta_2Q_coefficient": float(beta),
        "r_squared": float(r_squared),
        "scaling_formula": f"1 - F_Q = {alpha:.4f} * N_1Q * p_1Q + {beta:.4f} * N_2Q * p_2Q",
        "description": "Semi-empirical first-order perturbation scaling model for state infidelity"
    }

    out_path = os.path.join(RESULTS_DIR, "predictive_scaling_model.json")
    with open(out_path, "w") as f:
        json.dump(scaling_results, f, indent=2)

    print(f"  [OK] Predictive scaling fit:")
    print(f"       {scaling_results['scaling_formula']}")
    print(f"       R^2 = {r_squared:.4f}")
    print(f"       Saved: {out_path}")


if __name__ == "__main__":
    print("=" * 70)
    print("EXECUTING CONTROLLED PHYSICS BENCHMARK EXPERIMENTS")
    print("=" * 70)
    run_experiment_1()
    run_experiment_2()
    run_experiment_3()
    run_experiment_4()
    run_experiment_5()
    run_experiment_6()
    print("=" * 70)
    print("ALL 5 CONTROLLED PHYSICS EXPERIMENTS COMPLETE")
    print("=" * 70)
