import qiskit
import qiskit_aer
import yfinance
import numpy
import pandas
import matplotlib
import scipy
import sklearn
print('qiskit:', qiskit.__version__)
print('qiskit-aer:', qiskit_aer.__version__)
print('yfinance:', yfinance.__version__)
print('numpy:', numpy.__version__)
print('pandas:', pandas.__version__)
print('scipy:', scipy.__version__)
print('sklearn:', sklearn.__version__)
print('ALL PACKAGES OK')
