#!/usr/bin/env python3
"""
17_build_submission_package.py
==============================
Builds the comprehensive 15-folder Physical Review Applied submission package
and packages it into Physical_Review_Applied_Quantum_Finance_Benchmark.zip
with cryptographic SHA-256 manifest.

Directory Structure:
01_manuscript/
02_source_tex/
03_word/
04_pdf/
05_figures/
06_tables/
07_python/
08_matlab/
09_data/
10_references/
11_supplementary/
12_cover_letter/
13_github/
14_reproducibility/
15_journal_requirements/
"""

import os
import sys
import shutil
import hashlib
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SUBMISSION_DIR = os.path.join(ROOT, "submission_package")
ZIP_NAME = "Physical_Review_Applied_Quantum_Finance_Benchmark.zip"
ZIP_PATH = os.path.join(ROOT, ZIP_NAME)
PKG_ZIP_PATH = os.path.join(SUBMISSION_DIR, ZIP_NAME)


def compute_sha256(filepath):
    """Compute SHA-256 hash of a file."""
    hasher = hashlib.sha256()
    with open(filepath, 'rb') as f:
        while chunk := f.read(65536):
            hasher.update(chunk)
    return hasher.hexdigest()


def copy_file_safe(src, dst):
    """Copy a file if it exists, creating parent dirs if needed."""
    if os.path.exists(src):
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
        return True
    return False


def copy_dir_safe(src, dst):
    """Copy directory contents recursively."""
    if os.path.exists(src):
        os.makedirs(dst, exist_ok=True)
        shutil.copytree(src, dst, dirs_exist_ok=True)
        return True
    return False


def build_package():
    print("=" * 70)
    print("ASSEMBLING PHYSICAL REVIEW APPLIED 15-FOLDER SUBMISSION PACKAGE")
    print("=" * 70)

    # Clean / create submission package staging root
    staging_dir = os.path.join(SUBMISSION_DIR, "bundle")
    if os.path.exists(staging_dir):
        shutil.rmtree(staging_dir)
    os.makedirs(staging_dir, exist_ok=True)

    folders = {
        "01_manuscript": os.path.join(staging_dir, "01_manuscript"),
        "02_source_tex": os.path.join(staging_dir, "02_source_tex"),
        "03_word": os.path.join(staging_dir, "03_word"),
        "04_pdf": os.path.join(staging_dir, "04_pdf"),
        "05_figures": os.path.join(staging_dir, "05_figures"),
        "06_tables": os.path.join(staging_dir, "06_tables"),
        "07_python": os.path.join(staging_dir, "07_python"),
        "08_matlab": os.path.join(staging_dir, "08_matlab"),
        "09_data": os.path.join(staging_dir, "09_data"),
        "10_references": os.path.join(staging_dir, "10_references"),
        "11_supplementary": os.path.join(staging_dir, "11_supplementary"),
        "12_cover_letter": os.path.join(staging_dir, "12_cover_letter"),
        "13_github": os.path.join(staging_dir, "13_github"),
        "14_reproducibility": os.path.join(staging_dir, "14_reproducibility"),
        "15_journal_requirements": os.path.join(staging_dir, "15_journal_requirements")
    }

    for f in folders.values():
        os.makedirs(f, exist_ok=True)

    # 01_manuscript
    print("\n[1/15] Populating 01_manuscript/...")
    copy_file_safe(os.path.join(ROOT, "manuscript", "main.tex"), os.path.join(folders["01_manuscript"], "main.tex"))
    copy_file_safe(os.path.join(ROOT, "manuscript", "references.bib"), os.path.join(folders["01_manuscript"], "references.bib"))
    copy_file_safe(os.path.join(ROOT, "manuscript", "main.pdf"), os.path.join(folders["01_manuscript"], "main.pdf"))
    copy_file_safe(os.path.join(ROOT, "manuscript", "main.docx"), os.path.join(folders["01_manuscript"], "main.docx"))

    # 02_source_tex
    print("[2/15] Populating 02_source_tex/...")
    copy_file_safe(os.path.join(ROOT, "manuscript", "main.tex"), os.path.join(folders["02_source_tex"], "main.tex"))
    copy_file_safe(os.path.join(ROOT, "manuscript", "references.bib"), os.path.join(folders["02_source_tex"], "references.bib"))
    copy_file_safe(os.path.join(ROOT, "manuscript", "ai_use_statement.tex"), os.path.join(folders["02_source_tex"], "ai_use_statement.tex"))
    copy_file_safe(os.path.join(ROOT, "manuscript", "authors.yaml"), os.path.join(folders["02_source_tex"], "authors.yaml"))
    copy_file_safe(os.path.join(ROOT, "texmaker_setup.md"), os.path.join(folders["02_source_tex"], "texmaker_setup.md"))

    # 03_word
    print("[3/15] Populating 03_word/...")
    copy_file_safe(os.path.join(ROOT, "manuscript", "main.docx"), os.path.join(folders["03_word"], "main.docx"))
    copy_file_safe(os.path.join(ROOT, "supplementary", "supplementary.docx"), os.path.join(folders["03_word"], "supplementary.docx"))

    # 04_pdf
    print("[4/15] Populating 04_pdf/...")
    copy_file_safe(os.path.join(ROOT, "manuscript", "main.pdf"), os.path.join(folders["04_pdf"], "main.pdf"))
    copy_file_safe(os.path.join(ROOT, "supplementary", "supplementary.pdf"), os.path.join(folders["04_pdf"], "supplementary.pdf"))
    copy_file_safe(os.path.join(ROOT, "figures", "pdf", "graphical_abstract.pdf"), os.path.join(folders["04_pdf"], "graphical_abstract.pdf"))
    copy_file_safe(os.path.join(ROOT, "manuscript", "cover_letter.pdf"), os.path.join(folders["04_pdf"], "cover_letter.pdf"))

    # 05_figures
    print("[5/15] Populating 05_figures/...")
    for fmt in ["png", "jpg", "pdf", "eps"]:
        src_fmt = os.path.join(ROOT, "figures", fmt)
        dst_fmt = os.path.join(folders["05_figures"], fmt)
        copy_dir_safe(src_fmt, dst_fmt)

    # 06_tables
    print("[6/15] Populating 06_tables/...")
    copy_dir_safe(os.path.join(ROOT, "tables"), folders["06_tables"])

    # 07_python
    print("[7/15] Populating 07_python/...")
    copy_dir_safe(os.path.join(ROOT, "python"), folders["07_python"])
    copy_file_safe(os.path.join(ROOT, "run_all.py"), os.path.join(folders["07_python"], "run_all.py"))
    copy_file_safe(os.path.join(ROOT, "requirements.txt"), os.path.join(folders["07_python"], "requirements.txt"))

    # 08_matlab
    print("[8/15] Populating 08_matlab/...")
    copy_dir_safe(os.path.join(ROOT, "matlab"), folders["08_matlab"])

    # 09_data
    print("[9/15] Populating 09_data/...")
    copy_dir_safe(os.path.join(ROOT, "data"), folders["09_data"])

    # 10_references
    print("[10/15] Populating 10_references/...")
    copy_dir_safe(os.path.join(ROOT, "references"), folders["10_references"])

    # 11_supplementary
    print("[11/15] Populating 11_supplementary/...")
    copy_dir_safe(os.path.join(ROOT, "supplementary"), folders["11_supplementary"])

    # 12_cover_letter
    print("[12/15] Populating 12_cover_letter/...")
    copy_file_safe(os.path.join(ROOT, "manuscript", "cover_letter.tex"), os.path.join(folders["12_cover_letter"], "cover_letter.tex"))
    copy_file_safe(os.path.join(ROOT, "manuscript", "cover_letter.pdf"), os.path.join(folders["12_cover_letter"], "cover_letter.pdf"))
    copy_file_safe(os.path.join(SUBMISSION_DIR, "COVER_LETTER.md"), os.path.join(folders["12_cover_letter"], "COVER_LETTER.md"))

    # 13_github
    print("[13/15] Populating 13_github/...")
    for gf in ["README.md", "LICENSE", "CITATION.cff", "CONTRIBUTING.md", "SECURITY.md", "VERSION", ".gitignore"]:
        copy_file_safe(os.path.join(ROOT, gf), os.path.join(folders["13_github"], gf))
    copy_dir_safe(os.path.join(ROOT, ".github"), os.path.join(folders["13_github"], ".github"))

    # 14_reproducibility
    print("[14/15] Populating 14_reproducibility/...")
    copy_dir_safe(os.path.join(ROOT, "environment"), os.path.join(folders["14_reproducibility"], "environment"))
    copy_file_safe(os.path.join(ROOT, "run_all.py"), os.path.join(folders["14_reproducibility"], "run_all.py"))
    copy_file_safe(os.path.join(ROOT, "docs", "reproducibility.md"), os.path.join(folders["14_reproducibility"], "reproducibility.md"))
    copy_file_safe(os.path.join(ROOT, "results", "reproducibility_report.json"), os.path.join(folders["14_reproducibility"], "reproducibility_report.json"))

    # 15_journal_requirements
    print("[15/15] Populating 15_journal_requirements/...")
    copy_dir_safe(os.path.join(ROOT, "journal_audit"), os.path.join(folders["15_journal_requirements"], "journal_audit"))
    copy_dir_safe(os.path.join(ROOT, "docs"), os.path.join(folders["15_journal_requirements"], "docs"))

    # Generate Checksums Manifest
    print("\nGenerating SHA-256 Manifest...")
    manifest_path = os.path.join(staging_dir, "CHECKSUMS.sha256")
    manifest_lines = []
    for root, dirs, files in os.walk(staging_dir):
        for file in sorted(files):
            if file == "CHECKSUMS.sha256":
                continue
            fpath = os.path.join(root, file)
            rel_path = os.path.relpath(fpath, staging_dir).replace("\\", "/")
            h = compute_sha256(fpath)
            manifest_lines.append(f"{h}  {rel_path}\n")

    with open(manifest_path, "w", encoding="utf-8") as f:
        f.writelines(manifest_lines)

    copy_file_safe(manifest_path, os.path.join(SUBMISSION_DIR, "CHECKSUMS.sha256"))
    print(f"[OK] Wrote CHECKSUMS.sha256 ({len(manifest_lines)} files hashed)")

    # Create Zip Archive
    print("\nCreating ZIP Archive...")
    for target_zip in [ZIP_PATH, PKG_ZIP_PATH]:
        with zipfile.ZipFile(target_zip, "w", zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(staging_dir):
                for file in sorted(files):
                    fpath = os.path.join(root, file)
                    rel_path = os.path.relpath(fpath, staging_dir)
                    zipf.write(fpath, arcname=rel_path)

        size_mb = os.path.getsize(target_zip) / (1024 * 1024)
        print(f"[OK] Created: {target_zip} ({size_mb:.2f} MB)")

    print("=" * 70)
    print("SUBMISSION PACKAGE COMPLETE & VERIFIED")
    print("=" * 70)


if __name__ == "__main__":
    build_package()
