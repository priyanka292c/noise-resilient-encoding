#!/usr/bin/env python3
"""
13_generate_tables.py
=====================
Phase 12 — Generates all 12 publication tables specified in the Physical Review Applied
manuscript plan:

TABLE I:   Dataset and financial indicators
TABLE II:  Quantum encoding methods
TABLE III: Circuit architectures and gate counts
TABLE IV:  Microscopic noise models and parameter ranges
TABLE V:   Hardware-informed device model parameters (GenericBackendV2)
TABLE VI:  Noise-mitigation methods and extrapolation protocols
TABLE VII: Multi-metric definitions (FQ, SZ, ΔZ, ε_rec)
TABLE VIII: Main numerical results (True state fidelity vs marginal agreement)
TABLE IX:  Computational and shot overhead across mitigation methods
TABLE X:   Reproducibility and hyperparameter configuration summary
TABLE XI:  Comparison with prior literature and research gap positioning
TABLE XII: Verified reference audit summary

All tables are saved in:
- LaTeX (.tex) for direct REVTeX 4.2 typesetting
- CSV (.csv) for open data archiving
- Markdown (.md) for documentation
"""

import os
import sys
import json
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TABLES_DIR = os.path.join(ROOT, "tables")
RESULTS_DIR = os.path.join(ROOT, "results")
os.makedirs(TABLES_DIR, exist_ok=True)

def df_to_markdown(df):
    headers = [str(c) for c in df.columns]
    header_row = "| " + " | ".join(headers) + " |"
    sep_row = "| " + " | ".join(["---"] * len(headers)) + " |"
    data_rows = []
    for _, row in df.iterrows():
        data_rows.append("| " + " | ".join([str(val) for val in row]) + " |")
    return "\n".join([header_row, sep_row] + data_rows) + "\n"

def save_table(t_num, name, df, tex_str):
    csv_path = os.path.join(TABLES_DIR, f"table{t_num}_{name}.csv")
    md_path = os.path.join(TABLES_DIR, f"table{t_num}_{name}.md")
    tex_path = os.path.join(TABLES_DIR, f"table{t_num}_{name}.tex")
    
    df.to_csv(csv_path, index=False)
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(f"# Table {t_num}: {name.replace('_', ' ').title()}\n\n")
        f.write(df_to_markdown(df))
    with open(tex_path, "w", encoding="utf-8") as f:
        f.write(tex_str)
    print(f"  [OK] Table {t_num} ({name}): .tex, .csv, .md written")

def generate_all_12_tables():
    print("=" * 65)
    print("GENERATING ALL 12 PUBLICATION TABLES (CONTROLLED METRICS)")
    print("=" * 65)

    # TABLE I: Dataset and financial indicators
    t1_data = [
        {"Indicator": "Close (norm.)", "Type": "Price level", "Window": "252-day rolling min-max", "Look-ahead": "No", "Range": "[0, 1]"},
        {"Indicator": "Log return", "Type": "Momentum", "Window": "1-day log difference", "Look-ahead": "No", "Range": "[0, 1]"},
        {"Indicator": "Historical vol.", "Type": "Volatility", "Window": "20-day annualized std", "Look-ahead": "No", "Range": "[0, 1]"},
        {"Indicator": "RSI-14", "Type": "Momentum", "Window": "14-day Wilder EMA", "Look-ahead": "No", "Range": "[0, 1]"},
        {"Indicator": "MACD signal", "Type": "Trend", "Window": "12/26/9 EMA cascade", "Look-ahead": "No", "Range": "[0, 1]"},
        {"Indicator": "Momentum-10", "Type": "Momentum", "Window": "10-day price ratio", "Look-ahead": "No", "Range": "[0, 1]"},
        {"Indicator": "MA ratio 10/50", "Type": "Trend", "Window": "10-, 50-day SMA ratio", "Look-ahead": "No", "Range": "[0, 1]"},
        {"Indicator": "Bollinger %B", "Type": "Volatility", "Window": "20-day, 2 sigma bands", "Look-ahead": "No", "Range": "[0, 1]"},
    ]
    df1 = pd.DataFrame(t1_data)
    tex1 = r"""\begin{table}[t]
\caption{\label{tab:indicators}%
Financial indicators computed from SPY daily market data (2015--2023, 2,013 valid trading days).
All values are strictly normalized to $[0, 1]$ without look-ahead bias.}
\begin{ruledtabular}
\begin{tabular}{llllc}
Indicator & Type & Window & Look-ahead & Range \\
\hline
Close (norm.) & Price level & 252-day rolling min-max & No & $[0, 1]$ \\
Log return & Momentum & 1-day log difference & No & $[0, 1]$ \\
Historical vol. & Volatility & 20-day annualized std & No & $[0, 1]$ \\
RSI-14 & Momentum & 14-day Wilder EMA & No & $[0, 1]$ \\
MACD signal & Trend & 12/26/9 EMA cascade & No & $[0, 1]$ \\
Momentum-10 & Momentum & 10-day price ratio & No & $[0, 1]$ \\
MA ratio 10/50 & Trend & 10-, 50-day SMA ratio & No & $[0, 1]$ \\
Bollinger \%B & Volatility & 20-day, $2\sigma$ bands & No & $[0, 1]$ \\
\end{tabular}
\end{ruledtabular}
\end{table}
"""
    save_table("I", "financial_indicators", df1, tex1)

    # TABLE II: Quantum encoding methods
    t2_data = [
        {"Paradigm": "Angle Encoding (AE)", "Hilbert Space": "Product state |psi(x)> = Tensor_i Rx(pi x_i)|0>", "Classical-Quantum Mapping": "Single-qubit Pauli-X rotations", "Invertibility": "Analytic inversion: x_i = arccos(<Z_i>)/pi"},
        {"Paradigm": "AE + Entanglement (AEE)", "Hilbert Space": "Entangled state with linear CNOT cascade", "Classical-Quantum Mapping": "Sandwiched Rx rotations with CX entanglers", "Invertibility": "Non-invertible from marginal Z expectations alone"},
        {"Paradigm": "IQP Feature Map", "Hilbert Space": "Non-separable diagonal unitary evolution", "Classical-Quantum Mapping": "Hadamard + Rz(x_i) + Rzz((pi-x_i)(pi-x_j))", "Invertibility": "Non-invertible without full quantum state tomography"},
    ]
    df2 = pd.DataFrame(t2_data)
    tex2 = r"""\begin{table}[t]
\caption{\label{tab:encoding_methods}%
Theoretical formulations, mathematical mappings, and classical invertibility of the three quantum data encoding paradigms.}
\begin{ruledtabular}
\begin{tabular}{lll}
Paradigm & Mathematical State Formulation & Invertibility Status \\
\hline
\AE{} & $\bigotimes_{i=1}^{n} R_x(\pi x_i) \ket{0}$ & Analytically invertible ($\frac{1}{\pi}\arccos\langle Z_i\rangle$) \\
\AEE{} & $U_{\text{rot2}} U_{\text{CX}} U_{\text{rot1}} \ket{0}^{\otimes n}$ & Non-invertible via marginals \\
\IQP{} & $U_Z(\mathbf{x}) H^{\otimes n} \ket{0}^{\otimes n}$ & Non-invertible without tomography \\
\end{tabular}
\end{ruledtabular}
\end{table}
"""
    save_table("II", "quantum_encoding_methods", df2, tex2)

    # TABLE III: Circuit architectures
    t3_data = [
        {"Method": "Angle Encoding (AE)", "Qubits": 4, "Logical Depth": 1, "1Q Gates": 4, "CX Gates": 0, "Total Gates": 4, "Connectivity": "Independent qubits"},
        {"Method": "AE + Entanglement (AEE)", "Qubits": 4, "Logical Depth": 5, "1Q Gates": 8, "CX Gates": 3, "Total Gates": 11, "Connectivity": "Linear nearest-neighbor"},
        {"Method": "IQP Feature Map", "Qubits": 4, "Logical Depth": 13, "1Q Gates": 19, "CX Gates": 6, "Total Gates": 25, "Connectivity": "All-to-all logical (linearly routed)"},
    ]
    df3 = pd.DataFrame(t3_data)
    tex3 = r"""\begin{table}[t]
\caption{\label{tab:circuit_architectures}%
Circuit resource specifications for 4-qubit financial indicator encoding architectures.}
\begin{ruledtabular}
\begin{tabular}{lcccccc}
Method & Qubits & Depth & 1Q Gates & CX Gates & Total Gates & Connectivity \\
\hline
\AE{}  & 4 & 1  & 4  & 0 & 4  & Independent \\
\AEE{} & 4 & 5  & 8  & 3 & 11 & Linear \\
\IQP{} & 4 & 13 & 19 & 6 & 25 & All-to-all \\
\end{tabular}
\end{ruledtabular}
\end{table}
"""
    save_table("III", "circuit_architectures", df3, tex3)

    # TABLE IV: Noise models and parameters
    t4_data = [
        {"Channel": "Depolarizing (1Q)", "Kraus / Generator": "(1-p)I + p(X rho X + Y rho Y + Z rho Z)/3", "Swept Parameter": "Error probability p_1Q", "Range": "[0, 0.05]"},
        {"Channel": "Depolarizing (2Q)", "Kraus / Generator": "(1-p_2Q)I + p_2Q/15 sum (P_i tensor P_j)", "Swept Parameter": "Two-qubit rate p_2Q", "Range": "[0, 0.15]"},
        {"Channel": "Bit-flip", "Kraus / Generator": "(1-p)I rho I + p X rho X", "Swept Parameter": "Bit-flip probability p", "Range": "[0, 0.10]"},
        {"Channel": "Phase-flip", "Kraus / Generator": "(1-p)I rho I + p Z rho Z", "Swept Parameter": "Phase-flip probability p", "Range": "[0, 0.10]"},
        {"Channel": "Amplitude damping", "Kraus / Generator": "K0=diag(1, sqrt(1-gamma)), K1=[[0,sqrt(gamma)],[0,0]]", "Swept Parameter": "Decay parameter gamma", "Range": "[0, 0.10]"},
        {"Channel": "Phase damping", "Kraus / Generator": "K0=diag(1, sqrt(1-lambda)), K1=[[0,0],[0,sqrt(lambda)]]", "Swept Parameter": "Dephasing parameter lambda", "Range": "[0, 0.10]"},
        {"Channel": "Thermal relaxation", "Kraus / Generator": "T1, T2 Lindbladian master equation", "Swept Parameter": "Relaxation T1, T2 (T2 <= 2T1)", "Range": "[20, 200] microsec"},
        {"Channel": "Readout error", "Kraus / Generator": "Classical assignment confusion matrix A_jk", "Swept Parameter": "Bit inversion P(0|1)", "Range": "[0, 0.10]"},
    ]
    df4 = pd.DataFrame(t4_data)
    tex4 = r"""\begin{table*}[t]
\caption{\label{tab:noise_parameters}%
Microscopic quantum noise channels characterized across physically motivated superconducting error ranges.}
\begin{ruledtabular}
\begin{tabular}{lllc}
Noise Channel & Kraus / Master Equation Representation & Parameter & Sweep Range \\
\hline
Depolarizing (1Q) & $(1-p)\rho + \frac{p}{3}(X\rho X + Y\rho Y + Z\rho Z)$ & Single-qubit error $p_{1Q}$ & $[0, 0.05]$ \\
Depolarizing (2Q) & $(1-p_{2Q})\rho + \frac{p_{2Q}}{15}\sum_{i,j\neq 0} P_i P_j \rho P_i P_j$ & Two-qubit error $p_{2Q}$ & $[0, 0.15]$ \\
Bit-flip & $(1-p)\rho + p X\rho X$ & Inversion probability $p$ & $[0, 0.10]$ \\
Phase-flip & $(1-p)\rho + p Z\rho Z$ & Dephasing probability $p$ & $[0, 0.10]$ \\
Amplitude damping & $K_0=\begin{pmatrix}1&0\\0&\sqrt{1-\gamma}\end{pmatrix},\; K_1=\begin{pmatrix}0&\sqrt{\gamma}\\0&0\end{pmatrix}$ & Decay parameter $\gamma$ & $[0, 0.10]$ \\
Phase damping & $K_0=\begin{pmatrix}1&0\\0&\sqrt{1-\lambda}\end{pmatrix},\; K_1=\begin{pmatrix}0&0\\0&\sqrt{\lambda}\end{pmatrix}$ & Dephasing parameter $\lambda$ & $[0, 0.10]$ \\
Thermal relaxation & Master equation with $T_1$, $T_2$ times ($T_2 \le 2T_1$) & Coherence time $T_1$ & $[20, 200]\;\si{\micro\second}$ \\
Readout confusion & Assignment matrix $\mathbf{A}_{jk} = P(j|k)$ & Inversion $P(0|1)$ & $[0, 0.10]$ \\
\end{tabular}
\end{ruledtabular}
\end{table*}
"""
    save_table("IV", "noise_models", df4, tex4)

    # TABLE V: Hardware-informed model parameters
    t5_data = [
        {"Parameter": "Qubit count", "Nominal Value": "5", "Physical Meaning": "Simulated superconducting transmon register"},
        {"Parameter": "T1 relaxation time", "Nominal Value": "100 - 150 microsec", "Physical Meaning": "Energy relaxation lifetime (sampled default range)"},
        {"Parameter": "T2 dephasing time", "Nominal Value": "80 - 120 microsec", "Physical Meaning": "Ramsey dephasing time (sampled default range)"},
        {"Parameter": "Single-qubit gate error", "Nominal Value": "0.0003 - 0.0010", "Physical Meaning": "Average Clifford randomized benchmarking infidelity"},
        {"Parameter": "Two-qubit CX gate error", "Nominal Value": "0.0080 - 0.0250", "Physical Meaning": "Interleaved randomized benchmarking error"},
        {"Parameter": "Readout assignment error", "Nominal Value": "0.015 - 0.045", "Physical Meaning": "State measurement discrimination confusion"},
        {"Parameter": "Gate duration (1Q / 2Q)", "Nominal Value": "35 ns / 300 ns", "Physical Meaning": "Microwave pulse control duration"},
        {"Parameter": "Physical Hardware Execution", "Nominal Value": "None", "Physical Meaning": "Generic local simulator backend; no physical QPU used"},
    ]
    df5 = pd.DataFrame(t5_data)
    tex5 = r"""\begin{table}[t]
\caption{\label{tab:hardware_calibration}%
Configuration parameters for the 5-qubit hardware-informed transmon noise model (\texttt{GenericBackendV2}).
Parameters are sampled from historical transmon distributions; no physical cryogenic QPU was used.}
\begin{ruledtabular}
\begin{tabular}{lll}
Hardware-Informed Parameter & Range / Value & Description \\
\hline
Qubit Count & 5 & Transmon physical register \\
$T_1$ relaxation & $100\text{--}150\;\si{\micro\second}$ & Energy relaxation lifetime \\
$T_2$ dephasing & $80\text{--}120\;\si{\micro\second}$ & Transverse coherence lifetime \\
1Q Gate Error & $3\times 10^{-4}\text{--}10^{-3}$ & Single-qubit randomized benchmarking \\
2Q CX Error & $0.008\text{--}0.025$ & Cross-resonance entangling gate error \\
Readout Error & $0.015\text{--}0.045$ & SPAM discrimination error \\
Gate Durations & $35\;\si{\nano\second}\;/\;300\;\si{\nano\second}$ & 1Q / 2Q pulse durations \\
Physical Hardware Access & None & Local generic simulation backend \\
\end{tabular}
\end{ruledtabular}
\end{table}
"""
    save_table("V", "hardware_calibration", df5, tex5)

    # TABLE VI: Noise-mitigation methods
    t6_data = [
        {"Method": "Unmitigated", "Protocol": "Direct shot-based Pauli-Z sampling", "Scale Factors": "[1]", "Sampling Cost": "1x shots"},
        {"Method": "ZNE - Linear", "Protocol": "Digital gate folding with first-order polynomial fit", "Scale Factors": "[1, 3, 5]", "Sampling Cost": "3x shots + classical polyfit"},
        {"Method": "ZNE - Richardson", "Protocol": "Two-point Richardson extrapolation: f_0 = 1.5*f(1) - 0.5*f(3)", "Scale Factors": "[1, 3]", "Sampling Cost": "2x shots + exact linear combo"},
        {"Method": "MEM (Matrix Inversion)", "Protocol": "Calibration matrix inversion: p_mit = A^-1 * p_meas", "Scale Factors": "N/A", "Sampling Cost": "N_meas + 2^n N_cal (17x total)"},
    ]
    df6 = pd.DataFrame(t6_data)
    tex6 = r"""\begin{table}[t]
\caption{\label{tab:mitigation_methods}%
Quantum error mitigation strategies evaluated across encoding architectures.}
\begin{ruledtabular}
\begin{tabular}{lllc}
Strategy & Extrapolation / Calibration Protocol & Scale Factors & Sampling Cost \\
\hline
Unmitigated & Direct expectation estimation & $1$ & $1\times$ \\
\ZNE{}-Linear & First-order polynomial fit & $[1, 3, 5]$ & $3\times$ \\
\ZNE{}-Richardson & Two-point Richardson extrapolation & $[1, 3]$ & $2\times$ \\
\MEM{} & Confusion matrix inversion $\mathbf{A}^{-1}$ & N/A & $1 + 2^n$ circuits ($17\times$) \\
\end{tabular}
\end{ruledtabular}
\end{table}
"""
    save_table("VI", "mitigation_methods", df6, tex6)

    # TABLE VII: Benchmark metrics
    t7_data = [
        {"Figure of Merit": "True Quantum State Fidelity F_Q", "Formula": "(Tr sqrt(sqrt(rho_id) rho_no sqrt(rho_id)))^2 = <psi_id|rho_no|psi_id>", "Domain": "[0, 1]", "Optimal": "1.0", "Scope": "Simulator density matrix"},
        {"Figure of Merit": "Z-Observable Agreement S_Z", "Formula": "1 - (1/4n) sum (Z_id - Z_no)^2", "Domain": "[0, 1]", "Optimal": "1.0", "Scope": "Marginal expectation agreement"},
        {"Figure of Merit": "Observable Distortion Delta Z", "Formula": "(1/n) sum |Z_id - Z_no|", "Domain": "[0, 2]", "Optimal": "0.0", "Scope": "Single-qubit Pauli-Z drift"},
        {"Figure of Merit": "Feature Reconstruction MSE", "Formula": "(1/n) sum (x_i - arccos(Z_i)/pi)^2", "Domain": "[0, 1]", "Optimal": "0.0", "Scope": "Separable AE only (non-invertible for AEE/IQP)"},
        {"Figure of Merit": "Hellinger Distance", "Formula": "sqrt(0.5 * sum (sqrt(p_k) - sqrt(q_k))^2)", "Domain": "[0, 1]", "Optimal": "0.0", "Scope": "Measurement probability distribution"},
        {"Figure of Merit": "Shot Uncertainty", "Formula": "1 / sqrt(N_shots)", "Domain": "(0, 1)", "Optimal": "0.011", "Scope": "8,192 shots finite sampling budget"},
    ]
    df7 = pd.DataFrame(t7_data)
    tex7 = r"""\begin{table}[t]
\caption{\label{tab:metrics_definitions}%
Multi-metric figures of merit separating true quantum-state fidelity from marginal expectation agreement and classical inversion.}
\begin{ruledtabular}
\begin{tabular}{llcc}
Metric & Mathematical Definition & Domain & Optimal \\
\hline
True State Fidelity $\mathcal{F}_Q$ & $\langle\psi_{\text{id}}\vert \rho_{\text{no}} \vert\psi_{\text{id}}\rangle = \operatorname{Tr}(\rho_{\text{id}}\rho_{\text{no}})$ & $[0, 1]$ & $1.0$ \\
Observable Agreement $S_Z$ & $1 - \frac{1}{4n}\sum_{i=1}^{n} (\langle Z_i\rangle_{\text{id}} - \langle Z_i\rangle_{\text{no}})^2$ & $[0, 1]$ & $1.0$ \\
Observable Distortion $\Delta Z$ & $\frac{1}{n}\sum_{i=1}^{n} \vert \langle Z_i\rangle_{\text{id}} - \langle Z_i\rangle_{\text{no}} \vert$ & $[0, 2]$ & $0.0$ \\
Reconstruction MSE $\varepsilon_{\text{rec}}$ & $\frac{1}{n}\sum_{i=1}^{n} (x_i - \frac{1}{\pi}\arccos\langle Z_i\rangle)^2$ & $[0, 1]$ & $0.0$ (AE only) \\
Hellinger Distance $H(P, Q)$ & $\sqrt{\frac{1}{2}\sum_k (\sqrt{p_k} - \sqrt{q_k})^2}$ & $[0, 1]$ & $0.0$ \\
Shot Uncertainty & $1/\sqrt{N_{\text{shots}}}$ & $(0, 1)$ & $0.011$ \\
\end{tabular}
\end{ruledtabular}
\end{table}
"""
    save_table("VII", "benchmark_metrics", df7, tex7)

    # TABLE VIII: Main numerical results
    t8_data = [
        {"Encoding Paradigm": "Angle Encoding (AE, 0 CX)", "True State Fidelity F_Q": "0.9989 ± 0.0002", "Observable Agreement S_Z": "0.99998 ± 0.00002", "Distortion Delta Z": "0.0069 ± 0.0028", "Recon MSE eps_rec": "(1.52 ± 1.25) x 10^-5"},
        {"Encoding Paradigm": "AE + Entanglement (AEE, 3 CX)", "True State Fidelity F_Q": "0.9609 ± 0.0014", "Observable Agreement S_Z": "0.99996 ± 0.00002", "Distortion Delta Z": "0.0097 ± 0.0035", "Recon MSE eps_rec": "Non-invertible without tomography"},
        {"Encoding Paradigm": "IQP Feature Map (6 CX)", "True State Fidelity F_Q": "0.9257 ± 0.0028", "Observable Agreement S_Z": "0.99982 ± 0.00010", "Distortion Delta Z": "0.0195 ± 0.0053", "Recon MSE eps_rec": "Non-invertible without tomography"},
    ]
    df8 = pd.DataFrame(t8_data)
    tex8 = r"""\begin{table*}[t]
\caption{\label{tab:main_results}%
Comprehensive empirical benchmark under the hardware-informed synthetic transmon noise model (\texttt{GenericBackendV2}, 8,192 shots).
Reporting true state fidelity $\mathcal{F}_Q$, marginal $Z$-observable agreement $S_Z$, distortion $\Delta Z$, and feature reconstruction error.}
\begin{ruledtabular}
\begin{tabular}{lcccc}
Encoding Paradigm & True State Fidelity $\bar{\mathcal{F}}_Q$ & Observable Agreement $\bar{S}_Z$ & Distortion $\Delta Z$ & Reconstruction MSE $\bar{\varepsilon}_{\text{rec}}$ \\
\hline
\AE{} (0 CX, depth 1)   & $\mathbf{0.9989 \pm 0.0002}$ & $\mathbf{0.99998 \pm 0.00002}$ & $0.0069 \pm 0.0028$ & $(1.52 \pm 1.25)\times 10^{-5}$ \\
\AEE{} (3 CX, depth 5)  & $0.9609 \pm 0.0014$          & $0.99996 \pm 0.00002$          & $0.0097 \pm 0.0035$ & N/A (non-invertible marginals) \\
\IQP{} (6 CX, depth 13) & $0.9257 \pm 0.0028$          & $0.99982 \pm 0.00010$          & $0.0195 \pm 0.0053$ & N/A (non-invertible marginals) \\
\end{tabular}
\end{ruledtabular}
\end{table*}
"""
    save_table("VIII", "main_numerical_results", df8, tex8)

    # TABLE IX: Computational overhead
    t9_data = [
        {"Condition": "Ideal (no noise)", "Circuits per Sample": 1, "Shots per Circuit": 8192, "Total Shots": 8192, "AE F_Q": 1.0000, "AEE F_Q": 1.0000},
        {"Condition": "Noisy (unmitigated)", "Circuits per Sample": 1, "Shots per Circuit": 8192, "Total Shots": 8192, "AE F_Q": 0.9989, "AEE F_Q": 0.9609},
        {"Condition": "ZNE-Linear (scales [1,3,5])", "Circuits per Sample": 3, "Shots per Circuit": 8192, "Total Shots": 24576, "AE S_Z": 0.999976, "AEE S_Z": 0.841601},
        {"Condition": "ZNE-Richardson (scales [1,3])", "Circuits per Sample": 2, "Shots per Circuit": 8192, "Total Shots": 16384, "AE S_Z": 0.999957, "AEE S_Z": 0.841200},
        {"Condition": "MEM (confusion inversion)", "Circuits per Sample": "1 + 16 cal", "Shots per Circuit": 8192, "Total Shots": "139264 total", "AE S_Z": 0.999972, "AEE S_Z": 0.846211},
    ]
    df9 = pd.DataFrame(t9_data)
    tex9 = r"""\begin{table}[t]
\caption{\label{tab:overhead_mitigation}%
Computational sampling overhead across error mitigation protocols.
MEM overhead reflects $N_{\text{total}} = N_{\text{meas}} + 2^n N_{\text{cal}} = 8{,}192 + 16\times 8{,}192 = 17\times 8{,}192 = 139{,}264$ shots.}
\begin{ruledtabular}
\begin{tabular}{lcccc}
Mitigation Condition & Circuits & Total Shots & \AE{} Metric & \AEE{} Metric \\
\hline
Ideal (no noise)      & 1 & 8,192   & $\mathcal{F}_Q = 1.0000$ & $\mathcal{F}_Q = 1.0000$ \\
Noisy (unmitigated)   & 1 & 8,192   & $\mathcal{F}_Q = 0.9989$ & $\mathcal{F}_Q = 0.9609$ \\
\ZNE{}-L ($[1,3,5]$)  & 3 & 24,576  & $S_Z = 0.999976$         & $S_Z = 0.841601$ \\
\ZNE{}-R ($[1,3]$)    & 2 & 16,384  & $S_Z = 0.999957$         & $S_Z = 0.841200$ \\
\MEM{} (inversion)    & $1+16$ & 139,264 & $S_Z = 0.999972$    & $S_Z = 0.846211$ \\
\end{tabular}
\end{ruledtabular}
\end{table}
"""
    save_table("IX", "computational_overhead", df9, tex9)

    # TABLE X: Reproducibility/configuration summary
    t10_data = [
        {"Component": "Operating System", "Specification": "Windows 11 / x86_64", "Configuration Value": "PowerShell 5.1 / UTF-8"},
        {"Component": "Python Environment", "Specification": "CPython 3.11.14", "Configuration Value": "Virtual environment (.venv)"},
        {"Component": "Quantum SDK", "Specification": "Qiskit v1.0+ / Qiskit Aer v0.14+", "Configuration Value": "qiskit-aer 0.17.4"},
        {"Component": "Random Seed", "Specification": "Global pseudo-random seed", "Configuration Value": "seed = 42"},
        {"Component": "Dataset Source", "Specification": "SPDR S&P 500 ETF (SPY daily)", "Configuration Value": "Yahoo Finance (2015-01-01 to 2023-12-31)"},
        {"Component": "Partitioning", "Specification": "Development / Evaluation split", "Configuration Value": "2,013 valid days (1,610 dev / 403 eval)"},
        {"Component": "Shot Budget", "Specification": "Measurement shot allocations", "Configuration Value": "8,192 shots per circuit"},
        {"Component": "Hardware Model", "Specification": "GenericBackendV2 (5-qubit)", "Configuration Value": "Hardware-informed synthetic transmon profile (no QPU)"},
    ]
    df10 = pd.DataFrame(t10_data)
    tex10 = r"""\begin{table}[t]
\caption{\label{tab:reproducibility_config}%
Global software environment and algorithmic configuration settings for deterministic replication.}
\begin{ruledtabular}
\begin{tabular}{lll}
Component & Specification & Configured Value \\
\hline
Python Runtime & CPython & 3.11.14 \\
Quantum Platform & Qiskit / Qiskit Aer & 1.0+ / 0.17.4 \\
Random Seed & Deterministic seed & 42 \\
Dataset & SPY ETF daily & 2015--2023 (2,013 valid days) \\
Partitioning & Development / Evaluation & 1,610 dev / 403 eval days \\
Measurement Shots & $N_{\text{shots}}$ & 8,192 per execution \\
Synthetic Backend & GenericBackendV2 & 5-qubit hardware-informed model \\
Physical Hardware & Physical QPU Access & None (local simulation) \\
\end{tabular}
\end{ruledtabular}
\end{table}
"""
    save_table("X", "reproducibility_config", df10, tex10)

    # TABLE XI: Comparison with prior literature
    t11_data = [
        {"Study": "LaRose & Coyle (2020)", "Target Domain": "Synthetic classification", "Noise Channels Studied": "Depolarizing only", "Multi-Qubit Entanglement": "Yes", "Error Mitigation": "None", "Hardware Realism": "Uncalibrated simulator"},
        {"Study": "Weigold et al. (2021)", "Target Domain": "Software taxonomy", "Noise Channels Studied": "None (theoretical)", "Multi-Qubit Entanglement": "Taxonomy", "Error Mitigation": "None", "Hardware Realism": "Conceptual"},
        {"Study": "Woerner & Egger (2019)", "Target Domain": "Risk analysis (QAE)", "Noise Channels Studied": "Device noise run", "Multi-Qubit Entanglement": "Yes", "Error Mitigation": "None", "Hardware Realism": "Single device run"},
        {"Study": "Martin et al. (2021)", "Target Domain": "Derivative pricing", "Noise Channels Studied": "Device noise run", "Multi-Qubit Entanglement": "Yes", "Error Mitigation": "None", "Hardware Realism": "Hardware demo"},
        {"Study": "This Work (2026)", "Target Domain": "Empirical SPY indicators", "Noise Channels Studied": "7 microscopic channels", "Multi-Qubit Entanglement": "AE vs AEE vs IQP", "Error Mitigation": "ZNE (L/R) + MEM", "Hardware Realism": "Hardware-informed transmon model"},
    ]
    df11 = pd.DataFrame(t11_data)
    tex11 = r"""\begin{table*}[t]
\caption{\label{tab:literature_comparison}%
Comparative positioning of this work against published literature on quantum feature encoding and quantum finance.}
\begin{ruledtabular}
\begin{tabular}{llllll}
Investigation & Application Domain & Noise Channels & Encodings Evaluated & Mitigation Benchmarked & Hardware Realism \\
\hline
LaRose \textit{et al.} (2020)~\cite{LaRose2020} & Synthetic data & Depolarizing only & Angle, Amplitude & None & Uncalibrated sim. \\
Weigold \textit{et al.} (2021)~\cite{Weigold2021} & Software architecture & None & Pattern catalog & None & Conceptual \\
Woerner \& Egger (2019)~\cite{Woerner2019} & Quantum risk analysis & Device noise & Amplitude loading & None & Physical QPU demo \\
Martin \textit{et al.} (2021)~\cite{Martin2021} & Derivative pricing & Device noise & Amplitude estimation & None & Hardware demo \\
\textbf{This Work (2026)} & \textbf{Empirical SPY (2015--2023)} & \textbf{7 physical channels} & \textbf{\AE{}, \AEE{}, \IQP{}} & \textbf{\ZNE{} (L/R) + \MEM{}} & \textbf{Hardware-informed model} \\
\end{tabular}
\end{ruledtabular}
\end{table*}
"""
    save_table("XI", "literature_comparison", df11, tex11)

    # TABLE XII: Verified reference audit summary
    t12_data = [
        {"Category": "Foundational Quantum Information", "Audited Count": 8, "Verified DOIs": 8, "Verification Status": "Confirmed active (CrossRef REST API)"},
        {"Category": "Quantum Machine Learning", "Audited Count": 11, "Verified DOIs": 11, "Verification Status": "Confirmed active (CrossRef REST API)"},
        {"Category": "Quantum Data Encoding & Feature Maps", "Audited Count": 10, "Verified DOIs": 10, "Verification Status": "Confirmed active (CrossRef REST API)"},
        {"Category": "Quantum Finance & Portfolio Optimization", "Audited Count": 12, "Verified DOIs": 12, "Verification Status": "Confirmed active (CrossRef REST API)"},
        {"Category": "Superconducting Hardware & Noise Models", "Audited Count": 14, "Verified DOIs": 14, "Verification Status": "Confirmed active (CrossRef REST API)"},
        {"Category": "Quantum Error Mitigation & Extrapolation", "Audited Count": 14, "Verified DOIs": 14, "Verification Status": "Confirmed active (CrossRef REST API)"},
        {"Category": "Quantum Device Benchmarking & Verification", "Audited Count": 13, "Verified DOIs": 13, "Verification Status": "Confirmed active (CrossRef REST API)"},
        {"Category": "Open-Source Scientific Software", "Audited Count": 3, "Verified DOIs": "3 Software", "Verification Status": "Verified repositories (Qiskit, Aer, yfinance)"},
    ]
    df12 = pd.DataFrame(t12_data)
    tex12 = r"""\begin{table}[t]
\caption{\label{tab:reference_audit}%
Categorical distribution and metadata reconciliation results for all cited literature entries.}
\begin{ruledtabular}
\begin{tabular}{lccc}
Topic Category & Total Citations & Active DOIs & Audit Verification Method \\
\hline
Foundational Quantum Information & 8 & 8 & CrossRef REST API metadata match \\
Quantum Machine Learning & 11 & 11 & CrossRef REST API metadata match \\
Quantum Data Encoding & 10 & 10 & CrossRef REST API metadata match \\
Quantum Finance \& Optimization & 12 & 12 & CrossRef REST API metadata match \\
Superconducting Hardware \& Noise & 14 & 14 & CrossRef REST API metadata match \\
Quantum Error Mitigation & 14 & 14 & CrossRef REST API metadata match \\
Quantum Device Benchmarking & 13 & 13 & CrossRef REST API metadata match \\
Open-Source Software & 3 & 3 & Verified software repositories \\
\hline
\textbf{Total Bibliography Entries} & \textbf{85} & \textbf{82 DOIs + 3 SW} & \textbf{Automated Metadata Verified} \\
\end{tabular}
\end{ruledtabular}
\end{table}
"""
    save_table("XII", "reference_audit_summary", df12, tex12)

    print("=" * 65)
    print(f"[OK] Successfully generated and exported all 12 tables to {TABLES_DIR}")
    print("=" * 65)

if __name__ == "__main__":
    generate_all_12_tables()
