#!/usr/bin/env python3
"""
06_noise_models.py
==================
Phase 10 — Script 6: Noise model construction and noise sweep experiments.

Implements the following noise channels using Qiskit Aer:
  1. Depolarizing noise (single-qubit and two-qubit)
  2. Bit-flip noise (Pauli X error)
  3. Phase-flip noise (Pauli Z error)
  4. Amplitude damping (T1 relaxation)
  5. Phase damping (T2 dephasing without energy relaxation)
  6. Thermal relaxation (T1 + T2, gate-time dependent)
  7. Measurement/readout error

All error rates are swept over physically motivated ranges.

Physical Review Applied manuscript:
"Noise Resilient Quantum Circuits for Financial Indicator Encoding
and Hardware Aware Benchmarking"
"""

import os
import sys
import json
import numpy as np
import pandas as pd
from tqdm import tqdm

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import yaml
with open(os.path.join(ROOT, "config.yaml"), "r") as f:
    CONFIG = yaml.safe_load(f)

RANDOM_SEED = CONFIG["random_seed"]
np.random.seed(RANDOM_SEED)

RESULTS_DIR = os.path.join(ROOT, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

# Qiskit imports
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit_aer.noise import (
    NoiseModel,
    depolarizing_error,
    pauli_error,
    amplitude_damping_error,
    phase_damping_error,
    thermal_relaxation_error,
    ReadoutError,
)

# Import encoding circuits
sys.path.insert(0, os.path.join(ROOT, "python"))
from encoding_utils import (
    angle_encoding,
    angle_encoding_entangled,
    iqp_feature_map,
    build_measurement_circuit,
)

SHOTS = CONFIG["shots"]["noisy"]
N_QUBITS = 4


# ============================================================
# Utility: run circuit with noise and return expectation values
# ============================================================

def run_with_noise(qc_bound: QuantumCircuit,
                   noise_model: NoiseModel = None,
                   shots: int = SHOTS) -> dict:
    """
    Run a bound (parameter-substituted) circuit with optional noise.

    Returns dict with measurement counts and derived Z-expectation values.
    """
    sim = AerSimulator(noise_model=noise_model)
    qc_t = transpile(qc_bound, backend=sim, optimization_level=0)
    job = sim.run(qc_t, shots=shots)
    counts = job.result().get_counts()

    # Compute <Z_i> for each qubit from counts
    n = qc_bound.num_qubits
    z_exp = np.zeros(n)
    total = sum(counts.values())
    for bitstring, count in counts.items():
        # Qiskit bit order: rightmost bit = qubit 0
        bits = [int(b) for b in reversed(bitstring)]
        for i, b in enumerate(bits[:n]):
            z_exp[i] += count * (1 - 2 * b)  # +1 for |0>, -1 for |1>
    z_exp /= total

    return {"counts": counts, "z_expectation": z_exp.tolist(), "shots": shots}


# ============================================================
# Noise Model Builders
# ============================================================

def build_depolarizing_model(p1q: float, p2q: float) -> NoiseModel:
    """
    Build depolarizing noise model.

    Args:
        p1q: Single-qubit depolarizing probability
        p2q: Two-qubit depolarizing probability
    """
    noise_model = NoiseModel()
    if p1q > 0:
        err_1q = depolarizing_error(p1q, 1)
        noise_model.add_all_qubit_quantum_error(err_1q, ["u1", "u2", "u3", "rx", "ry", "rz", "h"])
    if p2q > 0:
        err_2q = depolarizing_error(p2q, 2)
        noise_model.add_all_qubit_quantum_error(err_2q, ["cx"])
    return noise_model


def build_bit_flip_model(p: float) -> NoiseModel:
    """Build bit-flip (X) error noise model."""
    noise_model = NoiseModel()
    if p > 0:
        err = pauli_error([("X", p), ("I", 1 - p)])
        noise_model.add_all_qubit_quantum_error(err, ["rx", "ry", "rz", "h", "u3"])
    return noise_model


def build_phase_flip_model(p: float) -> NoiseModel:
    """Build phase-flip (Z) error noise model."""
    noise_model = NoiseModel()
    if p > 0:
        err = pauli_error([("Z", p), ("I", 1 - p)])
        noise_model.add_all_qubit_quantum_error(err, ["rx", "ry", "rz", "h", "u3"])
    return noise_model


def build_amplitude_damping_model(gamma: float) -> NoiseModel:
    """
    Build amplitude damping noise model.

    gamma: relaxation probability (0 to 1).
    Models T1 decay: qubit loses excitation to environment.
    """
    noise_model = NoiseModel()
    if gamma > 0:
        err = amplitude_damping_error(gamma)
        noise_model.add_all_qubit_quantum_error(err, ["rx", "ry", "rz", "h", "u3"])
    return noise_model


def build_phase_damping_model(lambda_: float) -> NoiseModel:
    """
    Build phase damping noise model.

    lambda_: dephasing probability (0 to 1).
    Models pure dephasing (T2 without T1).
    """
    noise_model = NoiseModel()
    if lambda_ > 0:
        err = phase_damping_error(lambda_)
        noise_model.add_all_qubit_quantum_error(err, ["rx", "ry", "rz", "h", "u3"])
    return noise_model


def build_thermal_relaxation_model(T1_us: float, T2_us: float,
                                    gate_time_ns: float = 50.0) -> NoiseModel:
    """
    Build thermal relaxation noise model.

    Args:
        T1_us: T1 coherence time in microseconds
        T2_us: T2 coherence time in microseconds
        gate_time_ns: Gate duration in nanoseconds (default: 50 ns for CX)

    Constraint: T2 <= 2*T1 (physical constraint)
    """
    noise_model = NoiseModel()
    T1_ns = T1_us * 1e3
    T2_ns = T2_us * 1e3
    # Enforce physical constraint
    T2_ns = min(T2_ns, 2 * T1_ns)
    if T1_ns > 0 and T2_ns > 0:
        # Single-qubit gate thermal relaxation (gate_time ~20 ns)
        err_1q = thermal_relaxation_error(T1_ns, T2_ns, gate_time_ns / 2.5)
        noise_model.add_all_qubit_quantum_error(err_1q, ["rx", "ry", "rz", "h", "u3"])
        # Two-qubit gate thermal relaxation (CX gate ~50 ns, apply to each qubit)
        err_2q = thermal_relaxation_error(T1_ns, T2_ns, gate_time_ns)
        err_2q_both = err_2q.expand(err_2q)
        noise_model.add_all_qubit_quantum_error(err_2q_both, ["cx"])
    return noise_model


def build_readout_error_model(p0given1: float, p1given0: float) -> NoiseModel:
    """
    Build measurement readout error model.

    Args:
        p0given1: P(measure 0 | true state is 1)
        p1given0: P(measure 1 | true state is 0)
    """
    noise_model = NoiseModel()
    if p0given1 > 0 or p1given0 > 0:
        # ReadoutError([[P(0|0), P(1|0)], [P(0|1), P(1|1)]])
        ro_err = ReadoutError([[1 - p1given0, p1given0],
                               [p0given1, 1 - p0given1]])
        for q in range(N_QUBITS):
            noise_model.add_readout_error(ro_err, [q])
    return noise_model


# ============================================================
# Sweep experiments
# ============================================================

def make_test_circuit(encoding_fn, x_values: np.ndarray) -> QuantumCircuit:
    """Build and bind an encoding circuit with given parameter values."""
    qc, params, _ = encoding_fn(n_qubits=len(x_values))
    qc_meas = qc.copy()
    qc_meas.measure_all()
    # Bind parameters
    param_dict = {params[i]: x_values[i] for i in range(len(x_values))}
    qc_bound = qc_meas.assign_parameters(param_dict)
    return qc_bound


def compute_fidelity_from_expectations(z_ideal: np.ndarray,
                                        z_noisy: np.ndarray) -> float:
    """
    Compute feature reconstruction fidelity as 1 - MSE of Z-expectations.

    For angle encoding Rx(pi*x), the ideal <Z> = cos(pi*x).
    Fidelity here measures how well noisy measurements reproduce ideal values.
    """
    mse = np.mean((np.array(z_ideal) - np.array(z_noisy)) ** 2)
    # Normalize: max possible MSE = 4 (range of Z is [-1,+1], so diff in [-2,+2])
    fidelity = 1.0 - mse / 4.0
    return float(np.clip(fidelity, 0.0, 1.0))


def sweep_noise(encoding_fn, encoding_name: str,
                noise_builder_fn, noise_param_name: str,
                param_values: np.ndarray,
                x_values: np.ndarray) -> pd.DataFrame:
    """
    Sweep a noise parameter and measure encoding fidelity at each level.

    Args:
        encoding_fn: Encoding circuit builder function
        encoding_name: Name of the encoding method
        noise_builder_fn: Function that builds NoiseModel from a single parameter
        noise_param_name: Name of the noise parameter
        param_values: Array of noise parameter values to sweep
        x_values: Input feature vector to encode

    Returns:
        DataFrame with columns: [noise_param, z_expectations_noisy, fidelity, ...]
    """
    records = []

    # Ideal (no noise) baseline
    qc_bound = make_test_circuit(encoding_fn, x_values)
    ideal_result = run_with_noise(qc_bound, noise_model=None, shots=SHOTS)
    z_ideal = np.array(ideal_result["z_expectation"])

    for p in tqdm(param_values, desc=f"{encoding_name} | {noise_param_name}"):
        try:
            noise_model = noise_builder_fn(p)
            qc_bound = make_test_circuit(encoding_fn, x_values)
            result = run_with_noise(qc_bound, noise_model=noise_model, shots=SHOTS)
            z_noisy = np.array(result["z_expectation"])
            fidelity = compute_fidelity_from_expectations(z_ideal, z_noisy)
            records.append({
                "encoding": encoding_name,
                "noise_type": noise_param_name,
                "noise_parameter": p,
                "fidelity": fidelity,
                "z_ideal": z_ideal.tolist(),
                "z_noisy": z_noisy.tolist(),
                "mse": float(np.mean((z_ideal - z_noisy) ** 2)),
            })
        except Exception as e:
            print(f"  [WARN] Failed at {noise_param_name}={p:.4f}: {e}")
            records.append({
                "encoding": encoding_name,
                "noise_type": noise_param_name,
                "noise_parameter": p,
                "fidelity": None,
                "error": str(e),
            })

    return pd.DataFrame(records)


# ============================================================
# Main: run all noise sweeps
# ============================================================

if __name__ == "__main__":
    print("=" * 60)
    print("NOISE MODEL EXPERIMENTS")
    print("=" * 60)

    # Test input: representative financial feature vector
    x_test = np.array([0.45, 0.62, 0.38, 0.71])
    print(f"Test feature vector: {x_test}")

    encoders = [
        (angle_encoding, "angle_encoding"),
        (angle_encoding_entangled, "angle_encoding_entangled"),
    ]

    noise_cfg = CONFIG["noise"]
    all_results = []

    for enc_fn, enc_name in encoders:
        print(f"\n{'='*40}")
        print(f"Encoding: {enc_name}")
        print(f"{'='*40}")

        # 1. Depolarizing (single-qubit sweep, fixed 2Q at 3x rate)
        p1q_vals = np.linspace(*noise_cfg["depolarizing"]["single_qubit_range"],
                                noise_cfg["depolarizing"]["num_points"])

        def dep_model_1q(p):
            return build_depolarizing_model(p, p * 3)

        df_dep = sweep_noise(enc_fn, enc_name, dep_model_1q,
                             "depolarizing_p1q", p1q_vals, x_test)
        all_results.append(df_dep)

        # 2. Bit-flip
        bf_vals = np.linspace(*noise_cfg["bit_flip"]["rate_range"],
                               noise_cfg["bit_flip"]["num_points"])
        df_bf = sweep_noise(enc_fn, enc_name, build_bit_flip_model,
                            "bit_flip", bf_vals, x_test)
        all_results.append(df_bf)

        # 3. Phase-flip
        pf_vals = np.linspace(*noise_cfg["phase_flip"]["rate_range"],
                               noise_cfg["phase_flip"]["num_points"])
        df_pf = sweep_noise(enc_fn, enc_name, build_phase_flip_model,
                            "phase_flip", pf_vals, x_test)
        all_results.append(df_pf)

        # 4. Amplitude damping
        ad_vals = np.linspace(*noise_cfg["amplitude_damping"]["gamma_range"],
                               noise_cfg["amplitude_damping"]["num_points"])
        df_ad = sweep_noise(enc_fn, enc_name, build_amplitude_damping_model,
                            "amplitude_damping", ad_vals, x_test)
        all_results.append(df_ad)

        # 5. Phase damping
        pd_vals = np.linspace(*noise_cfg["phase_damping"]["lambda_range"],
                               noise_cfg["phase_damping"]["num_points"])
        df_pd_noise = sweep_noise(enc_fn, enc_name, build_phase_damping_model,
                                   "phase_damping", pd_vals, x_test)
        all_results.append(df_pd_noise)

        # 6. Thermal relaxation (vary T1, keep T2 = T1)
        T1_vals = np.linspace(*noise_cfg["thermal_relaxation"]["T1_us_range"],
                               noise_cfg["thermal_relaxation"]["num_points"])
        T2_factor = 0.6  # T2 = 0.6 * T1 (physically realistic)

        def thermal_model(T1):
            T2 = T2_factor * T1
            return build_thermal_relaxation_model(T1, T2,
                    gate_time_ns=noise_cfg["thermal_relaxation"]["gate_time_ns"])

        # Report as 1/T1 (decoherence rate) for plotting
        df_th = sweep_noise(enc_fn, enc_name, thermal_model,
                            "thermal_T1_us", T1_vals, x_test)
        all_results.append(df_th)

        # 7. Readout error
        ro_vals = np.linspace(*noise_cfg["readout_error"]["p0given1_range"],
                               noise_cfg["readout_error"]["num_points"])

        def ro_model(p):
            return build_readout_error_model(p, p * 0.5)

        df_ro = sweep_noise(enc_fn, enc_name, ro_model,
                            "readout_p0given1", ro_vals, x_test)
        all_results.append(df_ro)

    # Combine results
    results_df = pd.concat(all_results, ignore_index=True)
    results_path = os.path.join(RESULTS_DIR, "noise_sweep_results.csv")
    results_df.to_csv(results_path, index=False)
    print(f"\nNoise sweep results saved: {results_path}")
    print(f"Total records: {len(results_df)}")

    # Summary stats
    print("\nFidelity summary by noise type:")
    summary = (results_df.dropna(subset=["fidelity"])
               .groupby(["encoding", "noise_type"])["fidelity"]
               .agg(["min", "mean", "max"]).round(4))
    print(summary.to_string())

    # Save summary
    summary_path = os.path.join(RESULTS_DIR, "noise_sweep_summary.csv")
    summary.to_csv(summary_path)
    print(f"Summary saved: {summary_path}")

    print("\n" + "=" * 60)
    print("Noise model experiments COMPLETE.")
    print("=" * 60)
