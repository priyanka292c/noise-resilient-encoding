# Contributing and Reproduction Guide

Thank you for your interest in reproducing or extending the results of:
**"Noise Resilient Quantum Circuits for Financial Indicator Encoding and Hardware Aware Benchmarking"** (Physical Review Applied).

## Reproducibility Standards

All code in this repository adheres to strict scientific reproducibility standards:
1. **Deterministic Execution:** Random seeds are explicitly fixed (`config.yaml`) across all classical dataset splitting and quantum measurement samplers.
2. **Zero Look-Ahead Bias:** Financial indicators use only historical information available up to trading date $t$.
3. **No Unverified Data:** References, noise parameters, and device calibration profiles are verified against published literature and CrossRef APIs.
4. **Clean Dependencies:** All package versions are pinned in `environment/environment.yml` and `environment/requirements.txt`.

## Getting Started

### 1. Environment Setup
```bash
# Clone the repository
git clone https://github.com/quantum-finance-benchmarks/prapplied-2026.git
cd prapplied-2026

# Create conda/mamba environment
conda env create -f environment/environment.yml
conda activate qfinance-qiskit
```

### 2. End-to-End Pipeline Execution
To execute the complete simulation, figure generation, reference verification, and manuscript build:
```bash
python run_all.py
```

### 3. Step-by-Step Execution
Individual phases can be executed independently:
- `python python/01_environment_check.py` — Verify environment and Qiskit version
- `python python/02_download_prepare_data.py` — Download and preprocess daily SPY dataset
- `python python/04_quantum_encoding.py` — Synthesize 4-qubit quantum encoding circuits
- `python python/05_ideal_simulation.py` — Execute noise-free benchmark
- `python python/06_noise_models.py` — Sweep 7 physical noise channels
- `python python/07_noise_mitigation.py` — Benchmark ZNE and MEM error mitigation
- `python python/08_hardware_calibrated_simulation.py` — Run 5-qubit GenericBackendV2 sim
- `python python/12_generate_figures.py` — Render publication figures (EPS, PNG, PDF)
- `python python/14_export_tables.py` — Export standalone tables (.tex, .csv, .md)
- `python python/15_reference_verification.py` — Verify all DOIs via CrossRef
- `python python/16_generate_docx.py` — Generate publication Word (.docx) document
- `python python/17_build_submission_package.py` — Assemble journal submission archive
